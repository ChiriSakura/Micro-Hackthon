"""Bounded executable module contracts, independent of generated HDL.

Compiler declares math/protocol; this interpreter computes vectors and expected
values. The declaration is still planner-authored, NOT the trusted algorithm
oracle. Whole-system verification remains mandatory.
"""
from __future__ import annotations

import ast
from functools import lru_cache
import operator
import random


@lru_cache(maxsize=1024)
def _parse(expression):
    if not isinstance(expression, str) or len(expression) > 8192:
        raise ValueError('Behavior expression must be a string of at most 8192 characters')
    try:
        tree = ast.parse(expression, mode='eval')
    except SyntaxError as exc:
        raise ValueError(f'Invalid behavior expression: {expression}') from exc
    if len(list(ast.walk(tree))) > 512:
        raise ValueError('Behavior expression too complex')
    return tree.body


def _lane(word, index, width):
    if any(type(v) is not int for v in (word,index,width)) or word < 0 or not 0 <= index < 256 or not 1 <= width <= 65536:
        raise ValueError('lane(word,index,width) arguments out of bounds')
    return (word >> (index*width)) & ((1 << width)-1)


def _pack(width, *values):
    if type(width) is not int or not 1 <= width <= 65536 or not 1 <= len(values) <= 32:
        raise ValueError('pack(width,low_lane,...,high_lane) arguments out of bounds')
    if width*len(values) > 65536 or any(type(v) is not int or not 0 <= v < (1 << width) for v in values):
        raise ValueError('Packed lane exceeds its width')
    return sum(v << (i*width) for i,v in enumerate(values))


def _signed(word, width):
    if type(word) is not int or type(width) is not int or not 1 <= width <= 65536:
        raise ValueError('signed(word,width) requires bounded integer arguments')
    word &= (1 << width)-1
    return word-(1 << width) if word & (1 << (width-1)) else word


def _spack(width, *values):
    if type(width) is not int or not 1 <= width <= 65536 or any(
            type(v) is not int or not -(1 << (width-1)) <= v < (1 << (width-1)) for v in values):
        raise ValueError('Signed packed lane exceeds its width')
    return _pack(width, *(v & ((1 << width)-1) for v in values))


def evaluate(expression, values):
    """No eval/exec, attributes, imports, loops, arbitrary calls or host access."""
    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) in (int, bool):
            result = node.value
        elif isinstance(node, ast.Name) and node.id in values:
            result = values[node.id]
        elif isinstance(node, ast.BinOp):
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, (ast.LShift, ast.RShift)) and not 0 <= right <= 65536:
                raise ValueError('Shift out of bounds')
            op = {ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul,
                  ast.FloorDiv:operator.floordiv, ast.Mod:operator.mod,
                  ast.BitAnd:operator.and_, ast.BitOr:operator.or_, ast.BitXor:operator.xor,
                  ast.LShift:operator.lshift, ast.RShift:operator.rshift}.get(type(node.op))
            if op is None:
                raise ValueError('Unsupported behavior operator')
            result = op(left, right)
        elif isinstance(node, ast.UnaryOp):
            op = {ast.USub:operator.neg,ast.UAdd:operator.pos,ast.Invert:operator.invert,ast.Not:operator.not_}.get(type(node.op))
            if op is None:
                raise ValueError('Unsupported unary operator')
            result = op(visit(node.operand))
        elif isinstance(node, ast.IfExp):
            result = visit(node.body if visit(node.test) else node.orelse)
        elif isinstance(node, ast.BoolOp) and isinstance(node.op,(ast.And,ast.Or)):
            # Preserve short-circuiting for guards such as d == 0 or n // d < 16.
            result = True if isinstance(node.op,ast.And) else False
            for item in node.values:
                result = bool(visit(item))
                if result != isinstance(node.op,ast.And):
                    break
        elif isinstance(node, ast.Compare):
            left, result = visit(node.left), True
            for op,right_node in zip(node.ops,node.comparators):
                right=visit(right_node)
                fn={ast.Eq:operator.eq,ast.NotEq:operator.ne,ast.Lt:operator.lt,
                    ast.LtE:operator.le,ast.Gt:operator.gt,ast.GtE:operator.ge}.get(type(op))
                if fn is None:
                    raise ValueError('Unsupported comparison')
                result = result and fn(left,right)
                left=right
        elif isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and not node.keywords:
            funcs={'lane':_lane,'pack':_pack,'spack':_spack,'signed':_signed,'abs':abs,'min':min,'max':max}
            if node.func.id not in funcs or not 1 <= len(node.args) <= 33:
                raise ValueError('Only lane, pack, spack, signed, abs, min and max calls are supported')
            result=funcs[node.func.id](*(visit(arg) for arg in node.args))
        else:
            raise ValueError(f'Unsupported behavior syntax: {type(node).__name__}')
        if type(result) not in (int,bool) or abs(result).bit_length() > 131072:
            raise ValueError('Behavior result is not a bounded integer')
        return result
    try:
        return int(visit(_parse(expression)))
    except (ZeroDivisionError,TypeError,RecursionError) as exc:
        raise ValueError(f'Behavior evaluation failed for {expression}: {exc}') from exc


def compile_tests(ports, behavior):
    """Generate reset, single-pulse, pipeline-drain and back-to-back checks."""
    if not isinstance(behavior,dict):
        raise ValueError('behavior must be an object')
    ins={p.name:p.width for p in ports if p.direction=='input'}
    outs={p.name:p.width for p in ports if p.direction=='output'}
    latency=behavior.get('latency',0)
    if type(latency) is not int or not 0 <= latency <= 64:
        raise ValueError('Behavior latency must be 0..64')
    valid_in=behavior.get('valid_input')
    valid_out=behavior.get('valid_output')
    reset=behavior.get('reset')
    control={'clock',reset,valid_in}-{None}
    if latency:
        if any(ins.get(n)!=1 for n in ('clock',reset,valid_in)) or outs.get(valid_out)!=1:
            raise ValueError('Pipeline requires one-bit clock/reset/valid_input and valid_output ports')
        if len({'clock',reset,valid_in})!=3:
            raise ValueError('Pipeline control ports must be distinct')
    elif valid_in or valid_out or reset or 'clock' in ins:
        raise ValueError('Combinational behavior has no clock/reset/valid metadata; express data outputs directly')
    data_ins={k:v for k,v in ins.items() if k not in control}
    data_outs={k:v for k,v in outs.items() if k!=valid_out}
    expressions=behavior.get('outputs')
    bindings=behavior.get('let',{})
    if not isinstance(expressions,dict) or set(expressions)!=set(data_outs) or not data_outs:
        raise ValueError('behavior.outputs must define every data output exactly once')
    if not isinstance(bindings,dict) or len(bindings)>256:
        raise ValueError('behavior.let must be an ordered map of at most 256 expressions')
    for name in bindings:
        if not isinstance(name,str) or not name.isidentifier() or name in ins:
            raise ValueError('Invalid/shadowed behavior binding')
    condition=behavior.get('input_condition','1')
    def oracle(vector):
        env=dict(vector)
        for name,expression in bindings.items():
            env[name]=evaluate(expression,env)
        return {name:evaluate(expr,env)&((1<<data_outs[name])-1) for name,expr in expressions.items()}
    raw_vectors=behavior.get('vectors')
    if not isinstance(raw_vectors,list) or not 3 <= len(raw_vectors) <= 12:
        raise ValueError('Provide 3..12 behavior input vectors (zero, boundaries, ordinary cases); no expected values')
    vectors=[]
    for raw in raw_vectors:
        if not isinstance(raw,dict) or set(raw)!=set(data_ins):
            raise ValueError(f'Each behavior vector initializes exactly {sorted(data_ins)}')
        vector={name:evaluate(value,{}) if isinstance(value,str) else value for name,value in raw.items()}
        for name, value in vector.items():
            if type(value) is not int or not 0 <= value < (1 << data_ins[name]):
                raise ValueError(f'Behavior vector {name}={value} exceeds {data_ins[name]}-bit input; '
                                 f'allowed integers 0..{(1 << data_ins[name])-1}. '
                                 'pack(w,...) and spack(w,...) take the width of EACH LANE, not the port. '
                                 f'For N lanes packed into this {data_ins[name]}-bit input, use lane width '
                                 f'{data_ins[name]}/N; e.g. two 4-bit lanes in 8 bits use pack(4,a,b), not pack(8,a,b). '
                                 f'Original expression: {str(raw[name])[:200]}')
        if not evaluate(condition,vector):
            raise ValueError('Explicit behavior vector violates input_condition')
        vectors.append(vector)
    # Measured against the declared model, not samples guessed by the HDL writer.
    bounds=behavior.get('input_bounds',{})
    if not isinstance(bounds,dict) or set(bounds)-set(data_ins):
        raise ValueError('Unknown behavior input_bounds')
    for name,pair in bounds.items():
        if (not isinstance(pair,list) or len(pair)!=2 or any(type(v) is not int for v in pair)
                or not 0<=pair[0]<=pair[1]<(1<<data_ins[name])):
            raise ValueError('Invalid behavior input bounds')
    if any(not lo <= vector[name] <= hi for name,(lo,hi) in bounds.items() for vector in vectors):
        raise ValueError('Explicit vector violates input_bounds')
    rng=random.Random(31)
    for _ in range(2048):
        if len(vectors)>=len(raw_vectors)+12:
            break
        candidate={n:rng.randint(*bounds.get(n,[0,(1<<w)-1])) for n,w in data_ins.items()}
        if evaluate(condition,candidate):
            vectors.append(candidate)
    if len(vectors)<len(raw_vectors)+12:
        raise ValueError('Could not sample 12 legal behavior vectors; review bounds and input_condition')
    if not latency:
        return [{'name':'behavior_combinational','steps':[
            {'inputs':v,'cycles':0,'expected':oracle(v)} for v in vectors]}]
    zeros={n:0 for n in data_ins}
    def scenario(name, transactions):
        pipeline=[None]*latency
        steps=[{'inputs':{reset:1,valid_in:0,**zeros},'cycles':1,
                'expected':{valid_out:0,**{n:0 for n in data_outs}}}]
        for vector in transactions:
            pipeline=[oracle(vector) if vector is not None else None]+pipeline[:-1]
            current=pipeline[-1]
            expected={valid_out:int(current is not None)}
            if current is not None:
                expected.update(current)
            steps.append({'inputs':{reset:0,valid_in:int(vector is not None),**(vector or zeros)},
                          'cycles':1,'expected':expected})
        # Check reset after nonzero activity, not just simulator initial zeros.
        steps.append({'inputs':{reset:1,valid_in:0,**zeros},'cycles':1,
                      'expected':{valid_out:0,**{n:0 for n in data_outs}}})
        return {'name':name,'steps':steps}
    tests=[scenario(f'behavior_isolated_{i}',[v]+[None]*latency) for i,v in enumerate(vectors[:3])]
    # One stream with bubbles and complete drain exercises alignment and throughput.
    stream=[]
    for index,vector in enumerate(vectors):
        stream.append(vector)
        if index%3==2:
            stream.append(None)
    tests.append(scenario('behavior_stream',stream+[None]*latency))
    return tests
