import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val q0 = IO(Input(UInt(4.W)))
  val q1 = IO(Input(UInt(4.W)))
  val k0 = IO(Input(UInt(4.W)))
  val k1 = IO(Input(UInt(4.W)))
  val score = IO(Output(UInt(9.W)))

  // Cast inputs to signed integers for arithmetic
  val q0_s = q0.asSInt
  val q1_s = q1.asSInt
  val k0_s = k0.asSInt
  val k1_s = k1.asSInt

  // Perform signed multiplications. The result of a 4-bit * 4-bit signed mult is 8 bits.
  val prod0 = q0_s * k0_s
  val prod1 = q1_s * k1_s

  // Perform widening addition to produce a 9-bit signed result, preventing overflow.
  // The range is [-112, 128], which fits in 9 signed bits.
  val score_s = prod0 +& prod1

  // Assign to the output, casting back to UInt to represent the 2's complement value.
  score := score_s.asUInt
}
