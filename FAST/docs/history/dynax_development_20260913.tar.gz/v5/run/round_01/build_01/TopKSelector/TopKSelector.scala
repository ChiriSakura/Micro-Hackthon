import chisel3._
import chisel3.util._

class TopKSelector extends RawModule {
  val s0 = IO(Input(SInt(9.W)))
  val s1 = IO(Input(SInt(9.W)))
  val s2 = IO(Input(SInt(9.W)))
  val s3 = IO(Input(SInt(9.W)))
  val k_to_keep = IO(Input(UInt(2.W)))
  val mask = IO(Output(UInt(4.W)))

  // Augment scores with inverted indices for tie-breaking. A smaller original index
  // gets a larger inverted index, making it preferred in case of a score tie.
  // The 9-bit signed score is concatenated with a 2-bit unsigned index, and the
  // result is treated as an 11-bit signed number for comparison.
  // Explicitly use .asUInt as Cat operates on Bits.
  val aug0 = Cat(s0.asUInt, 3.U(2.W)).asSInt
  val aug1 = Cat(s1.asUInt, 2.U(2.W)).asSInt
  val aug2 = Cat(s2.asUInt, 1.U(2.W)).asSInt
  val aug3 = Cat(s3.asUInt, 0.U(2.W)).asSInt

  // Calculate the rank of each score. The rank is the number of other scores
  // that are strictly greater. The comparisons are performed on the augmented values
  // to incorporate the tie-breaking logic. PopCount is used to sum the boolean results.
  val rank0 = PopCount(Seq(aug1 > aug0, aug2 > aug0, aug3 > aug0))
  val rank1 = PopCount(Seq(aug0 > aug1, aug2 > aug1, aug3 > aug1))
  val rank2 = PopCount(Seq(aug0 > aug2, aug1 > aug2, aug3 > aug2))
  val rank3 = PopCount(Seq(aug0 > aug3, aug1 > aug3, aug2 > aug3))

  // An item is selected if its rank is less than the number of items to keep.
  // A rank of 0 means it's the largest, 1 means second largest, and so on.
  val bit0 = rank0 < k_to_keep
  val bit1 = rank1 < k_to_keep
  val bit2 = rank2 < k_to_keep
  val bit3 = rank3 < k_to_keep

  // Concatenate the selection bits to form the final output mask.
  mask := Cat(bit3, bit2, bit1, bit0)
}
