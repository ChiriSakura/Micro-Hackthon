import chisel3._

class ScoreCalculator extends RawModule {
  val q0 = IO(Input(UInt(4.W)))
  val q1 = IO(Input(UInt(4.W)))
  val k0 = IO(Input(UInt(4.W)))
  val k1 = IO(Input(UInt(4.W)))
  val score = IO(Output(UInt(9.W)))

  // Cast 4-bit UInt inputs to 4-bit SInt for signed arithmetic.
  val q0_s = q0.asSInt
  val q1_s = q1.asSInt
  val k0_s = k0.asSInt
  val k1_s = k1.asSInt

  // Perform signed multiplications. The result of a 4-bit * 4-bit signed multiply is an 8-bit SInt.
  val p0 = q0_s * k0_s
  val p1 = q1_s * k1_s

  // Perform a widening signed addition to prevent overflow. The sum of two 8-bit SInts
  // is widened to 9 bits to contain the full range [-112, 128].
  val score_s = p0 +& p1

  // Assign the 9-bit SInt result to the 9-bit UInt output port.
  // .asUInt preserves the bit pattern, which is the expected behavior.
  score := score_s.asUInt
}
