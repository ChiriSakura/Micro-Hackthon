import chisel3._
import chisel3.util._

class TopKSelector extends RawModule {
  val s0 = IO(Input(UInt(9.W)))
  val s1 = IO(Input(UInt(9.W)))
  val s2 = IO(Input(UInt(9.W)))
  val s3 = IO(Input(UInt(9.W)))
  val k_to_keep = IO(Input(UInt(2.W)))
  val mask = IO(Output(UInt(4.W)))

  // Augment scores with inverted indices for tie-breaking.
  // A higher score is better. For ties, a smaller original index is better,
  // which means a larger inverted index (3-i) is better.
  // The augmented value is an 11-bit signed integer.
  // We concatenate the 9-bit score's bit pattern with the 2-bit inverted index and reinterpret as SInt.
  val aug0 = Cat(s0, 3.U(2.W)).asSInt
  val aug1 = Cat(s1, 2.U(2.W)).asSInt
  val aug2 = Cat(s2, 1.U(2.W)).asSInt
  val aug3 = Cat(s3, 0.U(2.W)).asSInt

  // Calculate the rank of each score. Rank is the number of other scores that are strictly greater.
  // Use widening addition (+&) to prevent overflow, as the sum of three 1-bit values can be up to 3.
  val rank0 = (aug1 > aug0).asUInt +& (aug2 > aug0).asUInt +& (aug3 > aug0).asUInt
  val rank1 = (aug0 > aug1).asUInt +& (aug2 > aug1).asUInt +& (aug3 > aug1).asUInt
  val rank2 = (aug0 > aug2).asUInt +& (aug1 > aug2).asUInt +& (aug3 > aug2).asUInt
  val rank3 = (aug0 > aug3).asUInt +& (aug1 > aug3).asUInt +& (aug2 > aug3).asUInt

  // An item is selected if its rank is less than k_to_keep.
  val bit0 = rank0 < k_to_keep
  val bit1 = rank1 < k_to_keep
  val bit2 = rank2 < k_to_keep
  val bit3 = rank3 < k_to_keep

  // Combine the selection bits into the final 4-bit mask.
  mask := Cat(bit3, bit2, bit1, bit0)
}
