module ScoreCalculator(
  input  [3:0] q0, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 5:14]
  input  [3:0] q1, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 6:14]
  input  [3:0] k0, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 7:14]
  input  [3:0] k1, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 8:14]
  output [8:0] score // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 9:17]
);
  wire [7:0] p0 = $signed(q0) * $signed(k0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 18:17]
  wire [7:0] p1 = $signed(q1) * $signed(k1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 19:17]
  assign score = $signed(p0) + $signed(p1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/dynax_autonomous_17702555/round_01/build_03/ScoreCalculator/ScoreCalculator.scala 27:20]
endmodule
