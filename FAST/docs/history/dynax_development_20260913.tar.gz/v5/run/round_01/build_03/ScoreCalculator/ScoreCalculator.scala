import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val q0 = IO(Input(UInt(4.W)))
  val q1 = IO(Input(UInt(4.W)))
  val k0 = IO(Input(UInt(4.W)))
  val k1 = IO(Input(UInt(4.W)))
  val score = IO(Output(UInt(9.W)))

  // Cast 4-bit UInt inputs to 4-bit SInt for signed arithmetic.
  val q0_s = q0.asSInt
  val q1_s = q1.asSInt
  val k0_s = k0.asSInt
  val k1_s = k1.asSInt

  // The product of two 4-bit signed numbers is an 8-bit signed number.
  val p0 = q0_s * k0_s
  val p1 = q1_s * k1_s

  // The sum of two 8-bit signed products requires a wider result to prevent overflow.
  // The range is [-112, 128], which fits in 9 bits.
  // The widening adder `+&` correctly produces a 9-bit signed result.
  val score_s = p0 +& p1

  // Assign the 9-bit signed result to the 9-bit UInt output port.
  score := score_s.asUInt
}
