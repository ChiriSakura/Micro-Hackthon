import chisel3._
import chisel3.experimental._
import predict_unit.FixedPointDivPipelined
class NativeDividerProbe extends RawModule {
 val clock = IO(Input(Clock()))
 val reset = IO(Input(Bool()))
 val numerator = IO(Input(UInt(27.W)))
 val denominator = IO(Input(UInt(19.W)))
 val iv = IO(Input(Bool()))
 val ov = IO(Output(Bool()))
 val quotient = IO(Output(UInt(16.W)))
 withClockAndReset(clock, reset) {
  val core = Module(new FixedPointDivPipelined(bitWidth=27, point=4, stages=21))
  core.io.numerator := numerator.asSInt.asFixedPoint(4.BP)
  core.io.denominator := denominator.zext.pad(27).asFixedPoint(4.BP)
  core.io.in_valid := iv
  ov := core.io.out_valid
  quotient := core.io.quotient.asUInt(15,0)
 }
}
