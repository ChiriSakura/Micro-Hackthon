module FixedPointDivPipelined(
  input         clock,
  input         reset,
  input         io_in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 55:14]
  input  [26:0] io_numerator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 55:14]
  input  [26:0] io_denominator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 55:14]
  output        io_out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 55:14]
  output [26:0] io_quotient // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 55:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [31:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [31:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
  reg [31:0] _RAND_63;
  reg [31:0] _RAND_64;
  reg [31:0] _RAND_65;
  reg [31:0] _RAND_66;
  reg [31:0] _RAND_67;
  reg [31:0] _RAND_68;
  reg [31:0] _RAND_69;
  reg [31:0] _RAND_70;
  reg [31:0] _RAND_71;
  reg [31:0] _RAND_72;
  reg [31:0] _RAND_73;
  reg [31:0] _RAND_74;
  reg [31:0] _RAND_75;
  reg [31:0] _RAND_76;
  reg [31:0] _RAND_77;
  reg [31:0] _RAND_78;
  reg [31:0] _RAND_79;
  reg [31:0] _RAND_80;
  reg [31:0] _RAND_81;
  reg [31:0] _RAND_82;
  reg [31:0] _RAND_83;
  reg [31:0] _RAND_84;
  reg [31:0] _RAND_85;
  reg [31:0] _RAND_86;
  reg [31:0] _RAND_87;
  reg [31:0] _RAND_88;
  reg [31:0] _RAND_89;
  reg [31:0] _RAND_90;
  reg [31:0] _RAND_91;
  reg [31:0] _RAND_92;
  reg [31:0] _RAND_93;
  reg [31:0] _RAND_94;
  reg [31:0] _RAND_95;
  reg [31:0] _RAND_96;
  reg [31:0] _RAND_97;
  reg [31:0] _RAND_98;
  reg [31:0] _RAND_99;
  reg [31:0] _RAND_100;
  reg [31:0] _RAND_101;
  reg [31:0] _RAND_102;
  reg [31:0] _RAND_103;
  reg [31:0] _RAND_104;
  reg [31:0] _RAND_105;
  reg [31:0] _RAND_106;
  reg [31:0] _RAND_107;
  reg [31:0] _RAND_108;
  reg [31:0] _RAND_109;
  reg [31:0] _RAND_110;
  reg [31:0] _RAND_111;
  reg [31:0] _RAND_112;
  reg [31:0] _RAND_113;
  reg [31:0] _RAND_114;
  reg [31:0] _RAND_115;
  reg [31:0] _RAND_116;
  reg [31:0] _RAND_117;
  reg [31:0] _RAND_118;
  reg [31:0] _RAND_119;
  reg [31:0] _RAND_120;
  reg [31:0] _RAND_121;
  reg [31:0] _RAND_122;
  reg [31:0] _RAND_123;
  reg [31:0] _RAND_124;
  reg [31:0] _RAND_125;
  reg [31:0] _RAND_126;
  reg [31:0] _RAND_127;
  reg [31:0] _RAND_128;
`endif // RANDOMIZE_REG_INIT
  wire  _initial_dividend_T = $signed(io_numerator) < 27'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 90:35]
  wire [26:0] _initial_dividend_T_3 = 27'sh0 - $signed(io_numerator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 90:35]
  wire [26:0] _initial_dividend_T_5 = $signed(io_numerator) < 27'sh0 ? $signed(_initial_dividend_T_3) : $signed(
    io_numerator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 90:39]
  wire [30:0] initial_dividend = {_initial_dividend_T_5, 4'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 90:46]
  wire  _initial_divisor_T = $signed(io_denominator) < 27'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 91:35]
  wire [26:0] _initial_divisor_T_3 = 27'sh0 - $signed(io_denominator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 91:35]
  wire [26:0] initial_divisor = $signed(io_denominator) < 27'sh0 ? $signed(_initial_divisor_T_3) : $signed(
    io_denominator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 91:39]
  wire  initial_negative = _initial_dividend_T ^ _initial_divisor_T; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 92:42]
  wire  initial_divideByZero = $signed(io_denominator) == 27'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 93:40]
  wire [27:0] shifted = {27'h0,initial_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_0 = {{1'd0}, initial_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial = shifted - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits = shifted >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_remainder = fits ? trial[27:0] : shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_quotient = {30'h0,fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_dividend = {initial_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_1 = {next_remainder[26:0],next_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_1 = shifted_1 - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_1 = shifted_1 >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_1_quotient = {next_quotient[29:0],fits_1}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_1_dividend = {next_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_2 = {REG_remainder[26:0],REG_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_4 = {{1'd0}, REG_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_2 = shifted_2 - _GEN_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_2 = shifted_2 >= _GEN_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_2_remainder = fits_2 ? trial_2[27:0] : shifted_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_2_quotient = {REG_quotient[29:0],fits_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_2_dividend = {REG_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_3 = {next_2_remainder[26:0],next_2_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_3 = shifted_3 - _GEN_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_3 = shifted_3 >= _GEN_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_3_quotient = {next_2_quotient[29:0],fits_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_3_dividend = {next_2_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_1_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_1_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_4 = {REG_1_remainder[26:0],REG_1_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_8 = {{1'd0}, REG_1_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_4 = shifted_4 - _GEN_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_4 = shifted_4 >= _GEN_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_4_remainder = fits_4 ? trial_4[27:0] : shifted_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_4_quotient = {REG_1_quotient[29:0],fits_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_4_dividend = {REG_1_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_5 = {next_4_remainder[26:0],next_4_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_5 = shifted_5 - _GEN_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_5 = shifted_5 >= _GEN_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_5_quotient = {next_4_quotient[29:0],fits_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_5_dividend = {next_4_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_2_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_2_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_6 = {REG_2_remainder[26:0],REG_2_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_12 = {{1'd0}, REG_2_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_6 = shifted_6 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_6 = shifted_6 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_6_remainder = fits_6 ? trial_6[27:0] : shifted_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_6_quotient = {REG_2_quotient[29:0],fits_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_6_dividend = {REG_2_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_7 = {next_6_remainder[26:0],next_6_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_7 = shifted_7 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_7 = shifted_7 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_7_quotient = {next_6_quotient[29:0],fits_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_7_dividend = {next_6_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_3_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_3_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_8 = {REG_3_remainder[26:0],REG_3_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_16 = {{1'd0}, REG_3_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_8 = shifted_8 - _GEN_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_8 = shifted_8 >= _GEN_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_8_remainder = fits_8 ? trial_8[27:0] : shifted_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_8_quotient = {REG_3_quotient[29:0],fits_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_8_dividend = {REG_3_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_9 = {next_8_remainder[26:0],next_8_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_9 = shifted_9 - _GEN_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_9 = shifted_9 >= _GEN_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_9_quotient = {next_8_quotient[29:0],fits_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_9_dividend = {next_8_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_4_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_4_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_4_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_10 = {REG_4_remainder[26:0],REG_4_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_20 = {{1'd0}, REG_4_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_10 = shifted_10 - _GEN_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_10 = shifted_10 >= _GEN_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_10_remainder = fits_10 ? trial_10[27:0] : shifted_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_10_quotient = {REG_4_quotient[29:0],fits_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_10_dividend = {REG_4_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_11 = {next_10_remainder[26:0],next_10_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_11 = shifted_11 - _GEN_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_11 = shifted_11 >= _GEN_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_11_quotient = {next_10_quotient[29:0],fits_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_11_dividend = {next_10_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_5_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_5_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_5_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_12 = {REG_5_remainder[26:0],REG_5_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_24 = {{1'd0}, REG_5_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_12 = shifted_12 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_12 = shifted_12 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_12_remainder = fits_12 ? trial_12[27:0] : shifted_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_12_quotient = {REG_5_quotient[29:0],fits_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_12_dividend = {REG_5_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_13 = {next_12_remainder[26:0],next_12_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_13 = shifted_13 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_13 = shifted_13 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_13_quotient = {next_12_quotient[29:0],fits_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_13_dividend = {next_12_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_6_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_6_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_6_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_14 = {REG_6_remainder[26:0],REG_6_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_28 = {{1'd0}, REG_6_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_14 = shifted_14 - _GEN_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_14 = shifted_14 >= _GEN_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_14_remainder = fits_14 ? trial_14[27:0] : shifted_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_14_quotient = {REG_6_quotient[29:0],fits_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_14_dividend = {REG_6_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_15 = {next_14_remainder[26:0],next_14_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_15 = shifted_15 - _GEN_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_15 = shifted_15 >= _GEN_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_15_quotient = {next_14_quotient[29:0],fits_15}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_15_dividend = {next_14_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_7_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_7_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_7_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_16 = {REG_7_remainder[26:0],REG_7_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_32 = {{1'd0}, REG_7_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_16 = shifted_16 - _GEN_32; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_16 = shifted_16 >= _GEN_32; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_16_remainder = fits_16 ? trial_16[27:0] : shifted_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_16_quotient = {REG_7_quotient[29:0],fits_16}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_16_dividend = {REG_7_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_17 = {next_16_remainder[26:0],next_16_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_17 = shifted_17 - _GEN_32; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_17 = shifted_17 >= _GEN_32; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_17_quotient = {next_16_quotient[29:0],fits_17}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_17_dividend = {next_16_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_8_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_8_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_8_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_18 = {REG_8_remainder[26:0],REG_8_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_36 = {{1'd0}, REG_8_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_18 = shifted_18 - _GEN_36; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_18 = shifted_18 >= _GEN_36; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_18_remainder = fits_18 ? trial_18[27:0] : shifted_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_18_quotient = {REG_8_quotient[29:0],fits_18}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_18_dividend = {REG_8_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_19 = {next_18_remainder[26:0],next_18_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_19 = shifted_19 - _GEN_36; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_19 = shifted_19 >= _GEN_36; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_19_quotient = {next_18_quotient[29:0],fits_19}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_19_dividend = {next_18_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_9_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_9_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_9_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_20 = {REG_9_remainder[26:0],REG_9_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_40 = {{1'd0}, REG_9_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_20 = shifted_20 - _GEN_40; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_20 = shifted_20 >= _GEN_40; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_20_remainder = fits_20 ? trial_20[27:0] : shifted_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_20_quotient = {REG_9_quotient[29:0],fits_20}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_20_dividend = {REG_9_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_21 = {next_20_remainder[26:0],next_20_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_21 = shifted_21 - _GEN_40; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_21 = shifted_21 >= _GEN_40; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_21_quotient = {next_20_quotient[29:0],fits_21}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_21_dividend = {next_20_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_10_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_10_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_10_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_22 = {REG_10_remainder[26:0],REG_10_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_44 = {{1'd0}, REG_10_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_22 = shifted_22 - _GEN_44; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_22 = shifted_22 >= _GEN_44; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_22_remainder = fits_22 ? trial_22[27:0] : shifted_22; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_22_quotient = {REG_10_quotient[29:0],fits_22}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_22_dividend = {REG_10_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_23 = {next_22_remainder[26:0],next_22_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_23 = shifted_23 - _GEN_44; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_23 = shifted_23 >= _GEN_44; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_23_quotient = {next_22_quotient[29:0],fits_23}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_23_dividend = {next_22_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_11_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_11_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_11_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_24 = {REG_11_remainder[26:0],REG_11_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_48 = {{1'd0}, REG_11_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_24 = shifted_24 - _GEN_48; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_24 = shifted_24 >= _GEN_48; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_24_remainder = fits_24 ? trial_24[27:0] : shifted_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_24_quotient = {REG_11_quotient[29:0],fits_24}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_24_dividend = {REG_11_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_25 = {next_24_remainder[26:0],next_24_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_25 = shifted_25 - _GEN_48; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_25 = shifted_25 >= _GEN_48; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_25_quotient = {next_24_quotient[29:0],fits_25}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_25_dividend = {next_24_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_12_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_12_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_12_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_26 = {REG_12_remainder[26:0],REG_12_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_52 = {{1'd0}, REG_12_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_26 = shifted_26 - _GEN_52; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_26 = shifted_26 >= _GEN_52; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_26_remainder = fits_26 ? trial_26[27:0] : shifted_26; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_26_quotient = {REG_12_quotient[29:0],fits_26}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_26_dividend = {REG_12_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_27 = {next_26_remainder[26:0],next_26_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_27 = shifted_27 - _GEN_52; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_27 = shifted_27 >= _GEN_52; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_27_quotient = {next_26_quotient[29:0],fits_27}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_27_dividend = {next_26_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_13_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_13_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_13_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_28 = {REG_13_remainder[26:0],REG_13_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_56 = {{1'd0}, REG_13_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire [28:0] trial_28 = shifted_28 - _GEN_56; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_28 = shifted_28 >= _GEN_56; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [27:0] next_28_remainder = fits_28 ? trial_28[27:0] : shifted_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
  wire [30:0] next_28_quotient = {REG_13_quotient[29:0],fits_28}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_28_dividend = {REG_13_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  wire [27:0] shifted_29 = {next_28_remainder[26:0],next_28_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [28:0] trial_29 = shifted_29 - _GEN_56; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_29 = shifted_29 >= _GEN_56; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_29_quotient = {next_28_quotient[29:0],fits_29}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  wire [30:0] next_29_dividend = {next_28_dividend[29:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 108:25]
  reg [27:0] REG_14_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_14_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_14_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [26:0] REG_14_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_14_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_14_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_14_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [27:0] shifted_30 = {REG_14_remainder[26:0],REG_14_dividend[30]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 101:22]
  wire [27:0] _GEN_60 = {{1'd0}, REG_14_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 102:32]
  wire  fits_30 = shifted_30 >= _GEN_60; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 103:31]
  wire [30:0] next_30_quotient = {REG_14_quotient[29:0],fits_30}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 106:25]
  reg [30:0] REG_15_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_15_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_15_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_15_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_16_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_16_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_16_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_16_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_17_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_17_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_17_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_17_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_18_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_18_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_18_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_18_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_19_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_19_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_19_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_19_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg [30:0] REG_20_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_20_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_20_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  reg  REG_20_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
  wire [30:0] _signed_T_3 = 31'sh0 - $signed(REG_20_quotient); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 127:50]
  wire [30:0] signed_ = REG_20_negative ? $signed(_signed_T_3) : $signed(REG_20_quotient); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 127:27]
  wire [30:0] result = REG_20_divideByZero ? $signed(31'sh0) : $signed(signed_); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 128:27]
  assign io_out_valid = REG_20_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 130:16]
  assign io_quotient = result[26:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 131:54]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_1) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_remainder <= trial_1[27:0];
    end else begin
      REG_remainder <= shifted_1;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_quotient <= next_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_dividend <= next_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_divisor <= initial_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_negative <= initial_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_divideByZero <= initial_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_valid <= io_in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_1_remainder <= trial_3[27:0];
    end else begin
      REG_1_remainder <= shifted_3;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_1_quotient <= next_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_1_dividend <= next_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_1_divisor <= REG_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_1_negative <= REG_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_1_divideByZero <= REG_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_1_valid <= REG_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_2_remainder <= trial_5[27:0];
    end else begin
      REG_2_remainder <= shifted_5;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_2_quotient <= next_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_2_dividend <= next_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_2_divisor <= REG_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_2_negative <= REG_1_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_2_divideByZero <= REG_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_2_valid <= REG_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_7) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_3_remainder <= trial_7[27:0];
    end else begin
      REG_3_remainder <= shifted_7;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_3_quotient <= next_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_3_dividend <= next_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_3_divisor <= REG_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_3_negative <= REG_2_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_3_divideByZero <= REG_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_3_valid <= REG_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_9) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_4_remainder <= trial_9[27:0];
    end else begin
      REG_4_remainder <= shifted_9;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_4_quotient <= next_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_4_dividend <= next_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_4_divisor <= REG_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_4_negative <= REG_3_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_4_divideByZero <= REG_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_4_valid <= REG_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_5_remainder <= trial_11[27:0];
    end else begin
      REG_5_remainder <= shifted_11;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_5_quotient <= next_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_5_dividend <= next_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_5_divisor <= REG_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_5_negative <= REG_4_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_5_divideByZero <= REG_4_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_5_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_5_valid <= REG_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_13) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_6_remainder <= trial_13[27:0];
    end else begin
      REG_6_remainder <= shifted_13;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_6_quotient <= next_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_6_dividend <= next_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_6_divisor <= REG_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_6_negative <= REG_5_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_6_divideByZero <= REG_5_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_6_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_6_valid <= REG_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_15) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_7_remainder <= trial_15[27:0];
    end else begin
      REG_7_remainder <= shifted_15;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_7_quotient <= next_15_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_7_dividend <= next_15_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_7_divisor <= REG_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_7_negative <= REG_6_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_7_divideByZero <= REG_6_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_7_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_7_valid <= REG_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_17) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_8_remainder <= trial_17[27:0];
    end else begin
      REG_8_remainder <= shifted_17;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_8_quotient <= next_17_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_8_dividend <= next_17_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_8_divisor <= REG_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_8_negative <= REG_7_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_8_divideByZero <= REG_7_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_8_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_8_valid <= REG_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_19) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_9_remainder <= trial_19[27:0];
    end else begin
      REG_9_remainder <= shifted_19;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_9_quotient <= next_19_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_9_dividend <= next_19_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_9_divisor <= REG_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_9_negative <= REG_8_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_9_divideByZero <= REG_8_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_9_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_9_valid <= REG_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_21) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_10_remainder <= trial_21[27:0];
    end else begin
      REG_10_remainder <= shifted_21;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_10_quotient <= next_21_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_10_dividend <= next_21_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_10_divisor <= REG_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_10_negative <= REG_9_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_10_divideByZero <= REG_9_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_10_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_10_valid <= REG_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_23) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_11_remainder <= trial_23[27:0];
    end else begin
      REG_11_remainder <= shifted_23;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_11_quotient <= next_23_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_11_dividend <= next_23_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_11_divisor <= REG_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_11_negative <= REG_10_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_11_divideByZero <= REG_10_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_11_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_11_valid <= REG_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_25) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_12_remainder <= trial_25[27:0];
    end else begin
      REG_12_remainder <= shifted_25;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_12_quotient <= next_25_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_12_dividend <= next_25_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_12_divisor <= REG_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_12_negative <= REG_11_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_12_divideByZero <= REG_11_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_12_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_12_valid <= REG_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_27) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_13_remainder <= trial_27[27:0];
    end else begin
      REG_13_remainder <= shifted_27;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_13_quotient <= next_27_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_13_dividend <= next_27_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_13_divisor <= REG_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_13_negative <= REG_12_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_13_divideByZero <= REG_12_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_13_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_13_valid <= REG_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_remainder <= 28'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else if (fits_29) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 105:26]
      REG_14_remainder <= trial_29[27:0];
    end else begin
      REG_14_remainder <= shifted_29;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_14_quotient <= next_29_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_dividend <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_14_dividend <= next_29_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_divisor <= 27'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_14_divisor <= REG_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_14_negative <= REG_13_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_14_divideByZero <= REG_13_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_14_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_14_valid <= REG_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_15_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_15_quotient <= next_30_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_15_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_15_negative <= REG_14_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_15_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_15_divideByZero <= REG_14_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_15_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_15_valid <= REG_14_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_16_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_16_quotient <= REG_15_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_16_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_16_negative <= REG_15_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_16_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_16_divideByZero <= REG_15_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_16_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_16_valid <= REG_15_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_17_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_17_quotient <= REG_16_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_17_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_17_negative <= REG_16_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_17_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_17_divideByZero <= REG_16_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_17_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_17_valid <= REG_16_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_18_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_18_quotient <= REG_17_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_18_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_18_negative <= REG_17_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_18_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_18_divideByZero <= REG_17_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_18_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_18_valid <= REG_17_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_19_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_19_quotient <= REG_18_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_19_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_19_negative <= REG_18_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_19_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_19_divideByZero <= REG_18_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_19_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_19_valid <= REG_18_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_20_quotient <= 31'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_20_quotient <= REG_19_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_20_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_20_negative <= REG_19_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_20_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_20_divideByZero <= REG_19_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
      REG_20_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end else begin
      REG_20_valid <= REG_19_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/references/004.scala 121:22]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  REG_remainder = _RAND_0[27:0];
  _RAND_1 = {1{`RANDOM}};
  REG_quotient = _RAND_1[30:0];
  _RAND_2 = {1{`RANDOM}};
  REG_dividend = _RAND_2[30:0];
  _RAND_3 = {1{`RANDOM}};
  REG_divisor = _RAND_3[26:0];
  _RAND_4 = {1{`RANDOM}};
  REG_negative = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  REG_divideByZero = _RAND_5[0:0];
  _RAND_6 = {1{`RANDOM}};
  REG_valid = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  REG_1_remainder = _RAND_7[27:0];
  _RAND_8 = {1{`RANDOM}};
  REG_1_quotient = _RAND_8[30:0];
  _RAND_9 = {1{`RANDOM}};
  REG_1_dividend = _RAND_9[30:0];
  _RAND_10 = {1{`RANDOM}};
  REG_1_divisor = _RAND_10[26:0];
  _RAND_11 = {1{`RANDOM}};
  REG_1_negative = _RAND_11[0:0];
  _RAND_12 = {1{`RANDOM}};
  REG_1_divideByZero = _RAND_12[0:0];
  _RAND_13 = {1{`RANDOM}};
  REG_1_valid = _RAND_13[0:0];
  _RAND_14 = {1{`RANDOM}};
  REG_2_remainder = _RAND_14[27:0];
  _RAND_15 = {1{`RANDOM}};
  REG_2_quotient = _RAND_15[30:0];
  _RAND_16 = {1{`RANDOM}};
  REG_2_dividend = _RAND_16[30:0];
  _RAND_17 = {1{`RANDOM}};
  REG_2_divisor = _RAND_17[26:0];
  _RAND_18 = {1{`RANDOM}};
  REG_2_negative = _RAND_18[0:0];
  _RAND_19 = {1{`RANDOM}};
  REG_2_divideByZero = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  REG_2_valid = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  REG_3_remainder = _RAND_21[27:0];
  _RAND_22 = {1{`RANDOM}};
  REG_3_quotient = _RAND_22[30:0];
  _RAND_23 = {1{`RANDOM}};
  REG_3_dividend = _RAND_23[30:0];
  _RAND_24 = {1{`RANDOM}};
  REG_3_divisor = _RAND_24[26:0];
  _RAND_25 = {1{`RANDOM}};
  REG_3_negative = _RAND_25[0:0];
  _RAND_26 = {1{`RANDOM}};
  REG_3_divideByZero = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  REG_3_valid = _RAND_27[0:0];
  _RAND_28 = {1{`RANDOM}};
  REG_4_remainder = _RAND_28[27:0];
  _RAND_29 = {1{`RANDOM}};
  REG_4_quotient = _RAND_29[30:0];
  _RAND_30 = {1{`RANDOM}};
  REG_4_dividend = _RAND_30[30:0];
  _RAND_31 = {1{`RANDOM}};
  REG_4_divisor = _RAND_31[26:0];
  _RAND_32 = {1{`RANDOM}};
  REG_4_negative = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  REG_4_divideByZero = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  REG_4_valid = _RAND_34[0:0];
  _RAND_35 = {1{`RANDOM}};
  REG_5_remainder = _RAND_35[27:0];
  _RAND_36 = {1{`RANDOM}};
  REG_5_quotient = _RAND_36[30:0];
  _RAND_37 = {1{`RANDOM}};
  REG_5_dividend = _RAND_37[30:0];
  _RAND_38 = {1{`RANDOM}};
  REG_5_divisor = _RAND_38[26:0];
  _RAND_39 = {1{`RANDOM}};
  REG_5_negative = _RAND_39[0:0];
  _RAND_40 = {1{`RANDOM}};
  REG_5_divideByZero = _RAND_40[0:0];
  _RAND_41 = {1{`RANDOM}};
  REG_5_valid = _RAND_41[0:0];
  _RAND_42 = {1{`RANDOM}};
  REG_6_remainder = _RAND_42[27:0];
  _RAND_43 = {1{`RANDOM}};
  REG_6_quotient = _RAND_43[30:0];
  _RAND_44 = {1{`RANDOM}};
  REG_6_dividend = _RAND_44[30:0];
  _RAND_45 = {1{`RANDOM}};
  REG_6_divisor = _RAND_45[26:0];
  _RAND_46 = {1{`RANDOM}};
  REG_6_negative = _RAND_46[0:0];
  _RAND_47 = {1{`RANDOM}};
  REG_6_divideByZero = _RAND_47[0:0];
  _RAND_48 = {1{`RANDOM}};
  REG_6_valid = _RAND_48[0:0];
  _RAND_49 = {1{`RANDOM}};
  REG_7_remainder = _RAND_49[27:0];
  _RAND_50 = {1{`RANDOM}};
  REG_7_quotient = _RAND_50[30:0];
  _RAND_51 = {1{`RANDOM}};
  REG_7_dividend = _RAND_51[30:0];
  _RAND_52 = {1{`RANDOM}};
  REG_7_divisor = _RAND_52[26:0];
  _RAND_53 = {1{`RANDOM}};
  REG_7_negative = _RAND_53[0:0];
  _RAND_54 = {1{`RANDOM}};
  REG_7_divideByZero = _RAND_54[0:0];
  _RAND_55 = {1{`RANDOM}};
  REG_7_valid = _RAND_55[0:0];
  _RAND_56 = {1{`RANDOM}};
  REG_8_remainder = _RAND_56[27:0];
  _RAND_57 = {1{`RANDOM}};
  REG_8_quotient = _RAND_57[30:0];
  _RAND_58 = {1{`RANDOM}};
  REG_8_dividend = _RAND_58[30:0];
  _RAND_59 = {1{`RANDOM}};
  REG_8_divisor = _RAND_59[26:0];
  _RAND_60 = {1{`RANDOM}};
  REG_8_negative = _RAND_60[0:0];
  _RAND_61 = {1{`RANDOM}};
  REG_8_divideByZero = _RAND_61[0:0];
  _RAND_62 = {1{`RANDOM}};
  REG_8_valid = _RAND_62[0:0];
  _RAND_63 = {1{`RANDOM}};
  REG_9_remainder = _RAND_63[27:0];
  _RAND_64 = {1{`RANDOM}};
  REG_9_quotient = _RAND_64[30:0];
  _RAND_65 = {1{`RANDOM}};
  REG_9_dividend = _RAND_65[30:0];
  _RAND_66 = {1{`RANDOM}};
  REG_9_divisor = _RAND_66[26:0];
  _RAND_67 = {1{`RANDOM}};
  REG_9_negative = _RAND_67[0:0];
  _RAND_68 = {1{`RANDOM}};
  REG_9_divideByZero = _RAND_68[0:0];
  _RAND_69 = {1{`RANDOM}};
  REG_9_valid = _RAND_69[0:0];
  _RAND_70 = {1{`RANDOM}};
  REG_10_remainder = _RAND_70[27:0];
  _RAND_71 = {1{`RANDOM}};
  REG_10_quotient = _RAND_71[30:0];
  _RAND_72 = {1{`RANDOM}};
  REG_10_dividend = _RAND_72[30:0];
  _RAND_73 = {1{`RANDOM}};
  REG_10_divisor = _RAND_73[26:0];
  _RAND_74 = {1{`RANDOM}};
  REG_10_negative = _RAND_74[0:0];
  _RAND_75 = {1{`RANDOM}};
  REG_10_divideByZero = _RAND_75[0:0];
  _RAND_76 = {1{`RANDOM}};
  REG_10_valid = _RAND_76[0:0];
  _RAND_77 = {1{`RANDOM}};
  REG_11_remainder = _RAND_77[27:0];
  _RAND_78 = {1{`RANDOM}};
  REG_11_quotient = _RAND_78[30:0];
  _RAND_79 = {1{`RANDOM}};
  REG_11_dividend = _RAND_79[30:0];
  _RAND_80 = {1{`RANDOM}};
  REG_11_divisor = _RAND_80[26:0];
  _RAND_81 = {1{`RANDOM}};
  REG_11_negative = _RAND_81[0:0];
  _RAND_82 = {1{`RANDOM}};
  REG_11_divideByZero = _RAND_82[0:0];
  _RAND_83 = {1{`RANDOM}};
  REG_11_valid = _RAND_83[0:0];
  _RAND_84 = {1{`RANDOM}};
  REG_12_remainder = _RAND_84[27:0];
  _RAND_85 = {1{`RANDOM}};
  REG_12_quotient = _RAND_85[30:0];
  _RAND_86 = {1{`RANDOM}};
  REG_12_dividend = _RAND_86[30:0];
  _RAND_87 = {1{`RANDOM}};
  REG_12_divisor = _RAND_87[26:0];
  _RAND_88 = {1{`RANDOM}};
  REG_12_negative = _RAND_88[0:0];
  _RAND_89 = {1{`RANDOM}};
  REG_12_divideByZero = _RAND_89[0:0];
  _RAND_90 = {1{`RANDOM}};
  REG_12_valid = _RAND_90[0:0];
  _RAND_91 = {1{`RANDOM}};
  REG_13_remainder = _RAND_91[27:0];
  _RAND_92 = {1{`RANDOM}};
  REG_13_quotient = _RAND_92[30:0];
  _RAND_93 = {1{`RANDOM}};
  REG_13_dividend = _RAND_93[30:0];
  _RAND_94 = {1{`RANDOM}};
  REG_13_divisor = _RAND_94[26:0];
  _RAND_95 = {1{`RANDOM}};
  REG_13_negative = _RAND_95[0:0];
  _RAND_96 = {1{`RANDOM}};
  REG_13_divideByZero = _RAND_96[0:0];
  _RAND_97 = {1{`RANDOM}};
  REG_13_valid = _RAND_97[0:0];
  _RAND_98 = {1{`RANDOM}};
  REG_14_remainder = _RAND_98[27:0];
  _RAND_99 = {1{`RANDOM}};
  REG_14_quotient = _RAND_99[30:0];
  _RAND_100 = {1{`RANDOM}};
  REG_14_dividend = _RAND_100[30:0];
  _RAND_101 = {1{`RANDOM}};
  REG_14_divisor = _RAND_101[26:0];
  _RAND_102 = {1{`RANDOM}};
  REG_14_negative = _RAND_102[0:0];
  _RAND_103 = {1{`RANDOM}};
  REG_14_divideByZero = _RAND_103[0:0];
  _RAND_104 = {1{`RANDOM}};
  REG_14_valid = _RAND_104[0:0];
  _RAND_105 = {1{`RANDOM}};
  REG_15_quotient = _RAND_105[30:0];
  _RAND_106 = {1{`RANDOM}};
  REG_15_negative = _RAND_106[0:0];
  _RAND_107 = {1{`RANDOM}};
  REG_15_divideByZero = _RAND_107[0:0];
  _RAND_108 = {1{`RANDOM}};
  REG_15_valid = _RAND_108[0:0];
  _RAND_109 = {1{`RANDOM}};
  REG_16_quotient = _RAND_109[30:0];
  _RAND_110 = {1{`RANDOM}};
  REG_16_negative = _RAND_110[0:0];
  _RAND_111 = {1{`RANDOM}};
  REG_16_divideByZero = _RAND_111[0:0];
  _RAND_112 = {1{`RANDOM}};
  REG_16_valid = _RAND_112[0:0];
  _RAND_113 = {1{`RANDOM}};
  REG_17_quotient = _RAND_113[30:0];
  _RAND_114 = {1{`RANDOM}};
  REG_17_negative = _RAND_114[0:0];
  _RAND_115 = {1{`RANDOM}};
  REG_17_divideByZero = _RAND_115[0:0];
  _RAND_116 = {1{`RANDOM}};
  REG_17_valid = _RAND_116[0:0];
  _RAND_117 = {1{`RANDOM}};
  REG_18_quotient = _RAND_117[30:0];
  _RAND_118 = {1{`RANDOM}};
  REG_18_negative = _RAND_118[0:0];
  _RAND_119 = {1{`RANDOM}};
  REG_18_divideByZero = _RAND_119[0:0];
  _RAND_120 = {1{`RANDOM}};
  REG_18_valid = _RAND_120[0:0];
  _RAND_121 = {1{`RANDOM}};
  REG_19_quotient = _RAND_121[30:0];
  _RAND_122 = {1{`RANDOM}};
  REG_19_negative = _RAND_122[0:0];
  _RAND_123 = {1{`RANDOM}};
  REG_19_divideByZero = _RAND_123[0:0];
  _RAND_124 = {1{`RANDOM}};
  REG_19_valid = _RAND_124[0:0];
  _RAND_125 = {1{`RANDOM}};
  REG_20_quotient = _RAND_125[30:0];
  _RAND_126 = {1{`RANDOM}};
  REG_20_negative = _RAND_126[0:0];
  _RAND_127 = {1{`RANDOM}};
  REG_20_divideByZero = _RAND_127[0:0];
  _RAND_128 = {1{`RANDOM}};
  REG_20_valid = _RAND_128[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module NativeDividerProbe(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 5:16]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 6:16]
  input  [26:0] numerator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 7:20]
  input  [18:0] denominator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 8:22]
  input         iv, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 9:13]
  output        ov, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 10:13]
  output [15:0] quotient // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 11:19]
);
  wire  core_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire  core_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire  core_io_in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire [26:0] core_io_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire [26:0] core_io_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire  core_io_out_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire [26:0] core_io_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
  wire [19:0] _core_io_denominator_T = {1'b0,$signed(denominator)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 15:38]
  wire [26:0] _quotient_T = core_io_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 18:32]
  FixedPointDivPipelined core ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 13:20]
    .clock(core_clock),
    .reset(core_reset),
    .io_in_valid(core_io_in_valid),
    .io_numerator(core_io_numerator),
    .io_denominator(core_io_denominator),
    .io_out_valid(core_io_out_valid),
    .io_quotient(core_io_quotient)
  );
  assign ov = core_io_out_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 17:6]
  assign quotient = _quotient_T[15:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 18:38]
  assign core_clock = clock;
  assign core_reset = reset;
  assign core_io_in_valid = iv; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 16:20]
  assign core_io_numerator = numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 14:34]
  assign core_io_denominator = {{7{_core_io_denominator_T[19]}},_core_io_denominator_T}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/native_divider_probe_17705014/NativeDividerProbe.scala 15:46]
endmodule
