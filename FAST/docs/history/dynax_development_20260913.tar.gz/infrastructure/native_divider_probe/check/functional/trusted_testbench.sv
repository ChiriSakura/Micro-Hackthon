module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [26:0] numerator;
reg [18:0] denominator;
reg [0:0] iv;
wire [0:0] ov;
wire [15:0] quotient;
NativeDividerProbe dut(.clock(clock),.reset(reset),.numerator(numerator),.denominator(denominator),.iv(iv),.ov(ov),.quotient(quotient));
initial begin
clock=0;
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=0 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=0 step=0 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd1;
numerator=27'd134216728;
denominator=19'd10;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=3 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=5 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=6 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=7 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=8 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=9 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=10 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=11 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=12 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=13 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=14 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=15 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=16 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=17 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=18 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=19 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=20 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=0 step=21 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd63936) $fatal(1,"module case=0 step=21 output=quotient expected=63936 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=22 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=23 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=0 step=23 output=quotient expected=0 actual=%0d",quotient);
$display("FAST_CASE cycles=1");
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=0 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=1 step=0 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd1;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=3 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=5 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=6 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=7 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=8 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=9 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=10 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=11 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=12 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=13 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=14 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=15 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=16 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=17 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=18 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=19 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=20 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=1 step=21 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=1 step=21 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=22 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=23 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=1 step=23 output=quotient expected=0 actual=%0d",quotient);
$display("FAST_CASE cycles=1");
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=0 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=2 step=0 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd1;
numerator=27'd12345;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=3 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=5 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=6 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=7 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=8 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=9 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=10 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=11 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=12 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=13 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=14 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=15 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=16 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=17 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=18 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=19 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=20 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=2 step=21 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=2 step=21 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=22 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=23 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=2 step=23 output=quotient expected=0 actual=%0d",quotient);
$display("FAST_CASE cycles=1");
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=0 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=3 step=0 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd1;
numerator=27'd134216728;
denominator=19'd10;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd12345;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=3 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd67108864;
denominator=19'd524287;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=5 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd67108863;
denominator=19'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=6 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd3295916;
denominator=19'd492388;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=7 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=8 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd30171838;
denominator=19'd411919;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=9 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd37810538;
denominator=19'd45370;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=10 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd37229562;
denominator=19'd117905;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=11 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=12 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd62223971;
denominator=19'd146372;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=13 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd39567712;
denominator=19'd34724;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=14 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd16271833;
denominator=19'd143212;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=15 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=16 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd62054013;
denominator=19'd469500;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=17 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd110748439;
denominator=19'd214883;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=18 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd24994399;
denominator=19'd123887;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=19 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=20 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
numerator=27'd5467078;
denominator=19'd422519;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=21 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd63936) $fatal(1,"module case=3 step=21 output=quotient expected=63936 actual=%0d",quotient);
reset=1'd0;
iv=1'd1;
numerator=27'd91679630;
denominator=19'd208139;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=22 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=3 step=22 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=23 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=3 step=23 output=quotient expected=0 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=24 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=25 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd63488) $fatal(1,"module case=3 step=25 output=quotient expected=63488 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=26 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd65520) $fatal(1,"module case=3 step=26 output=quotient expected=65520 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=27 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd107) $fatal(1,"module case=3 step=27 output=quotient expected=107 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=28 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=29 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd1171) $fatal(1,"module case=3 step=29 output=quotient expected=1171 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=30 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd13334) $fatal(1,"module case=3 step=30 output=quotient expected=13334 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=31 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd5052) $fatal(1,"module case=3 step=31 output=quotient expected=5052 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=32 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=33 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd6801) $fatal(1,"module case=3 step=33 output=quotient expected=6801 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=34 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd18231) $fatal(1,"module case=3 step=34 output=quotient expected=18231 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=35 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd1817) $fatal(1,"module case=3 step=35 output=quotient expected=1817 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=36 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=37 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd2114) $fatal(1,"module case=3 step=37 output=quotient expected=2114 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=38 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd63789) $fatal(1,"module case=3 step=38 output=quotient expected=63789 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=39 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd3228) $fatal(1,"module case=3 step=39 output=quotient expected=3228 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=40 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=41 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd207) $fatal(1,"module case=3 step=41 output=quotient expected=207 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=42 output=ov expected=1 actual=%0d",ov);
if (quotient !== 16'd62267) $fatal(1,"module case=3 step=42 output=quotient expected=62267 actual=%0d",quotient);
reset=1'd0;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=43 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
numerator=27'd0;
denominator=19'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=44 output=ov expected=0 actual=%0d",ov);
if (quotient !== 16'd0) $fatal(1,"module case=3 step=44 output=quotient expected=0 actual=%0d",quotient);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule