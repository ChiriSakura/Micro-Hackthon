import chisel3._
import chisel3.util._

class WeightGenerator extends RawModule {
  val scores_in = IO(Input(UInt(72.W)))
  val weights_out = IO(Output(UInt(128.W)))

  // The 256-entry, 16-bit wide exponential lookup table (ROM)
  // This is initialized with the exact values from the algorithm contract.
  val exp_table = VecInit(Seq(
    65535.U(16.W), 61564.U(16.W), 57834.U(16.W), 54330.U(16.W), 51039.U(16.W), 47946.U(16.W), 45042.U(16.W), 42313.U(16.W), 39749.U(16.W), 37341.U(16.W), 35078.U(16.W), 32953.U(16.W), 30957.U(16.W), 29081.U(16.W), 27319.U(16.W), 25664.U(16.W),
    24109.U(16.W), 22648.U(16.W), 21276.U(16.W), 19987.U(16.W), 18776.U(16.W), 17639.U(16.W), 16570.U(16.W), 15566.U(16.W), 14623.U(16.W), 13737.U(16.W), 12905.U(16.W), 12123.U(16.W), 11388.U(16.W), 10698.U(16.W), 10050.U(16.W), 9441.U(16.W),
    8869.U(16.W), 8332.U(16.W), 7827.U(16.W), 7353.U(16.W), 6907.U(16.W), 6489.U(16.W), 6096.U(16.W), 5726.U(16.W), 5379.U(16.W), 5054.U(16.W), 4747.U(16.W), 4460.U(16.W), 4190.U(16.W), 3936.U(16.W), 3697.U(16.W), 3473.U(16.W),
    3263.U(16.W), 3065.U(16.W), 2879.U(16.W), 2705.U(16.W), 2541.U(16.W), 2387.U(16.W), 2242.U(16.W), 2107.U(16.W), 1979.U(16.W), 1859.U(16.W), 1746.U(16.W), 1641.U(16.W), 1541.U(16.W), 1448.U(16.W), 1360.U(16.W), 1278.U(16.W),
    1200.U(16.W), 1128.U(16.W), 1059.U(16.W), 995.U(16.W), 935.U(16.W), 878.U(16.W), 825.U(16.W), 775.U(16.W), 728.U(16.W), 684.U(16.W), 642.U(16.W), 604.U(16.W), 567.U(16.W), 533.U(16.W), 500.U(16.W), 470.U(16.W),
    442.U(16.W), 415.U(16.W), 390.U(16.W), 366.U(16.W), 344.U(16.W), 323.U(16.W), 303.U(16.W), 285.U(16.W), 268.U(16.W), 252.U(16.W), 236.U(16.W), 222.U(16.W), 209.U(16.W), 196.U(16.W), 184.U(16.W), 173.U(16.W),
    162.U(16.W), 153.U(16.W), 143.U(16.W), 135.U(16.W), 127.U(16.W), 119.U(16.W), 112.U(16.W), 105.U(16.W), 99.U(16.W), 93.U(16.W), 87.U(16.W), 82.U(16.W), 77.U(16.W), 72.U(16.W), 68.U(16.W), 64.U(16.W),
    60.U(16.W), 56.U(16.W), 53.U(16.W), 50.U(16.W), 47.U(16.W), 44.U(16.W), 41.U(16.W), 39.U(16.W), 36.U(16.W), 34.U(16.W), 32.U(16.W), 30.U(16.W), 28.U(16.W), 27.U(16.W), 25.U(16.W), 23.U(16.W),
    22.U(16.W), 21.U(16.W), 19.U(16.W), 18.U(16.W), 17.U(16.W), 16.U(16.W), 15.U(16.W), 14.U(16.W), 13.U(16.W), 13.U(16.W), 12.U(16.W), 11.U(16.W), 10.U(16.W), 10.U(16.W), 9.U(16.W), 9.U(16.W),
    8.U(16.W), 8.U(16.W), 7.U(16.W), 7.U(16.W), 6.U(16.W), 6.U(16.W), 6.U(16.W), 5.U(16.W), 5.U(16.W), 5.U(16.W), 4.U(16.W), 4.U(16.W), 4.U(16.W), 4.U(16.W), 3.U(16.W), 3.U(16.W),
    3.U(16.W), 3.U(16.W), 3.U(16.W), 2.U(16.W), 2.U(16.W), 2.U(16.W), 2.U(16.W), 2.U(16.W), 2.U(16.W), 2.U(16.W), 2.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W),
    1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 1.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W),
    0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W),
    0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W),
    0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W),
    0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W), 0.U(16.W)
  ))

  // Unpack 8 signed 9-bit scores from the input
  val scores = VecInit(Seq.tabulate(8) { i =>
    scores_in(9 * (i + 1) - 1, 9 * i).asSInt
  })

  // Find the maximum score 'h' using an explicit comparator tree
  val max_stage1_0 = Mux(scores(0) > scores(1), scores(0), scores(1))
  val max_stage1_1 = Mux(scores(2) > scores(3), scores(2), scores(3))
  val max_stage1_2 = Mux(scores(4) > scores(5), scores(4), scores(5))
  val max_stage1_3 = Mux(scores(6) > scores(7), scores(6), scores(7))

  val max_stage2_0 = Mux(max_stage1_0 > max_stage1_1, max_stage1_0, max_stage1_1)
  val max_stage2_1 = Mux(max_stage1_2 > max_stage1_3, max_stage1_2, max_stage1_3)

  val h = Mux(max_stage2_0 > max_stage2_1, max_stage2_0, max_stage2_1)

  // Calculate deltas and look up weights in parallel for all 8 scores
  val weights = Wire(Vec(8, UInt(16.W)))
  for (i <- 0 until 8) {
    // Delta is h - s[i]. This is always non-negative.
    // Max delta is score_max - score_min = 128 - (-112) = 240, which fits in 8 bits.
    val delta = h - scores(i)
    // The result of the SInt subtraction is non-negative and has a width of 10 bits.
    // We cast to UInt (bitcast) and take the lower 8 bits for the table address.
    // The behavior contract's min(h-s, 255) is implicitly satisfied as max delta is 240.
    weights(i) := exp_table(delta.asUInt(7, 0))
  }

  // Pack the 8 resulting 16-bit weights into the 128-bit output wire.
  // Cat(w7, w6, ..., w0) places w0 at the LSBs, matching the 'pack' DSL function.
  weights_out := Cat(weights.reverse)
}
