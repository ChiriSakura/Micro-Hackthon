import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val q_in = IO(Input(UInt(8.W)))
  val k_in = IO(Input(UInt(64.W)))
  val scores_out = IO(Output(UInt(72.W)))

  // Unpack q_in into two signed 4-bit values
  val q0 = q_in(3, 0).asSInt
  val q1 = q_in(7, 4).asSInt

  // Create a vector to hold the 8 signed 9-bit scores
  val scores = Wire(Vec(8, SInt(9.W)))

  // Calculate each score in parallel
  for (i <- 0 until 8) {
    // Unpack the i-th pair of key vectors based on the packing rule:
    // k[i][d] is at bit range 4*(2*i+d)+3 : 4*(2*i+d)
    val k_i_0 = k_in(4 * (2 * i + 0) + 3, 4 * (2 * i + 0)).asSInt
    val k_i_1 = k_in(4 * (2 * i + 1) + 3, 4 * (2 * i + 1)).asSInt

    // Perform the dot product: q0*k0 + q1*k1
    // SInt(4.W) * SInt(4.W) -> SInt(8.W)
    val prod0 = q0 * k_i_0
    val prod1 = q1 * k_i_1

    // SInt(8.W) + SInt(8.W) -> SInt(9.W), correctly handling carry growth
    scores(i) := prod0 + prod1
  }

  // Pack the scores into the output wire.
  // Vec.asUInt concatenates elements from highest index (MSB) to lowest (LSB).
  // scores(7) will be at bits 71:63, scores(0) will be at bits 8:0.
  scores_out := scores.asUInt
}
