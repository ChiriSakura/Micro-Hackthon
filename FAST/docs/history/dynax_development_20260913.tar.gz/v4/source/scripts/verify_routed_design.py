#!/usr/bin/env python3
"""Independent algorithm E2E on the routed gate netlist, with Liberty cell models.

This is zero-delay functional gate simulation, not SDF timing simulation. STA
and extracted parasitics provide the separate timing evidence.
"""
import argparse
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fast.fullstack.contracts import SystemPlan
from fast.fullstack.library import Library,digest,save
from fast.fullstack.tools import RtlTools


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--physical',type=Path,required=True)
    p.add_argument('--catalog',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--tool-root',type=Path,required=True)
    args=p.parse_args();measured=json.loads(args.physical.read_text());e=measured['evaluation']
    if not e.get('complete'):raise ValueError('Requires completed physical measurement')
    work=args.output.resolve();work.mkdir(parents=True,exist_ok=False)
    run=Path(measured['original_run']);record=json.loads((run/f'round_{measured["original_round"]:02d}/result.json').read_text())
    inventory=json.loads((run/'library_manifest.json').read_text())
    library=Library(args.catalog,work);key='algorithm:'+measured['task']['algorithm']
    if library.files[key]['sha256']!=inventory['files'][key]['sha256']:raise ValueError('Algorithm identity differs')
    algorithm=library.algorithm(measured['task']['algorithm']);plan=SystemPlan.parse(record['system_plan'],algorithm.describe()['ports'])
    relative='hammer/par-rundir/routed.v';routed=args.physical.parent/relative
    if digest(routed)!=e['artifacts'][relative]:raise ValueError('Routed netlist integrity failed')
    liberty=args.tool_root/'pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib'
    models=work/'liberty_cells.v';script=work/'cell_models.ys'
    script.write_text(f'read_liberty -ignore_miss_func {liberty}\nwrite_verilog -noattr {models}\n')
    tools=RtlTools(args.tool_root,600)
    built=tools.command(['apptainer','exec',str(args.tool_root/'containers/yosys.sif'),'yosys','-s',str(script)],work,work/'cell_models.log')
    if not built['passed']:raise ValueError('Failed to compile trusted Liberty functions')
    verified=tools.verify(plan,[routed,models],algorithm.verification(record['config'],measured['task']['seed'],plan.top),work)
    library.check()
    result={'passed':verified['passed'],'verification':verified,'physical_measurement':str(args.physical),
            'routed_sha256':digest(routed),'liberty_sha256':digest(liberty),'llm_calls':0,
            'scope':'zero-delay functional gate-level E2E on routed netlist; not SDF timing simulation'}
    save(work/'summary.json',result);print(json.dumps({'passed':result['passed'],'cases':verified.get('cases')}))
    return 0 if result['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
