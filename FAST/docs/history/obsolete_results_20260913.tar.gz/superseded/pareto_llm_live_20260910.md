**Equal-budget energy/latency search pilot**

These are L1 shared-model predictions with partial energy coverage. They do not prove independent acceleration or an LLM advantage.

| Workload | Method | Seeds | Mean feasible | Mean Pareto size |
|---|---|---|---|---|
| xm:32:4:64 | llm | 1 | 4.0 | 1.0 |
| xm:32:4:64 | llm-no-feedback | 1 | 4.0 | 1.0 |

Front size is descriptive, not a quality score. Compare fixed-reference hypervolume or the actual coordinates, then independently validate candidates.
