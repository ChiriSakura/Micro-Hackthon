#!/usr/bin/env python3
"""Standalone latency-energy-efficiency figure from measured RQ1 records."""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experiment', type=Path, required=True)
    args = parser.parse_args()
    data = json.loads((args.experiment / 'metrics.json').read_text())
    rows = [r for r in data['rounds'] if r['latency_ns'] is not None
            and r['energy_efficiency_queries_per_joule'] is not None]
    if not rows:
        print('No measured PPA points; no figure generated.')
        return
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 10, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
    columns = min(2, len(data['runs']))
    panels = (len(data['runs']) + columns - 1) // columns
    fig, axes = plt.subplots(panels, columns, figsize=(4 * columns, 3 * panels), squeeze=False,
                             sharex=True, sharey=True, constrained_layout=True)
    colors = ['#0072B2', '#009E73', '#D55E00', '#CC79A7']
    for index, (ax, run) in enumerate(zip(axes.flat, data['runs'])):
        color = colors[index % len(colors)]
        group = [r for r in rows if r['algorithm'] == run['algorithm']]
        for r in group:
            x, y = r['latency_ns'], r['energy_efficiency_queries_per_joule'] / 1e9
            good = r['search_feasible']
            ax.scatter(x, y, color=color if good else '#888888', marker='o' if good else 'x', s=45)
            ax.annotate('R' + str(r['round']), (x, y), xytext=(5, 5), textcoords='offset points', fontsize=8)
        good = [r for r in group if r['search_feasible']]
        frontier = [r for r in good if not any(s['latency_ns'] <= r['latency_ns']
                    and s['energy_efficiency_queries_per_joule'] >= r['energy_efficiency_queries_per_joule']
                    and (s['latency_ns'] < r['latency_ns'] or s['energy_efficiency_queries_per_joule'] > r['energy_efficiency_queries_per_joule'])
                    for s in good)]
        frontier.sort(key=lambda r: r['latency_ns'])
        ax.plot([r['latency_ns'] for r in frontier], [r['energy_efficiency_queries_per_joule']/1e9 for r in frontier],
                color=color, linewidth=1, linestyle='--')
        ax.set_title(run['algorithm'].removeprefix('rq1_').replace('_', ' '))
        ax.grid(alpha=.2)
    for ax in list(axes.flat)[len(data['runs']):]:
        ax.set_visible(False)
    fig.supxlabel('Latency (ns, lower is better)')
    fig.supylabel('Energy efficiency (Gqueries/J, higher is better)')
    fig.suptitle('300 MHz · relative output RMSE ≤ 5%\nCircles: search-feasible; crosses: constraint violations', fontsize=11)
    for extension in ('pdf', 'svg', 'png'):
        fig.savefig(args.experiment / f'latency_energy_efficiency.{extension}', dpi=240)
    plt.close(fig)


if __name__ == '__main__':
    main()
