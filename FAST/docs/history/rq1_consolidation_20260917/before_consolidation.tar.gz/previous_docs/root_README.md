# FAST：参考库驱动的全栈硬件协同设计

研究问题：**Can agentic full-stack co-design replace algorithm-specific manual optimization for dynamic sparse-attention acceleration?**

FAST 从只读算法契约与硬件参考库出发，由 Kernel 分析算法、Compiler 规划并分派模块、UArch 编写和组装系统，经独立 E2E 验证与 PPA 提取后，由 Critic 分析并迭代。优化目标是在质量、面积、频率约束下，降低 **Latency**、提高 **Energy Efficiency**。

**当前已完成：小规模 DynaX X:M 查询行硬件的自主两轮闭环。** 第二轮在 100 MHz 下达到 **170 ns、34,272.77 µm² 标准单元面积、3.4166 mW 布线后建模功耗、1.7217 Gqueries/J**；相对首轮延迟降低 34.6%，能效提高 79.7%。两轮均通过独立数值验证、额外种子测试与布线后网表功能验证。范围为 8 keys、Q/K dim=2、V dim=1，功耗为 EDA 模型值；这不是完整模型加速或严格 Critic 消融结论。

## 从这里开始

| 目的 | 入口 |
|---|---|
| 20 分钟读懂项目 | [阅读指南](docs/quick-reading-20260913.md) |
| 当前能力、限制与验收证据 | [状态表](docs/STATUS.md) |
| 模块职责与调用关系 | [架构说明](docs/agent-architecture.md) |
| 最终配置、硬件、PPA 与 Critic 过程 | [DynaX 实验报告](docs/results/dynax_autonomous_20260913/RESULTS.md) |
| 启动新实验或复验归档 | [运行与复现](docs/dynax-autonomous.md) |
| 汇报 PPT 的论证顺序 | [汇报提纲](docs/presentation-outline-20260913.md) |
| 历史对照与失败记录 | [结果索引](docs/results/README.md) · [历史索引](docs/history/README.md) |

## 工程结构

```text
FAST/
├── fast/fullstack/     当前主线：契约、Agent、调度、工具、复验、归档
├── libraries/          只读算法插件与硬件模板注册表
├── hardware/           可引用的 Chisel IP、golden 与 testbench
├── configs/fullstack/  生成任务、目标约束与预算
├── scripts/            当前验证、归档、报告，以及仍可用的实验工具
│   └── legacy/         早期 L2 / 组件 PPA / 旧报告入口
├── tests/              控制流、数值契约、工具与完整性测试
├── docs/               当前架构、复现与汇报说明
│   ├── results/        经筛选的实验记录；最新结果含独立压缩包
│   └── history/        旧状态、开发失败证据与迁移记录
└── fast/{agents,adapters,orchestrator,...}/
                        历史搜索/闭环和共享基础设施
```

`fast/agents/` 仍为主线提供 LLM 后端，`fast/adapters/` 提供部分工具适配器，不能整组删除。历史 A/B/C 路径用途见 [架构说明](docs/agent-architecture.md)。相邻 `../DynaX/` 为算法与上游参考，`../chia/` 为历史运行时依赖，`../slurm/` 为集群入口。

## 开发检查

```bash
python -m pip install -e '.[test]'
python -m pytest -p no:cacheprovider
python -m fast.fullstack.cli --help
python scripts/archive_generated_run.py --help
```

单元测试不需要 LLM、GPU 或 EDA；真实生成需要配置 Vertex 后端、Chisel/Verilator 和 Hammer/OpenROAD 环境。详细命令与已验证配置见 [复现指南](docs/dynax-autonomous.md)。
