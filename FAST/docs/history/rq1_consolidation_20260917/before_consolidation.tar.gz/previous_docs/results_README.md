# 实验结果索引

## 当前用于汇报的结果

- [RQ1 四算法补完与总结](rq1_completion_20260917/RQ1_SUMMARY.md)：DynaX/N:M/Sanger原轮次恢复、共同8192样本独立验收、完整失败与PPA记录；开发恢复证据，不是统一从零cohort。

| 结果 | 用途 | 状态 |
|---|---|---|
| [DynaX 自主两轮](dynax_autonomous_20260913/RESULTS.md) | 主证据：自主生成、E2E、Hammer、Critic 改进 | 两轮通过；独立压缩包和哈希已保存 |
| [DynaX 恢复两轮](dynax_fast_recovery_20260913/RESULTS.md) | 恢复机制的辅助证据 | 首轮外部选取旧模块；不能算纯自主或公平对照 |
| [历史 Critic 消融](critic_ablation_20260911/RESULTS.md) | 24×5-loop 参数修正消融 | 路径 B；不能替代当前生成任务的消融 |

## 保留的历史证据

| 目录 | 保留原因 |
|---|---|
| `fullstack_extensions_20260913/` | threshold-attention 的 Hammer 和 Critic 生成对照；另含失败和辅助修复 |
| `fullstack_e2e_20260913/` | 逐模块实现与组装的 E2E bring-up |
| `parallel_uarch_20260913/` | 并发分派机制验证，不能算本次串行 DynaX 的并发收益 |
| `fullstack_generation_20260913/` | 初期 Chisel/Verilog 系统生成，算法/后端与当前不同 |
| `critic_integration_20260911/`、`critic_audit_20260911/` | 历史 Critic 接入与作用审计 |
| `dynax_rediscovery_20260910/`、`final_experiment_20260911/` | 算法搜索、确认及组件验证；部分功耗口径已被后续修正 |

旧数字按各自报告的算法、规模、后端和日期解释。过时前沿与早期示例已移入 [历史归档](../history/README.md)。当前结果目录中的 `run/` 是便于阅读的源码与 JSON 摘要；`artifacts.tar.gz` 才是完整可复验的运行、冻结源码与物理证据。

- [RQ1 扩展库 N:M / Sanger](rq1_extended_20260916/RESULTS.md)：新增只读上游参考、通用诊断修正、各 5 轮目标；与 v1 分开，不是单因素消融。

- [DynaX 工程恢复](dynax_recovery_20260916/RESULTS.md)：额外选参验证、历史已验证组件参考、失败候选回退；独立新测试集，单列恢复证据。

- [Block N:M 时序修复（2026-09-17）](block_nm_timing_repair_20260917/RESULTS.md)：300 MHz独立验收通过；外部诊断辅助，单独于原RQ1五轮报告。
