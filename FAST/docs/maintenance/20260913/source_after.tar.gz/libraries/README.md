# 只读参考库

`catalog.json` 注册可信算法与硬件参考。运行时先复制并计算 SHA-256，Agent 只能读取材料并在新运行目录生成设计。

- `algorithms/`：用户维护的算法契约、合法配置、画像测量和独立 E2E golden。
- `hardware/`：小型通用模板；注册表也可引用 `../hardware/chisel/` 中的完整原生 IP。
- 硬件条目的 `support_sources` 包含依赖，`test_references` 携带 golden/testbench 示例。
- Compiler 为模块分配 `reference_ids`；兼容的原生 Chisel 可通过 `linked_reference_ids` 直接链接，只生成适配层。

扩展库由维护者新增算法或模板并修改注册表，然后检查契约、依赖和 golden。Agent 执行期间不能修改这些文件。未知算法没有默认回退；库扩展说明见 [生成约定](../docs/fullstack-generation.md)。
