"""Exercise the actual Tcl proxy; this is not physical-design evidence."""
import ast
import os
from pathlib import Path
import shlex
import shutil
import subprocess

import pytest

from fast.fullstack.tools import RtlTools


def emitted_tcl(policy):
    # Hammer has its own isolated Python environment. This hook uses only the
    # public get_setting/block_append interface, so extract its actual body.
    path = Path(__file__).parents[1] / 'fast/fullstack/hammer_driver.py'
    function = next(n for n in ast.parse(path.read_text()).body
                    if isinstance(n, ast.FunctionDef) and n.name == 'constrain_io')
    namespace = {'HammerTool': object}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), 'exec'), namespace)
    class Tool:
        blocks = []
        def get_setting(self, name):
            assert name == 'fast.setup_repair_policy'
            return policy
        def block_append(self, value):
            self.blocks.append(value)
    tool = Tool()
    namespace['constrain_io'](tool)
    return '\n'.join(tool.blocks)


@pytest.mark.parametrize('policy', ['default', 'no-clone-buffer'])
def test_setup_compatibility_keeps_hold_repair_and_default_moves(policy):
    stub = '''
proc set_input_delay {args} {}
proc set_output_delay {args} {}
proc set_load {args} {}
proc all_inputs {args} {return inputs}
proc all_outputs {args} {return outputs}
proc repair_timing {args} {puts [join $args ,]}
'''
    commands = '''
repair_timing -setup -setup_margin 0.05
repair_timing -hold -hold_margin 0.01 -allow_setup_violations
repair_timing -setup -skip_gate_cloning -skip_buffering
'''
    command = shlex.split(os.environ.get('FAST_TEST_TCL_COMMAND', 'tclsh'))
    if not shutil.which(command[0]):
        pytest.skip('Tcl interpreter required; FAST_TEST_TCL_COMMAND can select the EDA container')
    run = subprocess.run(command, input=stub + emitted_tcl(policy) + commands,
                         text=True, capture_output=True, check=True)
    assert not run.stderr
    lines = run.stdout.splitlines()
    extra = ',-skip_gate_cloning,-skip_buffering' if policy != 'default' else ''
    assert lines == ['-setup,-setup_margin,0.05' + extra,
                     '-hold,-hold_margin,0.01,-allow_setup_violations',
                     '-setup,-skip_gate_cloning,-skip_buffering']


def test_unknown_policy_fails_closed(tmp_path):
    with pytest.raises(ValueError, match='Unknown OpenROAD'):
        RtlTools(tmp_path, openroad_setup_policy='skip-all-checks')
    with pytest.raises(ValueError, match='Unknown OpenROAD'):
        emitted_tcl('skip-all-checks')
