import chisel3._

class ScoreAndWeightUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val q_in = IO(Input(UInt(8.W)))
  val k_in = IO(Input(UInt(8.W)))
  val v_in = IO(Input(UInt(4.W)))

  val valid_out = IO(Output(Bool()))
  val weight_out = IO(Output(UInt(9.W)))
  val weighted_v_out = IO(Output(UInt(13.W)))

  withClockAndReset(clock, reset) {
    // --- Stage 1: Score Calculation --- 
    // Registers to hold the results of stage 1
    val score_s1_reg = RegInit(0.U(9.W))
    val v_in_s1_reg = RegInit(0.U(4.W))
    val valid_s1_reg = RegInit(false.B)

    // Combinational logic for stage 1
    val q0 = q_in(3, 0)
    val q1 = q_in(7, 4)
    val k0 = k_in(3, 0)
    val k1 = k_in(7, 4)
    
    // 4x4 mult is 8 bits. Sum of two 8-bit numbers needs 9 bits.
    // Use +& to get the 9th bit (carry).
    val score_s0 = (q0 * k0) +& (q1 * k1)

    // Latch stage 1 results
    valid_s1_reg := valid_in
    when(valid_in) {
      score_s1_reg := score_s0
      v_in_s1_reg := v_in
    }

    // --- Stage 2: Weighting and Value Multiplication ---
    // Registers to hold the results of stage 2 (which are the module outputs)
    val weight_out_reg = RegInit(0.U(9.W))
    val weighted_v_out_reg = RegInit(0.U(13.W))
    val valid_out_reg = RegInit(false.B)

    // Combinational logic for stage 2, using results from stage 1 registers
    val threshold = 64.U(9.W)
    val weight_s1 = Mux(score_s1_reg >= threshold, score_s1_reg, 0.U)
    
    // 9-bit weight * 4-bit value = 13-bit result
    val weighted_v_s1 = weight_s1 * v_in_s1_reg

    // Latch stage 2 results
    valid_out_reg := valid_s1_reg
    when(valid_s1_reg) {
      weight_out_reg := weight_s1
      weighted_v_out_reg := weighted_v_s1
    }

    // --- Connect Outputs ---
    valid_out := valid_out_reg
    weight_out := weight_out_reg
    weighted_v_out := weighted_v_out_reg
  }
}
