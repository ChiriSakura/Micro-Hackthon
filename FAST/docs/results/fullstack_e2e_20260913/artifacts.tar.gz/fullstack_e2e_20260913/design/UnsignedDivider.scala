import chisel3._
import chisel3.util._

class UnsignedDivider extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val numer = IO(Input(UInt(15.W)))
  val denom = IO(Input(UInt(11.W)))
  val valid_out = IO(Output(Bool()))
  val quot = IO(Output(UInt(4.W)))

  // Internal bundle to hold the state passed between pipeline stages.
  class PipeState extends Bundle {
    val remainder = UInt(12.W) // 11-bit divisor + 1 bit for comparison
    val quotient = UInt(15.W)
    val dividend = UInt(15.W)
    val divisor = UInt(11.W)
    val is_denom_zero = Bool()
    val valid = Bool()
  }

  // Define the reset value for the pipeline state registers.
  // is_denom_zero is set to true on reset to ensure the output Mux selects 0,
  // fixing the reset bug where a zeroed state could produce a non-zero quotient.
  val pipeStateReset = Wire(new PipeState)
  pipeStateReset.remainder := 0.U
  pipeStateReset.quotient := 0.U
  pipeStateReset.dividend := 0.U
  pipeStateReset.divisor := 0.U
  pipeStateReset.is_denom_zero := true.B
  pipeStateReset.valid := false.B

  // Input stage logic (combinational)
  val s0_state = Wire(new PipeState)
  s0_state.remainder := 0.U
  s0_state.quotient := 0.U
  s0_state.dividend := numer
  s0_state.divisor := denom
  s0_state.is_denom_zero := (denom === 0.U)
  s0_state.valid := valid_in

  // The `foldLeft` construct builds the 15-stage pipeline. 
  // The accumulator `stage_in_comb` is the combinational output of the previous stage's logic.
  val final_state_comb = (0 until 15).foldLeft(s0_state) { (stage_in_comb, _) =>
    // Register the input to this stage's logic.
    val stage_in_reg = withClockAndReset(clock, reset) {
      RegNext(stage_in_comb, pipeStateReset)
    }

    // Combinational logic for one step of restoring division.
    val stage_out_comb = Wire(new PipeState)
    
    // Form the partial remainder by shifting the last remainder and bringing in the MSB of the dividend.
    val partial_rem = Cat(stage_in_reg.remainder(10, 0), stage_in_reg.dividend(14))
    // Extend divisor to 12 bits for comparison.
    val divisor_ext = Cat(0.U(1.W), stage_in_reg.divisor)
    
    val fits = partial_rem >= divisor_ext
    val diff = partial_rem - divisor_ext

    // If subtraction was successful, new remainder is the difference. Otherwise, it's the old partial remainder.
    stage_out_comb.remainder := Mux(fits, diff(11, 0), partial_rem)
    // Shift the new quotient bit into the LSB of the quotient register.
    stage_out_comb.quotient := Cat(stage_in_reg.quotient(13, 0), fits)
    // Shift the dividend to prepare the next bit for the next stage.
    stage_out_comb.dividend := stage_in_reg.dividend << 1

    // Pass through the other state variables.
    stage_out_comb.divisor := stage_in_reg.divisor
    stage_out_comb.is_denom_zero := stage_in_reg.is_denom_zero
    stage_out_comb.valid := stage_in_reg.valid
    
    // The result of this iteration is the combinational output, which will be the input to the next stage's register.
    stage_out_comb
  }

  // The `valid` signal has passed through 15 registers, so the latency is 15 cycles.
  valid_out := final_state_comb.valid
  // If original denominator was zero, output 0. Otherwise, output the lower 4 bits of the calculated quotient.
  quot := Mux(final_state_comb.is_denom_zero, 0.U, final_state_comb.quotient(3, 0))
}
