import chisel3._
import chisel3.util._

class ThresholdAttention extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val start = IO(Input(Bool()))
  val q = IO(Input(UInt(8.W)))
  val k = IO(Input(UInt(32.W)))
  val v = IO(Input(UInt(16.W)))
  val done = IO(Output(Bool()))
  val result = IO(Output(UInt(4.W)))

  // Child modules are defined in the context and will be linked by the compiler.
  // class ScoreAndWeightUnit extends RawModule { ... }
  // class UnsignedDivider extends RawModule { ... }

  withClockAndReset(clock, reset) {
    // The design is a deep, feed-forward pipeline. A 'valid' signal is propagated
    // through the pipeline registers to control data flow.

    // Pipeline Stage 0: Input Latching (1 cycle latency)
    // Latches inputs on the cycle after 'start' is asserted.
    val s1_valid = RegNext(start, false.B)
    val q_s1 = RegNext(q, 0.U(8.W))
    val k_s1 = RegNext(k, 0.U(32.W))
    val v_s1 = RegNext(v, 0.U(16.W))

    // Unpack the latched 'k' and 'v' inputs for the parallel ScoreAndWeight units.
    val k_vec_s1 = Wire(Vec(4, UInt(8.W)))
    val v_vec_s1 = Wire(Vec(4, UInt(4.W)))
    for (i <- 0 until 4) {
      k_vec_s1(i) := k_s1(8 * (i + 1) - 1, 8 * i)
      v_vec_s1(i) := v_s1(4 * (i + 1) - 1, 4 * i)
    }

    // Pipeline Stages 1-2: Parallel Score and Weight Calculation (2 cycle latency)
    val saw_units = Seq.fill(4)(Module(new ScoreAndWeightUnit))
    val saw_weights = Wire(Vec(4, UInt(9.W)))
    val saw_weighted_vs = Wire(Vec(4, UInt(13.W)))

    for (i <- 0 until 4) {
      saw_units(i).clock := clock
      saw_units(i).reset := reset
      saw_units(i).valid_in := s1_valid
      saw_units(i).q_in := q_s1
      saw_units(i).k_in := k_vec_s1(i)
      saw_units(i).v_in := v_vec_s1(i)
      saw_weights(i) := saw_units(i).weight_out
      saw_weighted_vs(i) := saw_units(i).weighted_v_out
    }
    // The valid signal for the output of the S&W units, delayed by 2 cycles.
    val s3_valid = RegNext(RegNext(s1_valid, false.B), false.B)

    // Pipeline Stage 3: Reducer Tree Level 1 (1 cycle latency)
    // Sums the outputs of the S&W units in pairs.
    val w_sum_01_s3 = saw_weights(0) +& saw_weights(1)
    val w_sum_23_s3 = saw_weights(2) +& saw_weights(3)
    val wv_sum_01_s3 = saw_weighted_vs(0) +& saw_weighted_vs(1)
    val wv_sum_23_s3 = saw_weighted_vs(2) +& saw_weighted_vs(3)

    val s4_valid = RegNext(s3_valid, false.B)
    val w_sum_01_s4 = RegNext(w_sum_01_s3, 0.U(10.W))
    val w_sum_23_s4 = RegNext(w_sum_23_s3, 0.U(10.W))
    val wv_sum_01_s4 = RegNext(wv_sum_01_s3, 0.U(14.W))
    val wv_sum_23_s4 = RegNext(wv_sum_23_s3, 0.U(14.W))

    // Pipeline Stage 4: Reducer Tree Level 2 (1 cycle latency)
    // Completes the summation to get total weight and weighted value sums.
    val weight_sum_s4 = w_sum_01_s4 +& w_sum_23_s4
    val weighted_v_sum_s4 = wv_sum_01_s4 +& wv_sum_23_s4

    val s5_valid = RegNext(s4_valid, false.B)
    val weight_sum_s5 = RegNext(weight_sum_s4, 0.U(11.W))
    val weighted_v_sum_s5 = RegNext(weighted_v_sum_s4, 0.U(15.W))

    // Pipeline Stages 5-19: Division (15 cycle latency)
    val divider = Module(new UnsignedDivider)
    divider.clock := clock
    divider.reset := reset
    divider.valid_in := s5_valid
    divider.numer := weighted_v_sum_s5
    divider.denom := weight_sum_s5

    val s20_valid = divider.valid_out
    val quot_s20 = divider.quot

    // Pipeline Stage 20: Output Register (1 cycle latency)
    // Registers the final result and done signal for clean output timing.
    val s21_valid = RegNext(s20_valid, false.B)
    val result_s21 = RegNext(quot_s20, 0.U(4.W))

    // Total latency = 1 (latch) + 2 (S&W) + 1 (reduce1) + 1 (reduce2) + 15 (div) + 1 (out) = 21 cycles.

    // Connect outputs
    done := s21_valid
    result := result_s21
  }
}
