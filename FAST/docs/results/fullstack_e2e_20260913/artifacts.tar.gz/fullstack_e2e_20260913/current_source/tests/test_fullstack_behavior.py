"""Executable contract arithmetic/protocol tests, separate from trusted E2E oracle."""
from dataclasses import asdict
import pytest
import json

from fast.fullstack.behavior import evaluate, compile_tests
from fast.fullstack.contracts import Module, Port, SystemPlan
from fast.fullstack.tools import module_testbench


def test_packed_dot_product_and_sparse_reduction_regressions():
    env={'q':0x51,'k':0x85}
    assert evaluate('lane(q,0,4)*lane(k,0,4)+lane(q,1,4)*lane(k,1,4)',env)==45
    packed=evaluate('pack(9,60,70,80,90)',{})
    assert [evaluate(f'lane(s,{i},9)',{'s':packed}) for i in range(4)]==[60,70,80,90]
    weights=[v if v>=64 else 0 for v in (60,398,415,57)]
    assert sum(weights)==813
    assert evaluate('0 if d == 0 else n // d',{'n':15,'d':0})==0
    assert evaluate('d == 0 or n // d < 16',{'n':15,'d':0})==1
    assert evaluate('n < 0 and n // d > 0',{'n':15,'d':0})==0


@pytest.mark.parametrize('expr',["__import__('os')",'a.__class__','[x for x in a]','2**100','1 << 100000000','open(1)','(lambda:1)()'])
def test_expression_language_rejects_host_execution_and_unbounded_work(expr):
    with pytest.raises(ValueError): evaluate(expr,{'a':1})


def pipeline():
    ports=(Port('clock','input',1),Port('reset','input',1),Port('iv','input',1),
           Port('a','input',4),Port('ov','output',1),Port('b','output',5))
    behavior={'latency':3,'reset':'reset','valid_input':'iv','valid_output':'ov',
              'outputs':{'b':'a+1'},'vectors':[{'a':0},{'a':15},{'a':7}]}
    return ports,behavior


def test_pipeline_valid_delay_bubbles_and_reset_are_computed():
    ports,behavior=pipeline()
    tests=compile_tests(ports,behavior)
    first=tests[0]['steps']
    assert [step['expected']['ov'] for step in first]==[0,0,0,1,0,0]
    assert first[3]['expected']['b']==1
    assert all(step['cycles']==1 for case in tests for step in case['steps'])
    # Independently model a 3-register pipeline for the generated continuous stream.
    queue=[None,None,None]
    for step in tests[-1]['steps']:
        values=step['inputs'];expected=step['expected']
        if values['reset']:
            queue=[None,None,None]
            assert expected=={'ov':0,'b':0}
        else:
            queue=[values['a']+1 if values['iv'] else None,*queue[:2]]
            assert expected['ov']==(queue[2] is not None)
            if queue[2] is not None:assert expected['b']==queue[2]
    assert tests==compile_tests(ports,behavior)


def test_generated_tests_cannot_be_overridden_and_round_trip():
    ports,behavior=pipeline()
    leaf={'name':'Pipe','purpose':'increment','ports':[asdict(p) for p in ports],
          'dependencies':[],'implementation':'three registers','design_prompt':'implement','behavior':behavior}
    top={'name':'Top','purpose':'top','ports':[],'dependencies':['Pipe'],'implementation':'connect','design_prompt':'assemble'}
    obj={'top':'Top','rationale':'test','modules':[leaf,top]}
    plan=SystemPlan.parse(obj,[],require_jobs=True)
    assert SystemPlan.parse(json.loads(json.dumps(asdict(plan))),[],require_jobs=True)==plan
    leaf['tests']=[{'name':'forged','steps':[]}]
    with pytest.raises(ValueError,match='cannot override'):SystemPlan.parse(obj,[])


def test_combinational_vectors_use_bounded_pack_and_computed_outputs():
    ports=(Port('q','input',8),Port('k','input',8),Port('s','output',9))
    model={'latency':0,'outputs':{'s':'lane(q,0,4)*lane(k,0,4)+lane(q,1,4)*lane(k,1,4)'},
           'vectors':[{'q':0,'k':0},{'q':255,'k':255},{'q':'pack(4,1,5)','k':'pack(4,5,8)'}]}
    tests=compile_tests(ports,model)
    assert tests[0]['steps'][2]['expected']=={'s':45}
    assert len(tests[0]['steps'])==15
    module=Module('Score','',ports,(),'',tests=tuple(tests),behavior=model)
    tb=module_testbench(module)
    assert "9'd45" in tb['testbench']
