# FAST — 动态稀疏注意力的全栈 Agent 协同设计

研究问题：**Can agentic full-stack co-design replace algorithm-specific manual optimization for dynamic sparse-attention acceleration?**

本次 Hackathon 要验证的是：FAST 自主完成一次有难度的跨层适配，过程可验证、配置可复用，并在公平预算下比对照有效。长期目标是在质量、面积、频率等约束下，搜索同一任务的 **latency–energy Pareto 前沿**；固定任务下，降低 J/task 等价于提高 tasks/J。

**快速上手：[新框架代码阅读与运行](docs/fullstack-generation.md) · [新系统生成实验结果](docs/results/fullstack_generation_20260913/RESULTS.md) · [历史 Critic 消融](docs/results/critic_ablation_20260911/RESULTS.md)。**

最新：[逐模块设计 → 独立组装 → 完整 E2E/PPA 实验](docs/results/fullstack_e2e_20260913/RESULTS.md)：真实生成 100/100 用例通过，源码重新编译后 600/600 次检查通过，484 项 Python 测试通过。100 MHz 下延迟 210 ns，完整顶层综合面积 7,585.256 µm²，预布局估算功耗 0.6899 mW。

**新主线：[参考库驱动的完整系统生成](docs/fullstack-generation.md)**。从这里阅读只读参考库、Kernel 实测分析、Compiler 检索并按模块分配模板、独立模块 UArch 生成并局部验证（默认逐模块执行，可配置并发）、独立组装 UArch 连接新的 Chisel 或 Verilog 系统、全系统验证/PPA，以及 Critic 跨层重入。入口为 `python -m fast.fullstack.cli`；首个可信契约是小型 threshold-attention 集成用例。串行版本的历史结果见 [完整生成系统的两轮验证](docs/results/fullstack_generation_20260913/RESULTS.md)。下面的 DynaX 入口保留用于复现历史实验。

## 当前结构

```text
FAST/
├── fast/fullstack/     新主线：库、生成契约、角色协作、验证与迭代
├── libraries/          独立只读算法契约和硬件参考模板
├── fast/schemas/       数据契约、算法标签、公共转换、阈值尺度
├── fast/agents/        提议、搜索、实现、评价、Critic 决策
├── fast/orchestrator/  五 Agent 闭环、状态重入、停止条件
├── fast/adapters/      DynaX、分析模型、RTL、综合、STA、VCD 工具接口
├── fast/storage/       SQLite 实验记录、阶段证据、产物清单
├── fast/runtime/       CHIA 调度与运行环境
├── hardware/           Chisel 实现、C++ testbench、golden 参考
├── configs/            任务、参数域、约束及预算
├── scripts/            实验入口与报告工具，见 scripts/README.md
├── tests/              Python 协议、搜索、控制流和工具适配测试
└── docs/results/       历史实验与可追溯证据
```

相邻的 `../DynaX/` 提供真实算法评估与上游基准，`../chia/` 提供运行时，`../slurm/` 提供集群作业入口。

## 历史实验入口

| 目的 | 入口 | 反馈机制 |
|---|---|---|
| 联合重搜索 `N1/N2/M/T0/T1` 和硬件参数 | [run_dynax_rediscovery.py](scripts/run_dynax_rediscovery.py) | Critic 分析算法与硬件结果，执行候选干预；独立失败后逐轮修正 |
| 从已有算法测量出发验证 Critic 闭环 | [run_codesign.py](scripts/run_codesign.py) | `FiveAgentFlow` 执行 Critic 的换候选、重规划或 RTL 修改决策 |

**联合重搜索默认启用 Critic。** `--critic auto` 为 LLM 搜索配置 LLM Critic，为随机搜索配置规则 Critic；`--critic off` 保留无 Critic 对照。每次干预占用原有候选预算，结果记录是否执行、是否扩展模型前沿以及独立验证结论。两条入口共享 Critique 契约，联合重搜索当前支持参数干预，RTL 改写仍走 FiveAgentFlow。详见 [DynaX 重搜索指南](docs/dynax-rediscovery.md)。

## 本地快速运行

在 `FAST/` 目录、可用的 Python 环境中执行：

```bash
python -m fast.cli --kernel deterministic --run-dir runs/reading-smoke
python -m pytest
python scripts/run_dynax_rediscovery.py --help
PYTHONPATH=. python scripts/run_codesign.py --help
```

第一条只运行 L0 控制流示例，不下载模型、不启动真实硬件评估。真实实验还需要 DynaX 环境、模型及相应 RTL/综合工具；LLM 方法需要配置其后端。入口用途见 [脚本索引](scripts/README.md)。

## 当前证据边界

- DynaX 提供真实 perplexity 和稀疏分布；联合搜索的延迟、面积和部分能耗仍来自 L1 模型。
- `AttentionTileSystem` 已接入分档、硬件 TopK 索引、带反压的 KeyFeeder。当前是单行执行，分数与 block mass 由外部提供；现有 system testbench 的通过条件是选择一致和流程完成。
- 阈值尺度换算已有代码和测试，完整软件 softmax 概率与硬件未归一化质量的等价性尚未闭合。
- OpenSTA 已使用全局活动率，VCD 可提供 RTL 平均翻转率；搜索中的旧功耗锚点尚未更新，不能把当前能耗前沿称为整机实测结果。

## 按需继续阅读

| 内容 | 文档 |
|---|---|
| 框架、阅读顺序、最新修复状态 | [架构导读](docs/agent-architecture.md) |
| 算法与硬件参数联合搜索 | [DynaX rediscovery](docs/dynax-rediscovery.md) |
| Critic 如何分析、执行干预和记录收益 | [Critic 接入说明](docs/critic-integration.md) |
| RTL 来源、模块验证与工具环境 | [硬件说明](hardware/README.md) |
| Hackathon 实验协议 | [延迟–能耗评估协议](docs/energy-latency-hackathon.md) |
| 既有最终配置和组件 PPA | [2026-09-11 实验报告](docs/results/final_experiment_20260911/RESULTS.md)，功耗报告早于本轮活动率修复 |
| Critic 的既有作用审计 | [Critic 审计](docs/results/critic_audit_20260911/REVIEW.md) |
| 本次整理范围与验证 | [整理记录](docs/cleanup-2026-09-11.md) |
