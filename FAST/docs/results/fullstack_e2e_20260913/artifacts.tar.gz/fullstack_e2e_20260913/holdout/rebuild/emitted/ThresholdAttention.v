module ScoreAndWeightUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 4:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 5:17]
  input         valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 6:20]
  input  [7:0]  q_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 7:16]
  input  [7:0]  k_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 8:16]
  input  [3:0]  v_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 9:16]
  output [8:0]  weight_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 12:22]
  output [12:0] weighted_v_out // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 13:26]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
`endif // RANDOMIZE_REG_INIT
  reg [8:0] score_s1_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 18:31]
  reg [3:0] v_in_s1_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 19:30]
  reg  valid_s1_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 20:31]
  wire [3:0] q0 = q_in[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 23:18]
  wire [3:0] q1 = q_in[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 24:18]
  wire [3:0] k0 = k_in[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 25:18]
  wire [3:0] k1 = k_in[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 26:18]
  wire [7:0] _score_s0_T = q0 * k0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 30:24]
  wire [7:0] _score_s0_T_1 = q1 * k1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 30:37]
  wire [8:0] score_s0 = _score_s0_T + _score_s0_T_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 30:30]
  reg [8:0] weight_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 41:33]
  reg [12:0] weighted_v_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 42:37]
  wire [8:0] weight_s1 = score_s1_reg >= 9'h40 ? score_s1_reg : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 47:24]
  wire [12:0] weighted_v_s1 = weight_s1 * v_in_s1_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 50:35]
  assign weight_out = weight_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 61:16]
  assign weighted_v_out = weighted_v_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 62:20]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 18:31]
      score_s1_reg <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 18:31]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 34:20]
      score_s1_reg <= score_s0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 35:20]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 19:30]
      v_in_s1_reg <= 4'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 19:30]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 34:20]
      v_in_s1_reg <= v_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 36:19]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 20:31]
      valid_s1_reg <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 20:31]
    end else begin
      valid_s1_reg <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 33:18]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 41:33]
      weight_out_reg <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 41:33]
    end else if (valid_s1_reg) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 54:24]
      if (score_s1_reg >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 47:24]
        weight_out_reg <= score_s1_reg;
      end else begin
        weight_out_reg <= 9'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 42:37]
      weighted_v_out_reg <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 42:37]
    end else if (valid_s1_reg) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 54:24]
      weighted_v_out_reg <= weighted_v_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ScoreAndWeightUnit.scala 56:26]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  score_s1_reg = _RAND_0[8:0];
  _RAND_1 = {1{`RANDOM}};
  v_in_s1_reg = _RAND_1[3:0];
  _RAND_2 = {1{`RANDOM}};
  valid_s1_reg = _RAND_2[0:0];
  _RAND_3 = {1{`RANDOM}};
  weight_out_reg = _RAND_3[8:0];
  _RAND_4 = {1{`RANDOM}};
  weighted_v_out_reg = _RAND_4[12:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module UnsignedDivider(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 6:17]
  input         valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 7:20]
  input  [14:0] numer, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 8:17]
  input  [10:0] denom, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 9:17]
  output        valid_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 10:21]
  output [3:0]  quot // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 11:16]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [31:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [31:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
  reg [31:0] _RAND_63;
  reg [31:0] _RAND_64;
  reg [31:0] _RAND_65;
  reg [31:0] _RAND_66;
  reg [31:0] _RAND_67;
  reg [31:0] _RAND_68;
  reg [31:0] _RAND_69;
  reg [31:0] _RAND_70;
  reg [31:0] _RAND_71;
  reg [31:0] _RAND_72;
  reg [31:0] _RAND_73;
  reg [31:0] _RAND_74;
  reg [31:0] _RAND_75;
  reg [31:0] _RAND_76;
  reg [31:0] _RAND_77;
  reg [31:0] _RAND_78;
  reg [31:0] _RAND_79;
  reg [31:0] _RAND_80;
  reg [31:0] _RAND_81;
  reg [31:0] _RAND_82;
  reg [31:0] _RAND_83;
  reg [31:0] _RAND_84;
  reg [31:0] _RAND_85;
  reg [31:0] _RAND_86;
  reg [31:0] _RAND_87;
`endif // RANDOMIZE_REG_INIT
  wire  s0_state_is_denom_zero = denom == 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 40:36]
  reg [14:0] final_state_comb_stage_in_reg_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem = {11'h0,final_state_comb_stage_in_reg_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext = {1'h0,final_state_comb_stage_in_reg_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits = final_state_comb_partial_rem >= final_state_comb_divisor_ext; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff = final_state_comb_partial_rem - final_state_comb_divisor_ext; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_quotient = {14'h0,final_state_comb_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T = {final_state_comb_stage_in_reg_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_1_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_1_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_1 = {final_state_comb_stage_in_reg_1_remainder[10:0],
    final_state_comb_stage_in_reg_1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_1 = {1'h0,final_state_comb_stage_in_reg_1_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_1 = final_state_comb_partial_rem_1 >= final_state_comb_divisor_ext_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_1 = final_state_comb_partial_rem_1 - final_state_comb_divisor_ext_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_1_quotient = {final_state_comb_stage_in_reg_1_quotient[13:0],
    final_state_comb_fits_1}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_1 = {final_state_comb_stage_in_reg_1_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_2_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_2_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_2 = {final_state_comb_stage_in_reg_2_remainder[10:0],
    final_state_comb_stage_in_reg_2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_2 = {1'h0,final_state_comb_stage_in_reg_2_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_2 = final_state_comb_partial_rem_2 >= final_state_comb_divisor_ext_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_2 = final_state_comb_partial_rem_2 - final_state_comb_divisor_ext_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_2_quotient = {final_state_comb_stage_in_reg_2_quotient[13:0],
    final_state_comb_fits_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_2 = {final_state_comb_stage_in_reg_2_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_3_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_3_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_3 = {final_state_comb_stage_in_reg_3_remainder[10:0],
    final_state_comb_stage_in_reg_3_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_3 = {1'h0,final_state_comb_stage_in_reg_3_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_3 = final_state_comb_partial_rem_3 >= final_state_comb_divisor_ext_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_3 = final_state_comb_partial_rem_3 - final_state_comb_divisor_ext_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_3_quotient = {final_state_comb_stage_in_reg_3_quotient[13:0],
    final_state_comb_fits_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_3 = {final_state_comb_stage_in_reg_3_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_4_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_4_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_4 = {final_state_comb_stage_in_reg_4_remainder[10:0],
    final_state_comb_stage_in_reg_4_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_4 = {1'h0,final_state_comb_stage_in_reg_4_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_4 = final_state_comb_partial_rem_4 >= final_state_comb_divisor_ext_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_4 = final_state_comb_partial_rem_4 - final_state_comb_divisor_ext_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_4_quotient = {final_state_comb_stage_in_reg_4_quotient[13:0],
    final_state_comb_fits_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_4 = {final_state_comb_stage_in_reg_4_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_5_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_5_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_5 = {final_state_comb_stage_in_reg_5_remainder[10:0],
    final_state_comb_stage_in_reg_5_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_5 = {1'h0,final_state_comb_stage_in_reg_5_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_5 = final_state_comb_partial_rem_5 >= final_state_comb_divisor_ext_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_5 = final_state_comb_partial_rem_5 - final_state_comb_divisor_ext_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_5_quotient = {final_state_comb_stage_in_reg_5_quotient[13:0],
    final_state_comb_fits_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_5 = {final_state_comb_stage_in_reg_5_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_6_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_6_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_6 = {final_state_comb_stage_in_reg_6_remainder[10:0],
    final_state_comb_stage_in_reg_6_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_6 = {1'h0,final_state_comb_stage_in_reg_6_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_6 = final_state_comb_partial_rem_6 >= final_state_comb_divisor_ext_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_6 = final_state_comb_partial_rem_6 - final_state_comb_divisor_ext_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_6_quotient = {final_state_comb_stage_in_reg_6_quotient[13:0],
    final_state_comb_fits_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_6 = {final_state_comb_stage_in_reg_6_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_7_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_7_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_7 = {final_state_comb_stage_in_reg_7_remainder[10:0],
    final_state_comb_stage_in_reg_7_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_7 = {1'h0,final_state_comb_stage_in_reg_7_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_7 = final_state_comb_partial_rem_7 >= final_state_comb_divisor_ext_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_7 = final_state_comb_partial_rem_7 - final_state_comb_divisor_ext_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_7_quotient = {final_state_comb_stage_in_reg_7_quotient[13:0],
    final_state_comb_fits_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_7 = {final_state_comb_stage_in_reg_7_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_8_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_8_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_8 = {final_state_comb_stage_in_reg_8_remainder[10:0],
    final_state_comb_stage_in_reg_8_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_8 = {1'h0,final_state_comb_stage_in_reg_8_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_8 = final_state_comb_partial_rem_8 >= final_state_comb_divisor_ext_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_8 = final_state_comb_partial_rem_8 - final_state_comb_divisor_ext_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_8_quotient = {final_state_comb_stage_in_reg_8_quotient[13:0],
    final_state_comb_fits_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_8 = {final_state_comb_stage_in_reg_8_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_9_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_9_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_9 = {final_state_comb_stage_in_reg_9_remainder[10:0],
    final_state_comb_stage_in_reg_9_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_9 = {1'h0,final_state_comb_stage_in_reg_9_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_9 = final_state_comb_partial_rem_9 >= final_state_comb_divisor_ext_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_9 = final_state_comb_partial_rem_9 - final_state_comb_divisor_ext_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_9_quotient = {final_state_comb_stage_in_reg_9_quotient[13:0],
    final_state_comb_fits_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_9 = {final_state_comb_stage_in_reg_9_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_10_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_10_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_10 = {final_state_comb_stage_in_reg_10_remainder[10:0],
    final_state_comb_stage_in_reg_10_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_10 = {1'h0,final_state_comb_stage_in_reg_10_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_10 = final_state_comb_partial_rem_10 >= final_state_comb_divisor_ext_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_10 = final_state_comb_partial_rem_10 - final_state_comb_divisor_ext_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_10_quotient = {final_state_comb_stage_in_reg_10_quotient[13:0],
    final_state_comb_fits_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_10 = {final_state_comb_stage_in_reg_10_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_11_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_11_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_11 = {final_state_comb_stage_in_reg_11_remainder[10:0],
    final_state_comb_stage_in_reg_11_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_11 = {1'h0,final_state_comb_stage_in_reg_11_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_11 = final_state_comb_partial_rem_11 >= final_state_comb_divisor_ext_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_11 = final_state_comb_partial_rem_11 - final_state_comb_divisor_ext_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_11_quotient = {final_state_comb_stage_in_reg_11_quotient[13:0],
    final_state_comb_fits_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_11 = {final_state_comb_stage_in_reg_11_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_12_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_12_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_12 = {final_state_comb_stage_in_reg_12_remainder[10:0],
    final_state_comb_stage_in_reg_12_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_12 = {1'h0,final_state_comb_stage_in_reg_12_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_12 = final_state_comb_partial_rem_12 >= final_state_comb_divisor_ext_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_12 = final_state_comb_partial_rem_12 - final_state_comb_divisor_ext_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_12_quotient = {final_state_comb_stage_in_reg_12_quotient[13:0],
    final_state_comb_fits_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_12 = {final_state_comb_stage_in_reg_12_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_13_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_13_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_13 = {final_state_comb_stage_in_reg_13_remainder[10:0],
    final_state_comb_stage_in_reg_13_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_13 = {1'h0,final_state_comb_stage_in_reg_13_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_13 = final_state_comb_partial_rem_13 >= final_state_comb_divisor_ext_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [11:0] final_state_comb_diff_13 = final_state_comb_partial_rem_13 - final_state_comb_divisor_ext_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 60:28]
  wire [14:0] final_state_comb_stage_out_comb_13_quotient = {final_state_comb_stage_in_reg_13_quotient[13:0],
    final_state_comb_fits_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [15:0] _final_state_comb_stage_out_comb_dividend_T_13 = {final_state_comb_stage_in_reg_13_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 67:54]
  reg [11:0] final_state_comb_stage_in_reg_14_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_14_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [14:0] final_state_comb_stage_in_reg_14_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg [10:0] final_state_comb_stage_in_reg_14_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_14_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  reg  final_state_comb_stage_in_reg_14_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
  wire [11:0] final_state_comb_partial_rem_14 = {final_state_comb_stage_in_reg_14_remainder[10:0],
    final_state_comb_stage_in_reg_14_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 55:26]
  wire [11:0] final_state_comb_divisor_ext_14 = {1'h0,final_state_comb_stage_in_reg_14_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 57:26]
  wire  final_state_comb_fits_14 = final_state_comb_partial_rem_14 >= final_state_comb_divisor_ext_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 59:28]
  wire [14:0] final_state_comb_quotient = {final_state_comb_stage_in_reg_14_quotient[13:0],final_state_comb_fits_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 65:35]
  wire [14:0] final_state_comb_stage_out_comb_dividend = _final_state_comb_stage_out_comb_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_1_dividend = _final_state_comb_stage_out_comb_dividend_T_1[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_2_dividend = _final_state_comb_stage_out_comb_dividend_T_2[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_3_dividend = _final_state_comb_stage_out_comb_dividend_T_3[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_4_dividend = _final_state_comb_stage_out_comb_dividend_T_4[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_5_dividend = _final_state_comb_stage_out_comb_dividend_T_5[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_6_dividend = _final_state_comb_stage_out_comb_dividend_T_6[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_7_dividend = _final_state_comb_stage_out_comb_dividend_T_7[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_8_dividend = _final_state_comb_stage_out_comb_dividend_T_8[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_9_dividend = _final_state_comb_stage_out_comb_dividend_T_9[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_10_dividend = _final_state_comb_stage_out_comb_dividend_T_10[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_11_dividend = _final_state_comb_stage_out_comb_dividend_T_11[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_12_dividend = _final_state_comb_stage_out_comb_dividend_T_12[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  wire [14:0] final_state_comb_stage_out_comb_13_dividend = _final_state_comb_stage_out_comb_dividend_T_13[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 67:29]
  assign valid_out = final_state_comb_stage_in_reg_14_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 52:30 72:26]
  assign quot = final_state_comb_stage_in_reg_14_is_denom_zero ? 4'h0 : final_state_comb_quotient[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 81:14]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_dividend <= numer; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_divisor <= denom; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_is_denom_zero <= reset | s0_state_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_valid <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_1_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_1_remainder <= final_state_comb_diff;
    end else begin
      final_state_comb_stage_in_reg_1_remainder <= final_state_comb_partial_rem;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_1_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_1_quotient <= final_state_comb_stage_out_comb_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_1_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_1_dividend <= final_state_comb_stage_out_comb_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_1_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_1_divisor <= final_state_comb_stage_in_reg_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_1_is_denom_zero <= reset | final_state_comb_stage_in_reg_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_1_valid <= final_state_comb_stage_in_reg_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_2_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_1) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_2_remainder <= final_state_comb_diff_1;
    end else begin
      final_state_comb_stage_in_reg_2_remainder <= final_state_comb_partial_rem_1;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_2_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_2_quotient <= final_state_comb_stage_out_comb_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_2_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_2_dividend <= final_state_comb_stage_out_comb_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_2_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_2_divisor <= final_state_comb_stage_in_reg_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_2_is_denom_zero <= reset | final_state_comb_stage_in_reg_1_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_2_valid <= final_state_comb_stage_in_reg_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_3_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_3_remainder <= final_state_comb_diff_2;
    end else begin
      final_state_comb_stage_in_reg_3_remainder <= final_state_comb_partial_rem_2;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_3_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_3_quotient <= final_state_comb_stage_out_comb_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_3_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_3_dividend <= final_state_comb_stage_out_comb_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_3_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_3_divisor <= final_state_comb_stage_in_reg_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_3_is_denom_zero <= reset | final_state_comb_stage_in_reg_2_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_3_valid <= final_state_comb_stage_in_reg_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_4_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_4_remainder <= final_state_comb_diff_3;
    end else begin
      final_state_comb_stage_in_reg_4_remainder <= final_state_comb_partial_rem_3;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_4_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_4_quotient <= final_state_comb_stage_out_comb_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_4_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_4_dividend <= final_state_comb_stage_out_comb_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_4_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_4_divisor <= final_state_comb_stage_in_reg_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_4_is_denom_zero <= reset | final_state_comb_stage_in_reg_3_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_4_valid <= final_state_comb_stage_in_reg_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_5_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_4) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_5_remainder <= final_state_comb_diff_4;
    end else begin
      final_state_comb_stage_in_reg_5_remainder <= final_state_comb_partial_rem_4;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_5_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_5_quotient <= final_state_comb_stage_out_comb_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_5_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_5_dividend <= final_state_comb_stage_out_comb_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_5_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_5_divisor <= final_state_comb_stage_in_reg_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_5_is_denom_zero <= reset | final_state_comb_stage_in_reg_4_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_5_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_5_valid <= final_state_comb_stage_in_reg_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_6_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_6_remainder <= final_state_comb_diff_5;
    end else begin
      final_state_comb_stage_in_reg_6_remainder <= final_state_comb_partial_rem_5;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_6_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_6_quotient <= final_state_comb_stage_out_comb_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_6_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_6_dividend <= final_state_comb_stage_out_comb_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_6_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_6_divisor <= final_state_comb_stage_in_reg_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_6_is_denom_zero <= reset | final_state_comb_stage_in_reg_5_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_6_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_6_valid <= final_state_comb_stage_in_reg_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_7_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_6) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_7_remainder <= final_state_comb_diff_6;
    end else begin
      final_state_comb_stage_in_reg_7_remainder <= final_state_comb_partial_rem_6;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_7_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_7_quotient <= final_state_comb_stage_out_comb_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_7_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_7_dividend <= final_state_comb_stage_out_comb_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_7_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_7_divisor <= final_state_comb_stage_in_reg_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_7_is_denom_zero <= reset | final_state_comb_stage_in_reg_6_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_7_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_7_valid <= final_state_comb_stage_in_reg_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_8_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_7) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_8_remainder <= final_state_comb_diff_7;
    end else begin
      final_state_comb_stage_in_reg_8_remainder <= final_state_comb_partial_rem_7;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_8_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_8_quotient <= final_state_comb_stage_out_comb_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_8_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_8_dividend <= final_state_comb_stage_out_comb_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_8_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_8_divisor <= final_state_comb_stage_in_reg_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_8_is_denom_zero <= reset | final_state_comb_stage_in_reg_7_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_8_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_8_valid <= final_state_comb_stage_in_reg_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_9_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_9_remainder <= final_state_comb_diff_8;
    end else begin
      final_state_comb_stage_in_reg_9_remainder <= final_state_comb_partial_rem_8;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_9_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_9_quotient <= final_state_comb_stage_out_comb_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_9_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_9_dividend <= final_state_comb_stage_out_comb_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_9_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_9_divisor <= final_state_comb_stage_in_reg_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_9_is_denom_zero <= reset | final_state_comb_stage_in_reg_8_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_9_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_9_valid <= final_state_comb_stage_in_reg_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_10_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_9) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_10_remainder <= final_state_comb_diff_9;
    end else begin
      final_state_comb_stage_in_reg_10_remainder <= final_state_comb_partial_rem_9;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_10_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_10_quotient <= final_state_comb_stage_out_comb_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_10_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_10_dividend <= final_state_comb_stage_out_comb_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_10_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_10_divisor <= final_state_comb_stage_in_reg_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_10_is_denom_zero <= reset | final_state_comb_stage_in_reg_9_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_10_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_10_valid <= final_state_comb_stage_in_reg_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_11_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_10) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_11_remainder <= final_state_comb_diff_10;
    end else begin
      final_state_comb_stage_in_reg_11_remainder <= final_state_comb_partial_rem_10;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_11_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_11_quotient <= final_state_comb_stage_out_comb_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_11_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_11_dividend <= final_state_comb_stage_out_comb_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_11_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_11_divisor <= final_state_comb_stage_in_reg_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_11_is_denom_zero <= reset | final_state_comb_stage_in_reg_10_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_11_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_11_valid <= final_state_comb_stage_in_reg_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_12_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_12_remainder <= final_state_comb_diff_11;
    end else begin
      final_state_comb_stage_in_reg_12_remainder <= final_state_comb_partial_rem_11;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_12_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_12_quotient <= final_state_comb_stage_out_comb_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_12_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_12_dividend <= final_state_comb_stage_out_comb_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_12_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_12_divisor <= final_state_comb_stage_in_reg_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_12_is_denom_zero <= reset | final_state_comb_stage_in_reg_11_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_12_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_12_valid <= final_state_comb_stage_in_reg_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_13_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_12) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_13_remainder <= final_state_comb_diff_12;
    end else begin
      final_state_comb_stage_in_reg_13_remainder <= final_state_comb_partial_rem_12;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_13_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_13_quotient <= final_state_comb_stage_out_comb_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_13_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_13_dividend <= final_state_comb_stage_out_comb_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_13_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_13_divisor <= final_state_comb_stage_in_reg_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_13_is_denom_zero <= reset | final_state_comb_stage_in_reg_12_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_13_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_13_valid <= final_state_comb_stage_in_reg_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_14_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else if (final_state_comb_fits_13) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 63:36]
      final_state_comb_stage_in_reg_14_remainder <= final_state_comb_diff_13;
    end else begin
      final_state_comb_stage_in_reg_14_remainder <= final_state_comb_partial_rem_13;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_14_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_14_quotient <= final_state_comb_stage_out_comb_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_14_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_14_dividend <= final_state_comb_stage_out_comb_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_14_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_14_divisor <= final_state_comb_stage_in_reg_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
    final_state_comb_stage_in_reg_14_is_denom_zero <= reset | final_state_comb_stage_in_reg_13_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
      final_state_comb_stage_in_reg_14_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end else begin
      final_state_comb_stage_in_reg_14_valid <= final_state_comb_stage_in_reg_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/UnsignedDivider.scala 48:14]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_dividend = _RAND_0[14:0];
  _RAND_1 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_divisor = _RAND_1[10:0];
  _RAND_2 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_is_denom_zero = _RAND_2[0:0];
  _RAND_3 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_valid = _RAND_3[0:0];
  _RAND_4 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_1_remainder = _RAND_4[11:0];
  _RAND_5 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_1_quotient = _RAND_5[14:0];
  _RAND_6 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_1_dividend = _RAND_6[14:0];
  _RAND_7 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_1_divisor = _RAND_7[10:0];
  _RAND_8 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_1_is_denom_zero = _RAND_8[0:0];
  _RAND_9 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_1_valid = _RAND_9[0:0];
  _RAND_10 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_2_remainder = _RAND_10[11:0];
  _RAND_11 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_2_quotient = _RAND_11[14:0];
  _RAND_12 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_2_dividend = _RAND_12[14:0];
  _RAND_13 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_2_divisor = _RAND_13[10:0];
  _RAND_14 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_2_is_denom_zero = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_2_valid = _RAND_15[0:0];
  _RAND_16 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_3_remainder = _RAND_16[11:0];
  _RAND_17 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_3_quotient = _RAND_17[14:0];
  _RAND_18 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_3_dividend = _RAND_18[14:0];
  _RAND_19 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_3_divisor = _RAND_19[10:0];
  _RAND_20 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_3_is_denom_zero = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_3_valid = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_4_remainder = _RAND_22[11:0];
  _RAND_23 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_4_quotient = _RAND_23[14:0];
  _RAND_24 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_4_dividend = _RAND_24[14:0];
  _RAND_25 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_4_divisor = _RAND_25[10:0];
  _RAND_26 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_4_is_denom_zero = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_4_valid = _RAND_27[0:0];
  _RAND_28 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_5_remainder = _RAND_28[11:0];
  _RAND_29 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_5_quotient = _RAND_29[14:0];
  _RAND_30 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_5_dividend = _RAND_30[14:0];
  _RAND_31 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_5_divisor = _RAND_31[10:0];
  _RAND_32 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_5_is_denom_zero = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_5_valid = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_6_remainder = _RAND_34[11:0];
  _RAND_35 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_6_quotient = _RAND_35[14:0];
  _RAND_36 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_6_dividend = _RAND_36[14:0];
  _RAND_37 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_6_divisor = _RAND_37[10:0];
  _RAND_38 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_6_is_denom_zero = _RAND_38[0:0];
  _RAND_39 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_6_valid = _RAND_39[0:0];
  _RAND_40 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_7_remainder = _RAND_40[11:0];
  _RAND_41 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_7_quotient = _RAND_41[14:0];
  _RAND_42 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_7_dividend = _RAND_42[14:0];
  _RAND_43 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_7_divisor = _RAND_43[10:0];
  _RAND_44 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_7_is_denom_zero = _RAND_44[0:0];
  _RAND_45 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_7_valid = _RAND_45[0:0];
  _RAND_46 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_8_remainder = _RAND_46[11:0];
  _RAND_47 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_8_quotient = _RAND_47[14:0];
  _RAND_48 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_8_dividend = _RAND_48[14:0];
  _RAND_49 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_8_divisor = _RAND_49[10:0];
  _RAND_50 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_8_is_denom_zero = _RAND_50[0:0];
  _RAND_51 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_8_valid = _RAND_51[0:0];
  _RAND_52 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_9_remainder = _RAND_52[11:0];
  _RAND_53 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_9_quotient = _RAND_53[14:0];
  _RAND_54 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_9_dividend = _RAND_54[14:0];
  _RAND_55 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_9_divisor = _RAND_55[10:0];
  _RAND_56 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_9_is_denom_zero = _RAND_56[0:0];
  _RAND_57 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_9_valid = _RAND_57[0:0];
  _RAND_58 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_10_remainder = _RAND_58[11:0];
  _RAND_59 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_10_quotient = _RAND_59[14:0];
  _RAND_60 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_10_dividend = _RAND_60[14:0];
  _RAND_61 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_10_divisor = _RAND_61[10:0];
  _RAND_62 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_10_is_denom_zero = _RAND_62[0:0];
  _RAND_63 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_10_valid = _RAND_63[0:0];
  _RAND_64 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_11_remainder = _RAND_64[11:0];
  _RAND_65 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_11_quotient = _RAND_65[14:0];
  _RAND_66 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_11_dividend = _RAND_66[14:0];
  _RAND_67 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_11_divisor = _RAND_67[10:0];
  _RAND_68 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_11_is_denom_zero = _RAND_68[0:0];
  _RAND_69 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_11_valid = _RAND_69[0:0];
  _RAND_70 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_12_remainder = _RAND_70[11:0];
  _RAND_71 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_12_quotient = _RAND_71[14:0];
  _RAND_72 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_12_dividend = _RAND_72[14:0];
  _RAND_73 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_12_divisor = _RAND_73[10:0];
  _RAND_74 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_12_is_denom_zero = _RAND_74[0:0];
  _RAND_75 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_12_valid = _RAND_75[0:0];
  _RAND_76 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_13_remainder = _RAND_76[11:0];
  _RAND_77 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_13_quotient = _RAND_77[14:0];
  _RAND_78 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_13_dividend = _RAND_78[14:0];
  _RAND_79 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_13_divisor = _RAND_79[10:0];
  _RAND_80 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_13_is_denom_zero = _RAND_80[0:0];
  _RAND_81 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_13_valid = _RAND_81[0:0];
  _RAND_82 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_14_remainder = _RAND_82[11:0];
  _RAND_83 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_14_quotient = _RAND_83[14:0];
  _RAND_84 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_14_dividend = _RAND_84[14:0];
  _RAND_85 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_14_divisor = _RAND_85[10:0];
  _RAND_86 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_14_is_denom_zero = _RAND_86[0:0];
  _RAND_87 = {1{`RANDOM}};
  final_state_comb_stage_in_reg_14_valid = _RAND_87[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module ThresholdAttention(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 6:17]
  input         start, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 7:17]
  input  [7:0]  q, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 8:13]
  input  [31:0] k, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 9:13]
  input  [15:0] v, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 10:13]
  output        done, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 11:16]
  output [3:0]  result // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 12:18]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
`endif // RANDOMIZE_REG_INIT
  wire  saw_units_0_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_0_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_0_valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_0_q_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_0_k_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [3:0] saw_units_0_v_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [8:0] saw_units_0_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [12:0] saw_units_0_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_1_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_1_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_1_valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_1_q_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_1_k_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [3:0] saw_units_1_v_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [8:0] saw_units_1_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [12:0] saw_units_1_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_2_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_2_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_2_valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_2_q_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_2_k_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [3:0] saw_units_2_v_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [8:0] saw_units_2_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [12:0] saw_units_2_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_3_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_3_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  saw_units_3_valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_3_q_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [7:0] saw_units_3_k_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [3:0] saw_units_3_v_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [8:0] saw_units_3_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire [12:0] saw_units_3_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
  wire  divider_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  wire  divider_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  wire  divider_valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  wire [14:0] divider_numer; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  wire [10:0] divider_denom; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  wire  divider_valid_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  wire [3:0] divider_quot; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
  reg  s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 24:27]
  reg [7:0] q_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 25:23]
  reg [31:0] k_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 26:23]
  reg [15:0] v_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 27:23]
  reg  s3_valid_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:35]
  reg  s3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:27]
  wire [8:0] saw_weights_0 = saw_units_0_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 39:27 49:22]
  wire [8:0] saw_weights_1 = saw_units_1_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 39:27 49:22]
  wire [9:0] w_sum_01_s3 = saw_weights_0 + saw_weights_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 57:38]
  wire [8:0] saw_weights_2 = saw_units_2_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 39:27 49:22]
  wire [8:0] saw_weights_3 = saw_units_3_weight_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 39:27 49:22]
  wire [9:0] w_sum_23_s3 = saw_weights_2 + saw_weights_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 58:38]
  wire [12:0] saw_weighted_vs_0 = saw_units_0_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 40:31 50:26]
  wire [12:0] saw_weighted_vs_1 = saw_units_1_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 40:31 50:26]
  wire [13:0] wv_sum_01_s3 = saw_weighted_vs_0 + saw_weighted_vs_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 59:43]
  wire [12:0] saw_weighted_vs_2 = saw_units_2_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 40:31 50:26]
  wire [12:0] saw_weighted_vs_3 = saw_units_3_weighted_v_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 40:31 50:26]
  wire [13:0] wv_sum_23_s3 = saw_weighted_vs_2 + saw_weighted_vs_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 60:43]
  reg  s4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 62:27]
  reg [9:0] w_sum_01_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 63:30]
  reg [9:0] w_sum_23_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 64:30]
  reg [13:0] wv_sum_01_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 65:31]
  reg [13:0] wv_sum_23_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 66:31]
  wire [10:0] weight_sum_s4 = w_sum_01_s4 + w_sum_23_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 70:37]
  wire [14:0] weighted_v_sum_s4 = wv_sum_01_s4 + wv_sum_23_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 71:42]
  reg  s5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 73:27]
  reg [10:0] weight_sum_s5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 74:32]
  reg [14:0] weighted_v_sum_s5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 75:36]
  reg  s21_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 90:28]
  reg [3:0] result_s21; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 91:29]
  ScoreAndWeightUnit saw_units_0 ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
    .clock(saw_units_0_clock),
    .reset(saw_units_0_reset),
    .valid_in(saw_units_0_valid_in),
    .q_in(saw_units_0_q_in),
    .k_in(saw_units_0_k_in),
    .v_in(saw_units_0_v_in),
    .weight_out(saw_units_0_weight_out),
    .weighted_v_out(saw_units_0_weighted_v_out)
  );
  ScoreAndWeightUnit saw_units_1 ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
    .clock(saw_units_1_clock),
    .reset(saw_units_1_reset),
    .valid_in(saw_units_1_valid_in),
    .q_in(saw_units_1_q_in),
    .k_in(saw_units_1_k_in),
    .v_in(saw_units_1_v_in),
    .weight_out(saw_units_1_weight_out),
    .weighted_v_out(saw_units_1_weighted_v_out)
  );
  ScoreAndWeightUnit saw_units_2 ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
    .clock(saw_units_2_clock),
    .reset(saw_units_2_reset),
    .valid_in(saw_units_2_valid_in),
    .q_in(saw_units_2_q_in),
    .k_in(saw_units_2_k_in),
    .v_in(saw_units_2_v_in),
    .weight_out(saw_units_2_weight_out),
    .weighted_v_out(saw_units_2_weighted_v_out)
  );
  ScoreAndWeightUnit saw_units_3 ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 38:39]
    .clock(saw_units_3_clock),
    .reset(saw_units_3_reset),
    .valid_in(saw_units_3_valid_in),
    .q_in(saw_units_3_q_in),
    .k_in(saw_units_3_k_in),
    .v_in(saw_units_3_v_in),
    .weight_out(saw_units_3_weight_out),
    .weighted_v_out(saw_units_3_weighted_v_out)
  );
  UnsignedDivider divider ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 78:25]
    .clock(divider_clock),
    .reset(divider_reset),
    .valid_in(divider_valid_in),
    .numer(divider_numer),
    .denom(divider_denom),
    .valid_out(divider_valid_out),
    .quot(divider_quot)
  );
  assign done = s21_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 96:10]
  assign result = result_s21; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 97:12]
  assign saw_units_0_clock = clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 43:26]
  assign saw_units_0_reset = reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 44:26]
  assign saw_units_0_valid_in = s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 45:29]
  assign saw_units_0_q_in = q_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 46:25]
  assign saw_units_0_k_in = k_s1[7:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 33:26]
  assign saw_units_0_v_in = v_s1[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 34:26]
  assign saw_units_1_clock = clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 43:26]
  assign saw_units_1_reset = reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 44:26]
  assign saw_units_1_valid_in = s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 45:29]
  assign saw_units_1_q_in = q_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 46:25]
  assign saw_units_1_k_in = k_s1[15:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 33:26]
  assign saw_units_1_v_in = v_s1[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 34:26]
  assign saw_units_2_clock = clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 43:26]
  assign saw_units_2_reset = reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 44:26]
  assign saw_units_2_valid_in = s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 45:29]
  assign saw_units_2_q_in = q_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 46:25]
  assign saw_units_2_k_in = k_s1[23:16]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 33:26]
  assign saw_units_2_v_in = v_s1[11:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 34:26]
  assign saw_units_3_clock = clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 43:26]
  assign saw_units_3_reset = reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 44:26]
  assign saw_units_3_valid_in = s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 45:29]
  assign saw_units_3_q_in = q_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 46:25]
  assign saw_units_3_k_in = k_s1[31:24]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 33:26]
  assign saw_units_3_v_in = v_s1[15:12]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 34:26]
  assign divider_clock = clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 79:19]
  assign divider_reset = reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 80:19]
  assign divider_valid_in = s5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 81:22]
  assign divider_numer = weighted_v_sum_s5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 82:19]
  assign divider_denom = weight_sum_s5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 83:19]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 24:27]
      s1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 24:27]
    end else begin
      s1_valid <= start; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 24:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 25:23]
      q_s1 <= 8'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 25:23]
    end else begin
      q_s1 <= q; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 25:23]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 26:23]
      k_s1 <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 26:23]
    end else begin
      k_s1 <= k; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 26:23]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 27:23]
      v_s1 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 27:23]
    end else begin
      v_s1 <= v; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 27:23]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:35]
      s3_valid_REG <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:35]
    end else begin
      s3_valid_REG <= s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:35]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:27]
      s3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:27]
    end else begin
      s3_valid <= s3_valid_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 53:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 62:27]
      s4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 62:27]
    end else begin
      s4_valid <= s3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 62:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 63:30]
      w_sum_01_s4 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 63:30]
    end else begin
      w_sum_01_s4 <= w_sum_01_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 63:30]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 64:30]
      w_sum_23_s4 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 64:30]
    end else begin
      w_sum_23_s4 <= w_sum_23_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 64:30]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 65:31]
      wv_sum_01_s4 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 65:31]
    end else begin
      wv_sum_01_s4 <= wv_sum_01_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 65:31]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 66:31]
      wv_sum_23_s4 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 66:31]
    end else begin
      wv_sum_23_s4 <= wv_sum_23_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 66:31]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 73:27]
      s5_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 73:27]
    end else begin
      s5_valid <= s4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 73:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 74:32]
      weight_sum_s5 <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 74:32]
    end else begin
      weight_sum_s5 <= weight_sum_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 74:32]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 75:36]
      weighted_v_sum_s5 <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 75:36]
    end else begin
      weighted_v_sum_s5 <= weighted_v_sum_s4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 75:36]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 90:28]
      s21_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 90:28]
    end else begin
      s21_valid <= divider_valid_out; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 90:28]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 91:29]
      result_s21 <= 4'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 91:29]
    end else begin
      result_s21 <= divider_quot; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/holdout_17692477/rebuild/ThresholdAttention.scala 91:29]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  s1_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  q_s1 = _RAND_1[7:0];
  _RAND_2 = {1{`RANDOM}};
  k_s1 = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  v_s1 = _RAND_3[15:0];
  _RAND_4 = {1{`RANDOM}};
  s3_valid_REG = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  s3_valid = _RAND_5[0:0];
  _RAND_6 = {1{`RANDOM}};
  s4_valid = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  w_sum_01_s4 = _RAND_7[9:0];
  _RAND_8 = {1{`RANDOM}};
  w_sum_23_s4 = _RAND_8[9:0];
  _RAND_9 = {1{`RANDOM}};
  wv_sum_01_s4 = _RAND_9[13:0];
  _RAND_10 = {1{`RANDOM}};
  wv_sum_23_s4 = _RAND_10[13:0];
  _RAND_11 = {1{`RANDOM}};
  s5_valid = _RAND_11[0:0];
  _RAND_12 = {1{`RANDOM}};
  weight_sum_s5 = _RAND_12[10:0];
  _RAND_13 = {1{`RANDOM}};
  weighted_v_sum_s5 = _RAND_13[14:0];
  _RAND_14 = {1{`RANDOM}};
  s21_valid = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  result_s21 = _RAND_15[3:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
