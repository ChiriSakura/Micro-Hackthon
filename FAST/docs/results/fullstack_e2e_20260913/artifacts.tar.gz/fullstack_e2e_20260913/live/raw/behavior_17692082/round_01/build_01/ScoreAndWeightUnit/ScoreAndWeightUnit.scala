import chisel3._
import chisel3.util._

class ScoreAndWeightUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val q_in = IO(Input(UInt(8.W)))
  val k_in = IO(Input(UInt(8.W)))
  val v_in = IO(Input(UInt(4.W)))

  val valid_out = IO(Output(Bool()))
  val weight_out = IO(Output(UInt(9.W)))
  val weighted_v_out = IO(Output(UInt(13.W)))

  withClockAndReset(clock, reset) {
    // Stage 1: Calculate score
    val score_s1 = RegInit(0.U(9.W))
    val v_in_s1 = RegInit(0.U(4.W))
    val valid_s1 = RegInit(false.B)

    val q0 = q_in(3, 0)
    val q1 = q_in(7, 4)
    val k0 = k_in(3, 0)
    val k1 = k_in(7, 4)

    val prod0 = q0 * k0
    val prod1 = q1 * k1
    val score_s0 = prod0 +& prod1

    score_s1 := score_s0
    v_in_s1 := v_in
    valid_s1 := valid_in

    // Stage 2: Apply threshold and calculate weighted value
    val weight_out_reg = RegInit(0.U(9.W))
    val weighted_v_out_reg = RegInit(0.U(13.W))
    val valid_out_reg = RegInit(false.B)

    val threshold = 64.U(9.W)
    val weight_s1 = Mux(score_s1 >= threshold, score_s1, 0.U(9.W))
    val weighted_v_s1 = weight_s1 * v_in_s1

    weight_out_reg := weight_s1
    weighted_v_out_reg := weighted_v_s1
    valid_out_reg := valid_s1

    // Connect outputs
    valid_out := valid_out_reg
    weight_out := weight_out_reg
    weighted_v_out := weighted_v_out_reg
  }
}
