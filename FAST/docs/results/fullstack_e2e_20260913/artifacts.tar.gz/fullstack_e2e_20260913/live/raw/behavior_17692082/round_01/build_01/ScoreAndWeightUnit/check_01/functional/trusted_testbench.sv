module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] valid_in;
reg [7:0] q_in;
reg [7:0] k_in;
reg [3:0] v_in;
wire [0:0] valid_out;
wire [8:0] weight_out;
wire [12:0] weighted_v_out;
ScoreAndWeightUnit dut(.clock(clock),.reset(reset),.valid_in(valid_in),.q_in(q_in),.k_in(k_in),.v_in(v_in),.valid_out(valid_out),.weight_out(weight_out),.weighted_v_out(weighted_v_out));
initial begin
clock=0;
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=0 step=0 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=0 step=0 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=0 step=2 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=0 step=2 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=0 step=2 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=4 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=0 step=4 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=0 step=4 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=1 step=0 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=1 step=0 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd255;
k_in=8'd255;
v_in=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=1 step=2 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd450) $fatal(1,"module case=1 step=2 output=weight_out expected=450 actual=%0d",weight_out);
if (weighted_v_out !== 13'd6750) $fatal(1,"module case=1 step=2 output=weighted_v_out expected=6750 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=4 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=1 step=4 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=1 step=4 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=2 step=0 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=2 step=0 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd85;
k_in=8'd170;
v_in=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=2 step=2 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd100) $fatal(1,"module case=2 step=2 output=weight_out expected=100 actual=%0d",weight_out);
if (weighted_v_out !== 13'd700) $fatal(1,"module case=2 step=2 output=weighted_v_out expected=700 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=4 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=2 step=4 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=2 step=4 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=3 step=0 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=3 step=0 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd255;
k_in=8'd255;
v_in=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=2 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=3 step=2 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=3 step=2 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd85;
k_in=8'd170;
v_in=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd450) $fatal(1,"module case=3 step=3 output=weight_out expected=450 actual=%0d",weight_out);
if (weighted_v_out !== 13'd6750) $fatal(1,"module case=3 step=3 output=weighted_v_out expected=6750 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=4 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd100) $fatal(1,"module case=3 step=4 output=weight_out expected=100 actual=%0d",weight_out);
if (weighted_v_out !== 13'd700) $fatal(1,"module case=3 step=4 output=weighted_v_out expected=700 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd6;
k_in=8'd240;
v_in=4'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd201;
k_in=8'd72;
v_in=4'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=6 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=3 step=6 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=3 step=6 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd71;
k_in=8'd57;
v_in=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=7 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd120) $fatal(1,"module case=3 step=7 output=weight_out expected=120 actual=%0d",weight_out);
if (weighted_v_out !== 13'd120) $fatal(1,"module case=3 step=7 output=weighted_v_out expected=120 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=8 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd75) $fatal(1,"module case=3 step=8 output=weight_out expected=75 actual=%0d",weight_out);
if (weighted_v_out !== 13'd525) $fatal(1,"module case=3 step=8 output=weighted_v_out expected=525 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd71;
k_in=8'd75;
v_in=4'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=9 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd31;
k_in=8'd69;
v_in=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=10 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd93) $fatal(1,"module case=3 step=10 output=weight_out expected=93 actual=%0d",weight_out);
if (weighted_v_out !== 13'd93) $fatal(1,"module case=3 step=10 output=weighted_v_out expected=93 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd229;
k_in=8'd211;
v_in=4'd6;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=11 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd79) $fatal(1,"module case=3 step=11 output=weight_out expected=79 actual=%0d",weight_out);
if (weighted_v_out !== 13'd553) $fatal(1,"module case=3 step=11 output=weighted_v_out expected=553 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=12 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd197) $fatal(1,"module case=3 step=12 output=weight_out expected=197 actual=%0d",weight_out);
if (weighted_v_out !== 13'd1182) $fatal(1,"module case=3 step=12 output=weighted_v_out expected=1182 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd47;
k_in=8'd60;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=13 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd206;
k_in=8'd174;
v_in=4'd6;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=14 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd186) $fatal(1,"module case=3 step=14 output=weight_out expected=186 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=3 step=14 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd105;
k_in=8'd169;
v_in=4'd12;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=15 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd316) $fatal(1,"module case=3 step=15 output=weight_out expected=316 actual=%0d",weight_out);
if (weighted_v_out !== 13'd1896) $fatal(1,"module case=3 step=15 output=weighted_v_out expected=1896 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=16 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd141) $fatal(1,"module case=3 step=16 output=weight_out expected=141 actual=%0d",weight_out);
if (weighted_v_out !== 13'd1692) $fatal(1,"module case=3 step=16 output=weighted_v_out expected=1692 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd186;
k_in=8'd126;
v_in=4'd6;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=17 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd111;
k_in=8'd213;
v_in=4'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=18 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd217) $fatal(1,"module case=3 step=18 output=weight_out expected=217 actual=%0d",weight_out);
if (weighted_v_out !== 13'd1302) $fatal(1,"module case=3 step=18 output=weighted_v_out expected=1302 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd26;
k_in=8'd92;
v_in=4'd11;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=19 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd153) $fatal(1,"module case=3 step=19 output=weight_out expected=153 actual=%0d",weight_out);
if (weighted_v_out !== 13'd153) $fatal(1,"module case=3 step=19 output=weighted_v_out expected=153 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=20 output=valid_out expected=1 actual=%0d",valid_out);
if (weight_out !== 9'd125) $fatal(1,"module case=3 step=20 output=weight_out expected=125 actual=%0d",weight_out);
if (weighted_v_out !== 13'd1375) $fatal(1,"module case=3 step=20 output=weighted_v_out expected=1375 actual=%0d",weighted_v_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=21 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=22 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=8'd0;
v_in=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=23 output=valid_out expected=0 actual=%0d",valid_out);
if (weight_out !== 9'd0) $fatal(1,"module case=3 step=23 output=weight_out expected=0 actual=%0d",weight_out);
if (weighted_v_out !== 13'd0) $fatal(1,"module case=3 step=23 output=weighted_v_out expected=0 actual=%0d",weighted_v_out);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule