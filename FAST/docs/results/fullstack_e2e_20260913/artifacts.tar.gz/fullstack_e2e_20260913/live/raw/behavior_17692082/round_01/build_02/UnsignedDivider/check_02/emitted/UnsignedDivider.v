module UnsignedDivider(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 6:17]
  input         valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 7:20]
  input  [14:0] numer, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 8:17]
  input  [10:0] denom, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 9:17]
  output        valid_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 10:21]
  output [3:0]  quot // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 11:16]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [31:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [31:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
  reg [31:0] _RAND_63;
  reg [31:0] _RAND_64;
  reg [31:0] _RAND_65;
  reg [31:0] _RAND_66;
  reg [31:0] _RAND_67;
  reg [31:0] _RAND_68;
  reg [31:0] _RAND_69;
  reg [31:0] _RAND_70;
  reg [31:0] _RAND_71;
  reg [31:0] _RAND_72;
  reg [31:0] _RAND_73;
  reg [31:0] _RAND_74;
  reg [31:0] _RAND_75;
  reg [31:0] _RAND_76;
  reg [31:0] _RAND_77;
  reg [31:0] _RAND_78;
  reg [31:0] _RAND_79;
  reg [31:0] _RAND_80;
  reg [31:0] _RAND_81;
  reg [31:0] _RAND_82;
  reg [31:0] _RAND_83;
`endif // RANDOMIZE_REG_INIT
  wire  s0_state_is_denom_zero = denom == 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 74:36]
  wire [11:0] last_stage_out_comb_partial_rem = {11'h0,numer[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] last_stage_out_comb_divisor_ext = {1'h0,denom}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] last_stage_out_comb_diff = last_stage_out_comb_partial_rem - last_stage_out_comb_divisor_ext; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  last_stage_out_comb_quot_bit = ~last_stage_out_comb_diff[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] last_stage_out_comb_quotient = {14'h0,last_stage_out_comb_quot_bit}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] last_stage_out_comb_dividend = {numer[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem = {stage_in_reg_remainder[10:0],stage_in_reg_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext = {1'h0,stage_in_reg_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff = partial_rem - divisor_ext; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit = ~diff[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_quotient = {stage_in_reg_quotient[13:0],quot_bit}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_dividend = {stage_in_reg_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_1_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_1_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_1 = {stage_in_reg_1_remainder[10:0],stage_in_reg_1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_1 = {1'h0,stage_in_reg_1_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_1 = partial_rem_1 - divisor_ext_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_1 = ~diff_1[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_1_quotient = {stage_in_reg_1_quotient[13:0],quot_bit_1}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_1_dividend = {stage_in_reg_1_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_2_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_2_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_2 = {stage_in_reg_2_remainder[10:0],stage_in_reg_2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_2 = {1'h0,stage_in_reg_2_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_2 = partial_rem_2 - divisor_ext_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_2 = ~diff_2[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_2_quotient = {stage_in_reg_2_quotient[13:0],quot_bit_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_2_dividend = {stage_in_reg_2_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_3_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_3_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_3 = {stage_in_reg_3_remainder[10:0],stage_in_reg_3_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_3 = {1'h0,stage_in_reg_3_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_3 = partial_rem_3 - divisor_ext_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_3 = ~diff_3[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_3_quotient = {stage_in_reg_3_quotient[13:0],quot_bit_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_3_dividend = {stage_in_reg_3_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_4_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_4_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_4 = {stage_in_reg_4_remainder[10:0],stage_in_reg_4_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_4 = {1'h0,stage_in_reg_4_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_4 = partial_rem_4 - divisor_ext_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_4 = ~diff_4[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_4_quotient = {stage_in_reg_4_quotient[13:0],quot_bit_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_4_dividend = {stage_in_reg_4_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_5_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_5_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_5 = {stage_in_reg_5_remainder[10:0],stage_in_reg_5_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_5 = {1'h0,stage_in_reg_5_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_5 = partial_rem_5 - divisor_ext_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_5 = ~diff_5[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_5_quotient = {stage_in_reg_5_quotient[13:0],quot_bit_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_5_dividend = {stage_in_reg_5_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_6_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_6_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_6 = {stage_in_reg_6_remainder[10:0],stage_in_reg_6_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_6 = {1'h0,stage_in_reg_6_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_6 = partial_rem_6 - divisor_ext_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_6 = ~diff_6[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_6_quotient = {stage_in_reg_6_quotient[13:0],quot_bit_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_6_dividend = {stage_in_reg_6_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_7_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_7_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_7 = {stage_in_reg_7_remainder[10:0],stage_in_reg_7_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_7 = {1'h0,stage_in_reg_7_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_7 = partial_rem_7 - divisor_ext_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_7 = ~diff_7[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_7_quotient = {stage_in_reg_7_quotient[13:0],quot_bit_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_7_dividend = {stage_in_reg_7_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_8_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_8_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_8 = {stage_in_reg_8_remainder[10:0],stage_in_reg_8_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_8 = {1'h0,stage_in_reg_8_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_8 = partial_rem_8 - divisor_ext_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_8 = ~diff_8[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_8_quotient = {stage_in_reg_8_quotient[13:0],quot_bit_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_8_dividend = {stage_in_reg_8_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_9_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_9_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_9 = {stage_in_reg_9_remainder[10:0],stage_in_reg_9_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_9 = {1'h0,stage_in_reg_9_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_9 = partial_rem_9 - divisor_ext_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_9 = ~diff_9[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_9_quotient = {stage_in_reg_9_quotient[13:0],quot_bit_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_9_dividend = {stage_in_reg_9_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_10_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_10_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_10 = {stage_in_reg_10_remainder[10:0],stage_in_reg_10_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_10 = {1'h0,stage_in_reg_10_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_10 = partial_rem_10 - divisor_ext_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_10 = ~diff_10[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_10_quotient = {stage_in_reg_10_quotient[13:0],quot_bit_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_10_dividend = {stage_in_reg_10_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_11_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_11_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_11 = {stage_in_reg_11_remainder[10:0],stage_in_reg_11_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_11 = {1'h0,stage_in_reg_11_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_11 = partial_rem_11 - divisor_ext_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_11 = ~diff_11[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_11_quotient = {stage_in_reg_11_quotient[13:0],quot_bit_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_11_dividend = {stage_in_reg_11_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_12_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_12_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_12 = {stage_in_reg_12_remainder[10:0],stage_in_reg_12_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_12 = {1'h0,stage_in_reg_12_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_12 = partial_rem_12 - divisor_ext_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_12 = ~diff_12[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_12_quotient = {stage_in_reg_12_quotient[13:0],quot_bit_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  wire [14:0] nextState_12_dividend = {stage_in_reg_12_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 58:30]
  reg [11:0] stage_in_reg_13_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [14:0] stage_in_reg_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg [10:0] stage_in_reg_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_13_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  reg  stage_in_reg_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
  wire [11:0] partial_rem_13 = {stage_in_reg_13_remainder[10:0],stage_in_reg_13_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 45:26]
  wire [11:0] divisor_ext_13 = {1'h0,stage_in_reg_13_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 48:26]
  wire [11:0] diff_13 = partial_rem_13 - divisor_ext_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 49:28]
  wire  quot_bit_13 = ~diff_13[11]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 51:20]
  wire [14:0] nextState_13_quotient = {stage_in_reg_13_quotient[13:0],quot_bit_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 56:30]
  assign valid_out = stage_in_reg_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 42:25 63:21]
  assign quot = stage_in_reg_13_is_denom_zero ? 4'h0 : nextState_13_quotient[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 94:14]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (last_stage_out_comb_quot_bit) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_remainder <= last_stage_out_comb_diff;
    end else begin
      stage_in_reg_remainder <= last_stage_out_comb_partial_rem;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_quotient <= last_stage_out_comb_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_dividend <= last_stage_out_comb_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_divisor <= denom; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_is_denom_zero <= reset | s0_state_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_valid <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_1_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_1_remainder <= diff;
    end else begin
      stage_in_reg_1_remainder <= partial_rem;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_1_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_1_quotient <= nextState_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_1_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_1_dividend <= nextState_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_1_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_1_divisor <= stage_in_reg_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_1_is_denom_zero <= reset | stage_in_reg_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_1_valid <= stage_in_reg_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_2_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_1) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_2_remainder <= diff_1;
    end else begin
      stage_in_reg_2_remainder <= partial_rem_1;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_2_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_2_quotient <= nextState_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_2_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_2_dividend <= nextState_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_2_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_2_divisor <= stage_in_reg_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_2_is_denom_zero <= reset | stage_in_reg_1_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_2_valid <= stage_in_reg_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_3_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_3_remainder <= diff_2;
    end else begin
      stage_in_reg_3_remainder <= partial_rem_2;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_3_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_3_quotient <= nextState_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_3_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_3_dividend <= nextState_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_3_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_3_divisor <= stage_in_reg_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_3_is_denom_zero <= reset | stage_in_reg_2_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_3_valid <= stage_in_reg_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_4_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_4_remainder <= diff_3;
    end else begin
      stage_in_reg_4_remainder <= partial_rem_3;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_4_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_4_quotient <= nextState_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_4_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_4_dividend <= nextState_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_4_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_4_divisor <= stage_in_reg_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_4_is_denom_zero <= reset | stage_in_reg_3_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_4_valid <= stage_in_reg_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_5_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_4) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_5_remainder <= diff_4;
    end else begin
      stage_in_reg_5_remainder <= partial_rem_4;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_5_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_5_quotient <= nextState_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_5_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_5_dividend <= nextState_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_5_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_5_divisor <= stage_in_reg_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_5_is_denom_zero <= reset | stage_in_reg_4_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_5_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_5_valid <= stage_in_reg_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_6_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_6_remainder <= diff_5;
    end else begin
      stage_in_reg_6_remainder <= partial_rem_5;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_6_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_6_quotient <= nextState_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_6_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_6_dividend <= nextState_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_6_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_6_divisor <= stage_in_reg_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_6_is_denom_zero <= reset | stage_in_reg_5_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_6_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_6_valid <= stage_in_reg_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_7_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_6) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_7_remainder <= diff_6;
    end else begin
      stage_in_reg_7_remainder <= partial_rem_6;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_7_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_7_quotient <= nextState_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_7_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_7_dividend <= nextState_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_7_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_7_divisor <= stage_in_reg_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_7_is_denom_zero <= reset | stage_in_reg_6_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_7_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_7_valid <= stage_in_reg_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_8_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_7) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_8_remainder <= diff_7;
    end else begin
      stage_in_reg_8_remainder <= partial_rem_7;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_8_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_8_quotient <= nextState_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_8_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_8_dividend <= nextState_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_8_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_8_divisor <= stage_in_reg_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_8_is_denom_zero <= reset | stage_in_reg_7_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_8_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_8_valid <= stage_in_reg_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_9_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_9_remainder <= diff_8;
    end else begin
      stage_in_reg_9_remainder <= partial_rem_8;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_9_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_9_quotient <= nextState_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_9_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_9_dividend <= nextState_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_9_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_9_divisor <= stage_in_reg_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_9_is_denom_zero <= reset | stage_in_reg_8_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_9_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_9_valid <= stage_in_reg_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_10_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_9) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_10_remainder <= diff_9;
    end else begin
      stage_in_reg_10_remainder <= partial_rem_9;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_10_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_10_quotient <= nextState_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_10_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_10_dividend <= nextState_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_10_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_10_divisor <= stage_in_reg_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_10_is_denom_zero <= reset | stage_in_reg_9_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_10_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_10_valid <= stage_in_reg_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_11_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_10) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_11_remainder <= diff_10;
    end else begin
      stage_in_reg_11_remainder <= partial_rem_10;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_11_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_11_quotient <= nextState_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_11_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_11_dividend <= nextState_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_11_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_11_divisor <= stage_in_reg_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_11_is_denom_zero <= reset | stage_in_reg_10_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_11_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_11_valid <= stage_in_reg_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_12_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_12_remainder <= diff_11;
    end else begin
      stage_in_reg_12_remainder <= partial_rem_11;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_12_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_12_quotient <= nextState_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_12_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_12_dividend <= nextState_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_12_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_12_divisor <= stage_in_reg_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_12_is_denom_zero <= reset | stage_in_reg_11_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_12_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_12_valid <= stage_in_reg_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_13_remainder <= 12'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else if (quot_bit_12) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 54:31]
      stage_in_reg_13_remainder <= diff_12;
    end else begin
      stage_in_reg_13_remainder <= partial_rem_12;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_13_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_13_quotient <= nextState_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_13_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_13_dividend <= nextState_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_13_divisor <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_13_divisor <= stage_in_reg_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
    stage_in_reg_13_is_denom_zero <= reset | stage_in_reg_12_is_denom_zero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:{14,14,14}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
      stage_in_reg_13_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end else begin
      stage_in_reg_13_valid <= stage_in_reg_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_02/UnsignedDivider/UnsignedDivider.scala 84:14]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  stage_in_reg_remainder = _RAND_0[11:0];
  _RAND_1 = {1{`RANDOM}};
  stage_in_reg_quotient = _RAND_1[14:0];
  _RAND_2 = {1{`RANDOM}};
  stage_in_reg_dividend = _RAND_2[14:0];
  _RAND_3 = {1{`RANDOM}};
  stage_in_reg_divisor = _RAND_3[10:0];
  _RAND_4 = {1{`RANDOM}};
  stage_in_reg_is_denom_zero = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  stage_in_reg_valid = _RAND_5[0:0];
  _RAND_6 = {1{`RANDOM}};
  stage_in_reg_1_remainder = _RAND_6[11:0];
  _RAND_7 = {1{`RANDOM}};
  stage_in_reg_1_quotient = _RAND_7[14:0];
  _RAND_8 = {1{`RANDOM}};
  stage_in_reg_1_dividend = _RAND_8[14:0];
  _RAND_9 = {1{`RANDOM}};
  stage_in_reg_1_divisor = _RAND_9[10:0];
  _RAND_10 = {1{`RANDOM}};
  stage_in_reg_1_is_denom_zero = _RAND_10[0:0];
  _RAND_11 = {1{`RANDOM}};
  stage_in_reg_1_valid = _RAND_11[0:0];
  _RAND_12 = {1{`RANDOM}};
  stage_in_reg_2_remainder = _RAND_12[11:0];
  _RAND_13 = {1{`RANDOM}};
  stage_in_reg_2_quotient = _RAND_13[14:0];
  _RAND_14 = {1{`RANDOM}};
  stage_in_reg_2_dividend = _RAND_14[14:0];
  _RAND_15 = {1{`RANDOM}};
  stage_in_reg_2_divisor = _RAND_15[10:0];
  _RAND_16 = {1{`RANDOM}};
  stage_in_reg_2_is_denom_zero = _RAND_16[0:0];
  _RAND_17 = {1{`RANDOM}};
  stage_in_reg_2_valid = _RAND_17[0:0];
  _RAND_18 = {1{`RANDOM}};
  stage_in_reg_3_remainder = _RAND_18[11:0];
  _RAND_19 = {1{`RANDOM}};
  stage_in_reg_3_quotient = _RAND_19[14:0];
  _RAND_20 = {1{`RANDOM}};
  stage_in_reg_3_dividend = _RAND_20[14:0];
  _RAND_21 = {1{`RANDOM}};
  stage_in_reg_3_divisor = _RAND_21[10:0];
  _RAND_22 = {1{`RANDOM}};
  stage_in_reg_3_is_denom_zero = _RAND_22[0:0];
  _RAND_23 = {1{`RANDOM}};
  stage_in_reg_3_valid = _RAND_23[0:0];
  _RAND_24 = {1{`RANDOM}};
  stage_in_reg_4_remainder = _RAND_24[11:0];
  _RAND_25 = {1{`RANDOM}};
  stage_in_reg_4_quotient = _RAND_25[14:0];
  _RAND_26 = {1{`RANDOM}};
  stage_in_reg_4_dividend = _RAND_26[14:0];
  _RAND_27 = {1{`RANDOM}};
  stage_in_reg_4_divisor = _RAND_27[10:0];
  _RAND_28 = {1{`RANDOM}};
  stage_in_reg_4_is_denom_zero = _RAND_28[0:0];
  _RAND_29 = {1{`RANDOM}};
  stage_in_reg_4_valid = _RAND_29[0:0];
  _RAND_30 = {1{`RANDOM}};
  stage_in_reg_5_remainder = _RAND_30[11:0];
  _RAND_31 = {1{`RANDOM}};
  stage_in_reg_5_quotient = _RAND_31[14:0];
  _RAND_32 = {1{`RANDOM}};
  stage_in_reg_5_dividend = _RAND_32[14:0];
  _RAND_33 = {1{`RANDOM}};
  stage_in_reg_5_divisor = _RAND_33[10:0];
  _RAND_34 = {1{`RANDOM}};
  stage_in_reg_5_is_denom_zero = _RAND_34[0:0];
  _RAND_35 = {1{`RANDOM}};
  stage_in_reg_5_valid = _RAND_35[0:0];
  _RAND_36 = {1{`RANDOM}};
  stage_in_reg_6_remainder = _RAND_36[11:0];
  _RAND_37 = {1{`RANDOM}};
  stage_in_reg_6_quotient = _RAND_37[14:0];
  _RAND_38 = {1{`RANDOM}};
  stage_in_reg_6_dividend = _RAND_38[14:0];
  _RAND_39 = {1{`RANDOM}};
  stage_in_reg_6_divisor = _RAND_39[10:0];
  _RAND_40 = {1{`RANDOM}};
  stage_in_reg_6_is_denom_zero = _RAND_40[0:0];
  _RAND_41 = {1{`RANDOM}};
  stage_in_reg_6_valid = _RAND_41[0:0];
  _RAND_42 = {1{`RANDOM}};
  stage_in_reg_7_remainder = _RAND_42[11:0];
  _RAND_43 = {1{`RANDOM}};
  stage_in_reg_7_quotient = _RAND_43[14:0];
  _RAND_44 = {1{`RANDOM}};
  stage_in_reg_7_dividend = _RAND_44[14:0];
  _RAND_45 = {1{`RANDOM}};
  stage_in_reg_7_divisor = _RAND_45[10:0];
  _RAND_46 = {1{`RANDOM}};
  stage_in_reg_7_is_denom_zero = _RAND_46[0:0];
  _RAND_47 = {1{`RANDOM}};
  stage_in_reg_7_valid = _RAND_47[0:0];
  _RAND_48 = {1{`RANDOM}};
  stage_in_reg_8_remainder = _RAND_48[11:0];
  _RAND_49 = {1{`RANDOM}};
  stage_in_reg_8_quotient = _RAND_49[14:0];
  _RAND_50 = {1{`RANDOM}};
  stage_in_reg_8_dividend = _RAND_50[14:0];
  _RAND_51 = {1{`RANDOM}};
  stage_in_reg_8_divisor = _RAND_51[10:0];
  _RAND_52 = {1{`RANDOM}};
  stage_in_reg_8_is_denom_zero = _RAND_52[0:0];
  _RAND_53 = {1{`RANDOM}};
  stage_in_reg_8_valid = _RAND_53[0:0];
  _RAND_54 = {1{`RANDOM}};
  stage_in_reg_9_remainder = _RAND_54[11:0];
  _RAND_55 = {1{`RANDOM}};
  stage_in_reg_9_quotient = _RAND_55[14:0];
  _RAND_56 = {1{`RANDOM}};
  stage_in_reg_9_dividend = _RAND_56[14:0];
  _RAND_57 = {1{`RANDOM}};
  stage_in_reg_9_divisor = _RAND_57[10:0];
  _RAND_58 = {1{`RANDOM}};
  stage_in_reg_9_is_denom_zero = _RAND_58[0:0];
  _RAND_59 = {1{`RANDOM}};
  stage_in_reg_9_valid = _RAND_59[0:0];
  _RAND_60 = {1{`RANDOM}};
  stage_in_reg_10_remainder = _RAND_60[11:0];
  _RAND_61 = {1{`RANDOM}};
  stage_in_reg_10_quotient = _RAND_61[14:0];
  _RAND_62 = {1{`RANDOM}};
  stage_in_reg_10_dividend = _RAND_62[14:0];
  _RAND_63 = {1{`RANDOM}};
  stage_in_reg_10_divisor = _RAND_63[10:0];
  _RAND_64 = {1{`RANDOM}};
  stage_in_reg_10_is_denom_zero = _RAND_64[0:0];
  _RAND_65 = {1{`RANDOM}};
  stage_in_reg_10_valid = _RAND_65[0:0];
  _RAND_66 = {1{`RANDOM}};
  stage_in_reg_11_remainder = _RAND_66[11:0];
  _RAND_67 = {1{`RANDOM}};
  stage_in_reg_11_quotient = _RAND_67[14:0];
  _RAND_68 = {1{`RANDOM}};
  stage_in_reg_11_dividend = _RAND_68[14:0];
  _RAND_69 = {1{`RANDOM}};
  stage_in_reg_11_divisor = _RAND_69[10:0];
  _RAND_70 = {1{`RANDOM}};
  stage_in_reg_11_is_denom_zero = _RAND_70[0:0];
  _RAND_71 = {1{`RANDOM}};
  stage_in_reg_11_valid = _RAND_71[0:0];
  _RAND_72 = {1{`RANDOM}};
  stage_in_reg_12_remainder = _RAND_72[11:0];
  _RAND_73 = {1{`RANDOM}};
  stage_in_reg_12_quotient = _RAND_73[14:0];
  _RAND_74 = {1{`RANDOM}};
  stage_in_reg_12_dividend = _RAND_74[14:0];
  _RAND_75 = {1{`RANDOM}};
  stage_in_reg_12_divisor = _RAND_75[10:0];
  _RAND_76 = {1{`RANDOM}};
  stage_in_reg_12_is_denom_zero = _RAND_76[0:0];
  _RAND_77 = {1{`RANDOM}};
  stage_in_reg_12_valid = _RAND_77[0:0];
  _RAND_78 = {1{`RANDOM}};
  stage_in_reg_13_remainder = _RAND_78[11:0];
  _RAND_79 = {1{`RANDOM}};
  stage_in_reg_13_quotient = _RAND_79[14:0];
  _RAND_80 = {1{`RANDOM}};
  stage_in_reg_13_dividend = _RAND_80[14:0];
  _RAND_81 = {1{`RANDOM}};
  stage_in_reg_13_divisor = _RAND_81[10:0];
  _RAND_82 = {1{`RANDOM}};
  stage_in_reg_13_is_denom_zero = _RAND_82[0:0];
  _RAND_83 = {1{`RANDOM}};
  stage_in_reg_13_valid = _RAND_83[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
