module ScoreAndWeightUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 6:17]
  input         valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 7:20]
  input  [7:0]  q_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 8:16]
  input  [7:0]  k_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 9:16]
  input  [3:0]  v_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 10:16]
  output        valid_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 12:21]
  output [8:0]  weight_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 13:22]
  output [12:0] weighted_v_out // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 14:26]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
`endif // RANDOMIZE_REG_INIT
  reg [8:0] score_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 18:27]
  reg [3:0] v_in_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 19:26]
  reg  valid_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 20:27]
  wire [3:0] q0 = q_in[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 22:18]
  wire [3:0] q1 = q_in[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 23:18]
  wire [3:0] k0 = k_in[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 24:18]
  wire [3:0] k1 = k_in[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 25:18]
  wire [7:0] prod0 = q0 * k0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 27:20]
  wire [7:0] prod1 = q1 * k1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 28:20]
  wire [8:0] score_s0 = prod0 + prod1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 29:26]
  reg [8:0] weight_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 36:33]
  reg [12:0] weighted_v_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 37:37]
  reg  valid_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 38:32]
  wire [8:0] weight_s1 = score_s1 >= 9'h40 ? score_s1 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 41:24]
  wire [12:0] weighted_v_s1 = weight_s1 * v_in_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 42:35]
  assign valid_out = valid_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 49:15]
  assign weight_out = weight_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 50:16]
  assign weighted_v_out = weighted_v_out_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 51:20]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 18:27]
      score_s1 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 18:27]
    end else begin
      score_s1 <= score_s0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 31:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 19:26]
      v_in_s1 <= 4'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 19:26]
    end else begin
      v_in_s1 <= v_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 32:13]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 20:27]
      valid_s1 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 20:27]
    end else begin
      valid_s1 <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 33:14]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 36:33]
      weight_out_reg <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 36:33]
    end else if (score_s1 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 41:24]
      weight_out_reg <= score_s1;
    end else begin
      weight_out_reg <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 37:37]
      weighted_v_out_reg <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 37:37]
    end else begin
      weighted_v_out_reg <= weighted_v_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 45:24]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 38:32]
      valid_out_reg <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 38:32]
    end else begin
      valid_out_reg <= valid_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/behavior_17692082/round_01/build_01/ScoreAndWeightUnit/ScoreAndWeightUnit.scala 46:19]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  score_s1 = _RAND_0[8:0];
  _RAND_1 = {1{`RANDOM}};
  v_in_s1 = _RAND_1[3:0];
  _RAND_2 = {1{`RANDOM}};
  valid_s1 = _RAND_2[0:0];
  _RAND_3 = {1{`RANDOM}};
  weight_out_reg = _RAND_3[8:0];
  _RAND_4 = {1{`RANDOM}};
  weighted_v_out_reg = _RAND_4[12:0];
  _RAND_5 = {1{`RANDOM}};
  valid_out_reg = _RAND_5[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
