# 完整系统生成：Chisel / Verilog 集成验证

这是新主线的 bring-up 记录，不是 Critic 消融，也不是两种 HDL 的公平性能比较。

算法为 4-bit threshold-attention：QK 阈值筛选、加权求和、整数归一化。它不等于 DynaX 或 softmax attention。每轮使用独立 Python 参考驱动的 100 个全系统数值用例。

面积为完整生成顶层的 Nangate45 综合单元面积；功耗为 OpenSTA 全局活动率预布局估计，能量为该估计功耗乘以实测周期对应的延迟。没有布局布线或逐网工作负载活动标注。

| 运行 | 轮次 | 语言 | threshold | 验证 | 面积 µm² | 功耗 mW | 延迟 ns | 能量 nJ | slack ns | 可行 |
|---|---:|---|---:|---|---:|---:|---:|---:|---:|---|
| behavior_17692082 | 1 | chisel | 64 | 通过 | 7585.26 | 0.68988 | 210 | 0.144875 | 8.6215 | 是 |

## behavior_17692082

状态：`budget_exhausted`；参考库完整性：`True`；保留的 Pareto 轮次：`[1]`。

约束与预算：`{"algorithm": "threshold_attention", "prompt": "Design a complete threshold-sparse attention accelerator from q/k/v inputs to normalized output. Analyze the allowed threshold configurations, then co-design the complete datapath and control. Prefer reusable modules; explore energy-latency tradeoffs within measured quality, area and clock constraints.", "constraints": {"max_quality_loss": 0.15, "max_area_um2": 30000, "frequency_mhz": 100}, "max_loops": 1, "compiler_attempts": 3, "module_attempts": 4, "seed": 17, "kernel_profile_budget": 16, "activity": 0.1, "hdl": "chisel", "template_read_budget": 2, "module_workers": 1, "assembly_attempts": 4}`

LLM 调用次数：`{"kernel": 1, "compiler": 6, "critic": 1, "uarch": 6, "uarch_assembly": 1}`。

### 轮次 1

重入：`kernel`；状态：`evaluated`。

可信 Kernel 分析：`{"config": {"threshold": 64}, "quality_loss": 0.07025641025641026, "quality_metric": "mean absolute output error / 15 vs threshold=0", "quality_scope": "260 deterministic synthetic profiling queries; not model perplexity", "sparsity": 0.31634615384615383, "active_keys_histogram": {"0": 20, "1": 27, "2": 47, "3": 74, "4": 92}, "samples": 260, "seed": 17}`。

完整顶层：`ThresholdAttention`。下述为 Compiler 的接口/拓扑计划。UArch 重入会保留该计划，因此其中流水级等实现说明可能仍是初始值；最终实现以该轮源码、UArch 说明和实测周期为准：

The system is decomposed into a top-level controller (`ThresholdAttention`), four parallel `ScoreAndWeightUnit` instances, and a final `UnsignedDivider`. This modular design allows for independent implementation and verification of the core components. The dataflow is a deep, feed-forward pipeline to maximize throughput. An initial stage latches and unpacks inputs. Four `ScoreAndWeightUnit`s process the four key-value pairs in parallel over 2 pipeline stages. A 2-stage pipelined adder tree aggregates their results. The final normalization is performed by a deeply pipelined `UnsignedDivider`. This plan corrects a critical flaw in the previous `UnsignedDivider` design identified by UArch feedback. The previous 4-stage divider could not correctly compute the 15-bit by 11-bit division. The new `UnsignedDivider` is a 15-stage radix-2 restoring divider, with one stage per bit of the 15-bit numerator. This ensures the full integer division is performed correctly. The total system latency is 21 cycles, which is well within the 128-cycle constraint and allows for a high clock frequency. The `threshold` value of 64 is hardcoded into the `ScoreAndWeightUnit` as specified by the task's profile configuration.

| 新生成模块 | 依赖 | Compiler 分配的参考 | 职责 |
|---|---|---|---|
| ScoreAndWeightUnit |  | chisel_carry_and_clock | Computes the dot product score for one key, applies a threshold to get the weight, and multiplies the weight by the corresponding value. |
| UnsignedDivider |  | pipelined_divider | Pipelined unsigned integer divider for `numer (15b) / denom (11b) -> quot (4b)`. It is based on a 15-stage radix-2 restoring division algorithm to correctly handle the full width of the numerator. |
| ThresholdAttention | ScoreAndWeightUnit, UnsignedDivider | — | Top-level module to implement threshold attention. It orchestrates dataflow through four parallel ScoreAndWeight units, an aggregation tree, and a final pipelined divider. |

Critic → `uarch`；有下一轮执行：`False`。

归因（模型分析，因果结论仍需对照）：The design is feasible and meets all constraints, but it is not Pareto-optimal. The primary contributor to the high 21-cycle latency and corresponding energy is the 15-stage, fully-pipelined `UnsignedDivider`. The massive timing slack indicates the design is severely over-pipelined for the 100 MHz clock target, creating unnecessary pipeline registers that increase latency, area, and energy without providing any benefit at the target frequency.

具体干预：Replace the 15-stage pipelined radix-2 `UnsignedDivider` with a more compact, iterative (multi-cycle) implementation. A non-pipelined restoring divider that reuses its hardware over approximately 15 cycles would achieve a similar throughput latency but would drastically reduce the number of pipeline registers. This will trade the excessive frequency headroom for lower latency, energy, and area, moving the design to a much better latency-energy Pareto point while still easily meeting the 100 MHz timing constraint.

引用字段：`['evaluation.slack_ns', 'evaluation.verification.mean_cycles', 'evaluation.energy_nj', 'evaluation.area_um2']`。

[完整结果](raw/behavior_17692082/summary.json) · [事件与反馈](raw/behavior_17692082/events.json)

## 证据使用边界

本记录证明的是指定契约下的系统生成、验证、测量和角色重入。单次变好或变差都不足以证明 Critic 相比无 Critic / 规则 Critic 更有效。下一步应冻结工作负载、初始设计和预算，做多 seed 的有/无 Critic 对照，并增加真实 DynaX 契约和工作负载活动标注。

raw 保留原日志中的绝对路径；它们对应运行时的 scratch 目录。归档的相对目录保持原层次。source 是执行时的冻结源码快照；当前工作区可能有后续兼容性修复，不能反向归算为本次运行的行为。
