module Pipe(input clock,input reset,input iv,input [3:0] a,output ov,output [4:0] b);
reg v1,v2,v3; reg [4:0] d1,d2,d3;
always @(posedge clock) begin
 if(reset) begin v1<=0;v2<=0;v3<=0;d1<=0;d2<=0;d3<=0;end
 else begin v1<=iv;v2<=v1;v3<=v2;d1<={1'b0,a}+5'd1;d2<=d1;d3<=d2;end
end
assign ov=v3; assign b=d3; endmodule