module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] iv;
reg [3:0] a;
wire [0:0] ov;
wire [4:0] b;
Pipe dut(.clock(clock),.reset(reset),.iv(iv),.a(a),.ov(ov),.b(b));
initial begin
clock=0;
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=0 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=0 step=0 output=b expected=0 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=0 step=3 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd1) $fatal(1,"module case=0 step=3 output=b expected=1 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=0 step=5 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=0 step=5 output=b expected=0 actual=%0d",b);
$display("FAST_CASE cycles=1");
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=0 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=1 step=0 output=b expected=0 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=1 step=3 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd16) $fatal(1,"module case=1 step=3 output=b expected=16 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=1 step=5 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=1 step=5 output=b expected=0 actual=%0d",b);
$display("FAST_CASE cycles=1");
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=0 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=2 step=0 output=b expected=0 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=2 step=3 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd8) $fatal(1,"module case=2 step=3 output=b expected=8 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=4 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=2 step=5 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=2 step=5 output=b expected=0 actual=%0d",b);
$display("FAST_CASE cycles=1");
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=0 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=3 step=0 output=b expected=0 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=1 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
a=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=2 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
a=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=3 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd1) $fatal(1,"module case=3 step=3 output=b expected=1 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=4 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd16) $fatal(1,"module case=3 step=4 output=b expected=16 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=5 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd8) $fatal(1,"module case=3 step=5 output=b expected=8 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=6 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
a=4'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=7 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd1) $fatal(1,"module case=3 step=7 output=b expected=1 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=8 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd16) $fatal(1,"module case=3 step=8 output=b expected=16 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd12;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=9 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd4) $fatal(1,"module case=3 step=9 output=b expected=4 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd4;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=10 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
a=4'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=11 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd13) $fatal(1,"module case=3 step=11 output=b expected=13 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=12 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd5) $fatal(1,"module case=3 step=12 output=b expected=5 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd4;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=13 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd2) $fatal(1,"module case=3 step=13 output=b expected=2 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=14 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
a=4'd7;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=15 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd5) $fatal(1,"module case=3 step=15 output=b expected=5 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=16 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd4) $fatal(1,"module case=3 step=16 output=b expected=4 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd4;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=17 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd8) $fatal(1,"module case=3 step=17 output=b expected=8 actual=%0d",b);
reset=1'd0;
iv=1'd1;
a=4'd4;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=18 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd1;
a=4'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=19 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd5) $fatal(1,"module case=3 step=19 output=b expected=5 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=20 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd5) $fatal(1,"module case=3 step=20 output=b expected=5 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd1) $fatal(1,"module case=3 step=21 output=ov expected=1 actual=%0d",ov);
if (b !== 5'd2) $fatal(1,"module case=3 step=21 output=b expected=2 actual=%0d",b);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=22 output=ov expected=0 actual=%0d",ov);
reset=1'd0;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=23 output=ov expected=0 actual=%0d",ov);
reset=1'd1;
iv=1'd0;
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (ov !== 1'd0) $fatal(1,"module case=3 step=24 output=ov expected=0 actual=%0d",ov);
if (b !== 5'd0) $fatal(1,"module case=3 step=24 output=b expected=0 actual=%0d",b);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule