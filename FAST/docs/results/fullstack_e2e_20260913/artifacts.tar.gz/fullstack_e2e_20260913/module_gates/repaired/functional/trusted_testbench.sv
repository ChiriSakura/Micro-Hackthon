module FASTTestbench;
reg [3:0] a;
wire [4:0] b;
Increment dut(.a(a),.b(b));
initial begin
a=4'd0;
#5;
if (b !== 5'd1) $fatal(1,"module case=0 step=0 output=b expected=1 actual=%0d",b);
a=4'd15;
#5;
if (b !== 5'd16) $fatal(1,"module case=0 step=1 output=b expected=16 actual=%0d",b);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=1");
$finish;
end
endmodule