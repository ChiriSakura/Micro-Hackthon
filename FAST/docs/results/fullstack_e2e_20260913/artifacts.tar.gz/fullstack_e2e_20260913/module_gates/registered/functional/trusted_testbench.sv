module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [3:0] a;
wire [3:0] b;
Register dut(.clock(clock),.reset(reset),.a(a),.b(b));
initial begin
clock=0;
reset=1'd1;
a=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (b !== 4'd0) $fatal(1,"module case=0 step=0 output=b expected=0 actual=%0d",b);
reset=1'd0;
a=4'd15;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (b !== 4'd15) $fatal(1,"module case=0 step=1 output=b expected=15 actual=%0d",b);
a=4'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (b !== 4'd0) $fatal(1,"module case=0 step=2 output=b expected=0 actual=%0d",b);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=1");
$finish;
end
endmodule