# Floorplan automatically generated from HAMMER
puts "(hammer) initialize_floorplan -site FreePDK45_38x28_10R_NP_162NW_34O -die_area { 0 0 660 660} -core_area {10 10 640 640}"
initialize_floorplan -site FreePDK45_38x28_10R_NP_162NW_34O -die_area { 0 0 660 660} -core_area {10 10 640 640}