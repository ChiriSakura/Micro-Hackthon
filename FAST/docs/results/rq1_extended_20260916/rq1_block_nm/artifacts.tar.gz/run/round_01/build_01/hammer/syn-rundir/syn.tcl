yosys -import
setundef -zero
read_verilog -sv /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/whole_system.v
read_liberty -lib /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
puts "(hammer) yosys proc"
yosys proc
puts "(hammer) hierarchy -check -top Rq1BlockNmTop"
hierarchy -check -top Rq1BlockNmTop
puts "(hammer) synth -top Rq1BlockNmTop -flatten"
synth -top Rq1BlockNmTop -flatten
puts "(hammer) opt -purge"
opt -purge
puts "dfflibmap -liberty /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib" 
dfflibmap -liberty /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
puts "opt_clean" 
opt_clean
# Technology mapping for cells
# ABC supports multiple liberty files, but the hook from Yosys to ABC doesn't
# TODO: this is a bad way of getting one liberty file, need a way to merge all std cell lib files
# NOTE: this breaks for any PDK that has multiple LIB files for std cell library
puts "(hammer) abc -D 3333"
abc -D 3333 \
    -constr "/scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.sdc" \
    -liberty "/scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib" \
    -showtmp

# Replace undef values with defined constants
# TODO: do we need this??
puts "(hammer) setundef -zero"
setundef -zero

# Split multi-bit nets into single-bit nets.
# Splitting nets resolves unwanted compound assign statements in netlist (assign [..] = [..])
puts "(hammer) splitnets"
splitnets

# Remove unused cells and wires
puts "(hammer) opt_clean -purge"
opt_clean -purge
# Technology mapping of constant hi- and/or lo-drivers
puts "(hammer) hilomap -singleton"
hilomap -singleton \
        -hicell {*}LOGIC1_X1 Z \
        -locell {*}LOGIC0_X1 Z
puts "(hammer) tee -o /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.synth_check.rpt check"
tee -o /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.synth_check.rpt check

puts "(hammer) tee -o /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.synth_stat.txt stat -top Rq1BlockNmTop -liberty /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib"
tee -o /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.synth_stat.txt stat -top Rq1BlockNmTop -liberty /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
puts "check -assert" 
check -assert
puts "select -assert-none {t:$*}" 
select -assert-none {t:$*}
puts "(hammer) write_verilog -noattr -noexpr -nohex -nodec -defparam \"/scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.v\""
write_verilog -noattr -noexpr -nohex -nodec -defparam "/scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.v"

# flatten

# # OpenROAD will throw an error if the verilog from Yosys is not flattened
# # UPDATE ON THIS: nvm, it somehow works now...
# write_verilog -noattr -noexpr -nohex -nodec -defparam "/scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.v"

# BLIF file seems to be easier to parse than mapped verilog for find_regs functions so leave for now
# write_blif -top Rq1BlockNmTop "/scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.blif"
exit