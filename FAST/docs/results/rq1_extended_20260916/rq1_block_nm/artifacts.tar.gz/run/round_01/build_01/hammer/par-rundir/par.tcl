# OpenROAD TCL Script
puts "(hammer) write_db pre_init_design"
write_db pre_init_design
puts "(hammer) exec ln -sfn pre_init_design latest"
exec ln -sfn pre_init_design latest
puts "(hammer) read_lef /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lef/NangateOpenCellLibrary.tech.lef"
read_lef /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lef/NangateOpenCellLibrary.tech.lef
puts "(hammer) read_lef /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lef/NangateOpenCellLibrary.macro.lef"
read_lef /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lef/NangateOpenCellLibrary.macro.lef
puts "(hammer) define_corners setup hold"
define_corners setup hold
puts "(hammer) read_liberty -corner setup /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib"
read_liberty -corner setup /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
puts "(hammer) read_liberty -corner hold /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib"
read_liberty -corner hold /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
puts "(hammer) read_verilog /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.v"
read_verilog /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/syn-rundir/Rq1BlockNmTop.mapped.v
puts "(hammer) link_design Rq1BlockNmTop"
link_design Rq1BlockNmTop
puts "(hammer) read_sdc -echo /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/clock_constraints_fragment.sdc"
read_sdc -echo /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/clock_constraints_fragment.sdc
puts "(hammer) read_sdc -echo /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/pin_constraints_fragment.sdc"
read_sdc -echo /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/pin_constraints_fragment.sdc
puts "(hammer) source /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/setRC.tcl"
source /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/setRC.tcl
puts "(hammer) set_dont_use {}"
set_dont_use {}
puts "(hammer) source /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/write_reports.tcl"
source /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/write_reports.tcl
proc find_macros {} {
    set macros ""
    set block [[[ord::get_db] getChip] getBlock]
    foreach inst [$block getInsts] {
        set inst_master [$inst getMaster]
        if { [string match [$inst_master getType] "BLOCK"] } {
            append macros [$inst getName] " "
        }
    }
    return $macros
}
puts "(hammer) write_db pre_constrain_io"
write_db pre_constrain_io
puts "(hammer) exec ln -sfn pre_constrain_io latest"
exec ln -sfn pre_constrain_io latest
# Recent OpenROAD uses Tcl's native source, without the old echo/verbose flags.
puts "(hammer) rename source fast_native_source"
rename source fast_native_source
proc source {args} {
    puts "(hammer) set filtered {}"
    set filtered {}
    foreach arg $args {
        puts "(hammer) if {\$arg ni {\"-echo\" \"-verbose\"}} {lappend filtered \$arg}"
        if {$arg ni {"-echo" "-verbose"}} {lappend filtered $arg}
    }
    puts "(hammer) uplevel 1 \[linsert \$filtered 0 fast_native_source\]"
    uplevel 1 [linsert $filtered 0 fast_native_source]
}
puts "(hammer) set_input_delay 1.0 -clock clock \[all_inputs -no_clocks\]"
set_input_delay 1.0 -clock clock [all_inputs -no_clocks]
puts "(hammer) set_output_delay 1.0 -clock clock \[all_outputs\]"
set_output_delay 1.0 -clock clock [all_outputs]
puts "(hammer) set_load 5.0 \[all_outputs\]"
set_load 5.0 [all_outputs]
puts "(hammer) write_db pre_floorplan_design"
write_db pre_floorplan_design
puts "(hammer) exec ln -sfn pre_floorplan_design latest"
exec ln -sfn pre_floorplan_design latest
################################################################
# Floorplan Design
# Print paths to macros to file
set macros_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/macros.txt
set macros_file [open $macros_file "w"]
set macros ""
foreach macro [find_macros] {
    set inst [[ord::get_db_block] findInst $macro]
    set inst_master [$inst getMaster]
    append macros $macro " \n"
    append macros "\t- master: " [$inst_master getName] " \n"
    append macros "\t- width:  " [$inst_master getWidth] " \n"
    append macros "\t- height: " [$inst_master getHeight] " \n"
    set origin [$inst_master getOrigin]
    append macros "\t- origin: " [lindex $origin 0] ", " [lindex $origin 1] " \n"
}
puts $macros
puts $macros_file $macros
close $macros_file
# Init floorplan + Place Macros
puts "(hammer) source -verbose /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/floorplan.tcl"
source -verbose /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/floorplan.tcl

# Make tracks
# create routing tracks
puts "(hammer) make_tracks metal1 -x_offset 0.07 -x_pitch 0.14 -y_offset 0.07 -y_pitch 0.14"
make_tracks metal1 -x_offset 0.07 -x_pitch 0.14 -y_offset 0.07 -y_pitch 0.14
puts "(hammer) make_tracks metal2 -x_offset 0.095 -x_pitch 0.14 -y_offset 0.095 -y_pitch 0.14"
make_tracks metal2 -x_offset 0.095 -x_pitch 0.14 -y_offset 0.095 -y_pitch 0.14
puts "(hammer) make_tracks metal3 -x_offset 0.07 -x_pitch 0.14 -y_offset 0.07 -y_pitch 0.14"
make_tracks metal3 -x_offset 0.07 -x_pitch 0.14 -y_offset 0.07 -y_pitch 0.14
puts "(hammer) make_tracks metal4 -x_offset 0.095 -x_pitch 0.28 -y_offset 0.095 -y_pitch 0.28"
make_tracks metal4 -x_offset 0.095 -x_pitch 0.28 -y_offset 0.095 -y_pitch 0.28
puts "(hammer) make_tracks metal5 -x_offset 0.07 -x_pitch 0.28 -y_offset 0.07 -y_pitch 0.28"
make_tracks metal5 -x_offset 0.07 -x_pitch 0.28 -y_offset 0.07 -y_pitch 0.28
puts "(hammer) make_tracks metal6 -x_offset 0.095 -x_pitch 0.28 -y_offset 0.095 -y_pitch 0.28"
make_tracks metal6 -x_offset 0.095 -x_pitch 0.28 -y_offset 0.095 -y_pitch 0.28
puts "(hammer) make_tracks metal7 -x_offset 0.07 -x_pitch 0.8 -y_offset 0.07 -y_pitch 0.8"
make_tracks metal7 -x_offset 0.07 -x_pitch 0.8 -y_offset 0.07 -y_pitch 0.8
puts "(hammer) make_tracks metal8 -x_offset 0.095 -x_pitch 0.8 -y_offset 0.095 -y_pitch 0.8"
make_tracks metal8 -x_offset 0.095 -x_pitch 0.8 -y_offset 0.095 -y_pitch 0.8
puts "(hammer) make_tracks metal9 -x_offset 0.07 -x_pitch 1.6 -y_offset 0.07 -y_pitch 1.6"
make_tracks metal9 -x_offset 0.07 -x_pitch 1.6 -y_offset 0.07 -y_pitch 1.6
puts "(hammer) make_tracks metal10 -x_offset 0.095 -x_pitch 1.6 -y_offset 0.095 -y_pitch 1.6"
make_tracks metal10 -x_offset 0.095 -x_pitch 1.6 -y_offset 0.095 -y_pitch 1.6
# remove buffers inserted by synthesis
puts "(hammer) remove_buffers"
remove_buffers

# IO Placement (random)
puts "(hammer) place_pins -random -hor_layers {metal7} -ver_layers {metal6}"
place_pins -random -hor_layers {metal7} -ver_layers {metal6}
puts "(hammer) write_db pre_place_initial_pins"
write_db pre_place_initial_pins
puts "(hammer) exec ln -sfn pre_place_initial_pins latest"
exec ln -sfn pre_place_initial_pins latest
puts "(hammer) place_pins -hor_layers {metal3} -ver_layers {metal2}"
place_pins -hor_layers {metal3} -ver_layers {metal2}
puts "(hammer) write_db pre_place_bumps"
write_db pre_place_bumps
puts "(hammer) exec ln -sfn pre_place_bumps latest"
exec ln -sfn pre_place_bumps latest
puts "(hammer) write_db pre_macro_placement"
write_db pre_macro_placement
puts "(hammer) exec ln -sfn pre_macro_placement latest"
exec ln -sfn pre_macro_placement latest
puts "(hammer) write_db pre_place_tapcells"
write_db pre_place_tapcells
puts "(hammer) exec ln -sfn pre_place_tapcells latest"
exec ln -sfn pre_place_tapcells latest
################################################################
# Tapcell insertion
puts "(hammer) tapcell -tapcell_master FILLCELL_X1  -distance 10.0 -halo_width_x 0.0 -halo_width_y 0.0"
tapcell -tapcell_master FILLCELL_X1  -distance 10.0 -halo_width_x 0.0 -halo_width_y 0.0
puts "(hammer) write_db pre_power_straps"
write_db pre_power_straps
puts "(hammer) exec ln -sfn pre_power_straps latest"
exec ln -sfn pre_power_straps latest
################################################################
# Power distribution network insertion
# pdngen -verbose /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/power_straps.tcl
puts "(hammer) source -echo -verbose /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/power_straps.tcl"
source -echo -verbose /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/power_straps.tcl
puts "(hammer) pdngen"
pdngen
puts "(hammer) write_db pre_snap_power_grid"
write_db pre_snap_power_grid
puts "(hammer) exec ln -sfn pre_snap_power_grid latest"
exec ln -sfn pre_snap_power_grid latest
puts "(hammer) write_db pre_global_placement"
write_db pre_global_placement
puts "(hammer) exec ln -sfn pre_global_placement latest"
exec ln -sfn pre_global_placement latest
################################################################
# Global placement (with placed IOs, timing-driven, and routability-driven)
# set_dont_use {}
# reduce the routing resources of all routing layers by X%
puts "(hammer) set_global_routing_layer_adjustment metal2-metal10 0.5"
set_global_routing_layer_adjustment metal2-metal10 0.5
puts "(hammer) set_routing_layers -signal metal2-metal10 -clock metal2-metal10"
set_routing_layers -signal metal2-metal10 -clock metal2-metal10
# creates blockages around macros
# set_macro_extension 0.0

# -density default is 0.7, overflow default is 0.1
puts "(hammer) global_placement -density 0.6 -pad_left 3 -pad_right 3 -routability_driven"
global_placement -density 0.6 -pad_left 3 -pad_right 3 -routability_driven 

puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement
puts "(hammer) write_db pre_io_placement"
write_db pre_io_placement
puts "(hammer) exec ln -sfn pre_io_placement latest"
exec ln -sfn pre_io_placement latest
################################################################
# IO Placement

puts "(hammer) write_db pre_resize"
write_db pre_resize
puts "(hammer) exec ln -sfn pre_resize latest"
exec ln -sfn pre_resize latest
################################################################
# Resizing & Buffering
puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement
puts "(hammer) buffer_ports"
buffer_ports
# Perform buffer insertion
# set_debug_level RSZ repair_net 1
# insert buffers on nets to repair max slew, max capacitance, max fanout violations, and on long wires to reduce RC delay in the wire
puts "(hammer) repair_design"
repair_design
# -slew_margin 0 -cap_margin 0

# Repair tie lo/hi fanout
puts "(hammer) set tielo_lib_name \[get_name \[get_property \[lindex \[get_lib_cell LOGIC0_X1\] 0\] library\]\]"
set tielo_lib_name [get_name [get_property [lindex [get_lib_cell LOGIC0_X1] 0] library]]
puts "(hammer) set tiehi_lib_name \[get_name \[get_property \[lindex \[get_lib_cell LOGIC1_X1\] 0\] library\]\]"
set tiehi_lib_name [get_name [get_property [lindex [get_lib_cell LOGIC1_X1] 0] library]]
puts "(hammer) repair_tie_fanout -separation 0 \$tielo_lib_name/LOGIC0_X1/Z"
repair_tie_fanout -separation 0 $tielo_lib_name/LOGIC0_X1/Z
puts "(hammer) repair_tie_fanout -separation 0 \$tiehi_lib_name/LOGIC1_X1/Z"
repair_tie_fanout -separation 0 $tiehi_lib_name/LOGIC1_X1/Z
puts "(hammer) write_db pre_detailed_placement"
write_db pre_detailed_placement
puts "(hammer) exec ln -sfn pre_detailed_placement latest"
exec ln -sfn pre_detailed_placement latest
################################################################
# Detail placement

puts "(hammer) set_placement_padding -global -left 2 -right 2"
set_placement_padding -global -left 2 -right 2
puts "(hammer) detailed_placement"
detailed_placement

# improve_placement
puts "(hammer) optimize_mirroring"
optimize_mirroring

puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement

puts "(hammer) write_reports dpl"
write_reports dpl
puts "(hammer) write_db pre_clock_tree"
write_db pre_clock_tree
puts "(hammer) exec ln -sfn pre_clock_tree latest"
exec ln -sfn pre_clock_tree latest
# Check Detailed Placement
puts "(hammer) check_placement -verbose"
check_placement -verbose
################################################################
# Clock Tree Synthesis
# Run TritonCTS
puts "(hammer) repair_clock_inverters"
repair_clock_inverters

puts "(hammer) clock_tree_synthesis -root_buf BUF_X4 -buf_list { BUF_X4 BUF_X8 } -sink_clustering_enable"
clock_tree_synthesis -root_buf BUF_X4 -buf_list { BUF_X4 BUF_X8 } -sink_clustering_enable \
                                -sink_clustering_size 30 \
                                -sink_clustering_max_diameter 100

puts "(hammer) set_propagated_clock \[all_clocks\]"
set_propagated_clock [all_clocks]

puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement

# CTS leaves a long wire from the pad to the clock tree root.
puts "(hammer) repair_clock_nets"
repair_clock_nets

puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement

puts "(hammer) set_placement_padding -global -left 1 -right 1"
set_placement_padding -global -left 1 -right 1

# place clock buffers
puts "(hammer) detailed_placement"
detailed_placement

puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement
puts "(hammer) write_db pre_clock_tree_resize"
write_db pre_clock_tree_resize
puts "(hammer) exec ln -sfn pre_clock_tree_resize latest"
exec ln -sfn pre_clock_tree_resize latest
###########################
# Post-CTS Timing repair
puts "(hammer) puts \"Design has \[llength \[get_cells *\]\] instances.\""
puts "Design has [llength [get_cells *]] instances." 

puts "(hammer) repair_timing -setup -setup_margin 0.05"
repair_timing -setup -setup_margin 0.05
puts "(hammer) repair_timing -hold -setup_margin 0.05 -hold_margin 0.01 -max_buffer_percent 60  -allow_setup_violations"
repair_timing -hold -setup_margin 0.05 -hold_margin 0.01 -max_buffer_percent 60  -allow_setup_violations

puts "(hammer) set_placement_padding -global -left 0 -right 0"
set_placement_padding -global -left 0 -right 0

puts "(hammer) detailed_placement"
detailed_placement

puts "(hammer) optimize_mirroring"
optimize_mirroring

puts "(hammer) estimate_parasitics -placement"
estimate_parasitics -placement

puts "(hammer) write_reports cts_rsz"
write_reports cts_rsz
puts "(hammer) write_db pre_dummy_step"
write_db pre_dummy_step
puts "(hammer) exec ln -sfn pre_dummy_step latest"
exec ln -sfn pre_dummy_step latest
puts "(hammer) write_db pre_global_route"
write_db pre_global_route
puts "(hammer) exec ln -sfn pre_global_route latest"
exec ln -sfn pre_global_route latest
# Check Detailed Placement
puts "(hammer) check_placement -verbose"
check_placement -verbose
################################################################
# Global routing
# reduce the routing resources of all routing layers by X%
puts "(hammer) set_global_routing_layer_adjustment metal2-metal10 0.3"
set_global_routing_layer_adjustment metal2-metal10 0.3
puts "(hammer) set_routing_layers -signal metal2-metal10 -clock metal4-metal10"
set_routing_layers -signal metal2-metal10 -clock metal4-metal10

# hard-coded in the example OpenROAD scripts
# set_macro_extension 2


puts "(hammer) global_route -guide_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.route_guide -congestion_iterations 150 -verbose -congestion_report_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/congestion.rpt"
global_route -guide_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.route_guide -congestion_iterations 150 -verbose -congestion_report_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/congestion.rpt
puts "(hammer) estimate_parasitics -global_routing"
estimate_parasitics -global_routing
puts "(hammer) write_db pre_global_route_resize"
write_db pre_global_route_resize
puts "(hammer) exec ln -sfn pre_global_route_resize latest"
exec ln -sfn pre_global_route_resize latest
###########################
# Post-GRT Timing repair

puts "(hammer) remove_fillers"
remove_fillers

puts "(hammer) set_global_routing_layer_adjustment metal2-metal10 0.3"
set_global_routing_layer_adjustment metal2-metal10 0.3
puts "(hammer) repair_timing -hold -hold_margin 0.01 -allow_setup_violations"
repair_timing -hold -hold_margin 0.01 -allow_setup_violations

puts "(hammer) detailed_placement"
detailed_placement

# post-timing optimizations STA
puts "(hammer) estimate_parasitics -global_routing"
estimate_parasitics -global_routing
# Check Detailed Placement
puts "(hammer) check_placement -verbose"
check_placement -verbose
################################################################
# Filler cell insertion

puts "(hammer) set_propagated_clock \[all_clocks\]"
set_propagated_clock [all_clocks]

puts "(hammer) filler_placement { FILLCELL_X1 FILLCELL_X2 FILLCELL_X4 FILLCELL_X8 FILLCELL_X16 FILLCELL_X32 }"
filler_placement { FILLCELL_X1 FILLCELL_X2 FILLCELL_X4 FILLCELL_X8 FILLCELL_X16 FILLCELL_X32 }
puts "(hammer) global_route -guide_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.route_guide -congestion_iterations 150 -verbose -congestion_report_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/congestion.rpt"
global_route -guide_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.route_guide -congestion_iterations 150 -verbose -congestion_report_file /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/congestion.rpt
puts "(hammer) estimate_parasitics -global_routing"
estimate_parasitics -global_routing

    puts "(hammer) write_reports grt_rsz"
    write_reports grt_rsz
    
puts "(hammer) write_db pre_place_final_fillers"
write_db pre_place_final_fillers
puts "(hammer) exec ln -sfn pre_place_final_fillers latest"
exec ln -sfn pre_place_final_fillers latest
# Check Detailed Placement
puts "(hammer) check_placement -verbose"
check_placement -verbose
################################################################
# Filler cell insertion

puts "(hammer) set_propagated_clock \[all_clocks\]"
set_propagated_clock [all_clocks]

puts "(hammer) filler_placement { FILLCELL_X1 FILLCELL_X2 FILLCELL_X4 FILLCELL_X8 FILLCELL_X16 FILLCELL_X32 }"
filler_placement { FILLCELL_X1 FILLCELL_X2 FILLCELL_X4 FILLCELL_X8 FILLCELL_X16 FILLCELL_X32 }
puts "(hammer) write_db pre_route_current_openroad"
write_db pre_route_current_openroad
puts "(hammer) exec ln -sfn pre_route_current_openroad latest"
exec ln -sfn pre_route_current_openroad latest
puts "(hammer) set_propagated_clock \[all_clocks\]"
set_propagated_clock [all_clocks]
puts "(hammer) set_thread_count 4"
set_thread_count 4
puts "(hammer) detailed_route -output_drc /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop_route_drc.rpt"
detailed_route -output_drc /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop_route_drc.rpt \
  -output_maze /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop_maze.log -save_guide_updates -verbose 1
puts "(hammer) write_db pre_extraction"
write_db pre_extraction
puts "(hammer) exec ln -sfn pre_extraction latest"
exec ln -sfn pre_extraction latest
################################################################
# Extraction
puts "(hammer) define_process_corner -ext_model_index 0 X"
define_process_corner -ext_model_index 0 X
puts "(hammer) extract_parasitics -ext_model_file /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/rcx_patterns.rules -corner_cnt 2"
extract_parasitics -ext_model_file /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/rcx_patterns.rules -corner_cnt 2
puts "(hammer) write_spef /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef"
write_spef /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef

# Read Spef for OpenSTA
# Read Spef for OpenSTA
puts "(hammer) read_spef -corner setup /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef"
read_spef -corner setup /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef
puts "(hammer) read_spef -corner hold /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef"
read_spef -corner hold /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef
puts "(hammer) write_db pre_report_routed"
write_db pre_report_routed
puts "(hammer) exec ln -sfn pre_report_routed latest"
exec ln -sfn pre_report_routed latest
puts "(hammer) set_power_activity -global -activity 0.1 -duty 0.5"
set_power_activity -global -activity 0.1 -duty 0.5
puts "(hammer) set_propagated_clock \[all_clocks\]"
set_propagated_clock [all_clocks]
puts "(hammer) global_connect"
global_connect
puts "(hammer) write_db /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/routed.odb"
write_db /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/routed.odb
puts "(hammer) write_def /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/routed.def"
write_def /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/routed.def
puts "(hammer) write_verilog /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/routed.v"
write_verilog /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/routed.v
puts "(hammer) puts FAST_FINAL_BEGIN"
puts FAST_FINAL_BEGIN
puts "(hammer) report_power -corner setup -digits 8"
report_power -corner setup -digits 8
puts "(hammer) report_worst_slack -max -digits 8"
report_worst_slack -max -digits 8
puts "(hammer) report_worst_slack -min -digits 8"
report_worst_slack -min -digits 8
puts "(hammer) report_check_types -max_slew -max_capacitance -violators"
report_check_types -max_slew -max_capacitance -violators
puts "(hammer) report_design_area"
report_design_area
puts "(hammer) set fast_filler_names {FILLCELL_X1 FILLCELL_X2 FILLCELL_X4 FILLCELL_X8 FILLCELL_X16 FILLCELL_X32}"
set fast_filler_names {FILLCELL_X1 FILLCELL_X2 FILLCELL_X4 FILLCELL_X8 FILLCELL_X16 FILLCELL_X32}
set block [ord::get_db_block]
set dbu [$block getDbUnitsPerMicron]
set cell_area 0.0
foreach inst [$block getInsts] {
    set master [$inst getMaster]
    # Nangate45 LEF labels FILLCELL as CORE, not CORE_SPACER. Use the
    # technology's explicit filler inventory, retaining CTS and tie cells.
    if {[$master getName] ni $fast_filler_names} {
        set cell_area [expr {$cell_area + double([$master getWidth])*[$master getHeight]/($dbu*$dbu)}]
    }
}
set die [$block getDieArea]
set core [$block getCoreArea]
puts "FAST_CELL_AREA_UM2 $cell_area"
puts "FAST_DIE_AREA_UM2 [expr {double([$die dx])*[$die dy]/($dbu*$dbu)}]"
puts "FAST_CORE_AREA_UM2 [expr {double([$core dx])*[$core dy]/($dbu*$dbu)}]"
puts FAST_FINAL_END
puts "(hammer) write_db post_report_routed"
write_db post_report_routed
puts "(hammer) exec ln -sfn post_report_routed latest"
exec ln -sfn post_report_routed latest
puts "(hammer) exit"
exit