create_clock clock -name clock -period 3.333
set_clock_uncertainty 0.1 [get_clocks clock]
set_clock_groups -asynchronous  -group { clock }

