// No latches expected in generated synchronous logic.
