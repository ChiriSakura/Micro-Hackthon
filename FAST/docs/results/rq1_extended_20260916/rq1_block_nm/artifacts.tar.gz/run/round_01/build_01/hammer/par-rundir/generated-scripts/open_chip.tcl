set db_name $::env(db_name)
set timing $::env(timing)

if {$timing} {
    define_corners setup hold
    read_liberty -corner setup /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
    read_liberty -corner hold /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/lib/NangateOpenCellLibrary_typical.lib
}
puts "Reading $db_name database..."
read_db $db_name
# Determine step & index
set steps { init_design floorplan_design place_bumps macro_placement place_tapcells power_straps global_placement io_placement resize detailed_placement clock_tree clock_tree_resize add_fillers global_route global_route_resize detailed_route extraction write_design }
set step [string map {pre_ ""} $db_name]
set step [string map {post_ ""} $step]
set step_idx [lsearch $steps $step]
if { [string range $db_name 0 3] == "pre_" } {
    set step_idx [expr $step_idx - 1]
}
set step [lindex $steps $step_idx]
if {$timing} {
    # TODO: need to read a later SDC with updated clock constraints?
    read_sdc -echo /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/clock_constraints_fragment.sdc
    read_sdc -echo /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/pin_constraints_fragment.sdc
    source /scratch/gz2522/gz2522/tmp/micro-hackthon/pdk/hammer45/setRC.tcl
    if { $step_idx >= [lsearch $steps "clock_tree"] } {
        puts "Post-CTS, propagate clocks..."
        set_propagated_clock [all_clocks]
    }

    if { ($step_idx >= [lsearch $steps "extraction"]) && ([file exists /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef] == 1) } {
        puts "Post-extraction, reading SPEF..."
        # Read Spef for OpenSTA
        read_spef -corner setup /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef
        read_spef -corner hold /scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_extended_v2_20260916/rq1_block_nm/round_01/build_01/hammer/par-rundir/Rq1BlockNmTop.par.spef
    } elseif { $step_idx >= [lsearch $steps "global_route"] } {
        puts "Post-global_route & pre-extraction, estimating parasitics from global route..."
        estimate_parasitics -global_routing
    } elseif { $step_idx >= [lsearch $steps "global_placement"] } {
        puts "Post-global_placement & pre-global_route, estimating parasitics from placement..."
        estimate_parasitics -placement
    }
}
if {$timing} {
    puts "Timing information loaded."
} else {
    puts "Timing information not loaded."
    puts "  To load database with timing information, run: "
    puts "  ./generated_scripts/open_chip \[db_name\] timing"
}
puts "Loaded Step $step_idx: $step ($db_name)."