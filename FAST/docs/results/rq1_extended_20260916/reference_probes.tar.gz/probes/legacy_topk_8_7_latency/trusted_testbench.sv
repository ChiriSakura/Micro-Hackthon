module FASTTestbench;
reg clock=0; always #5 clock=~clock;
reg reset=1,en=0;reg [15:0] data=0;wire [20:0] idx;wire [6:0] vld;
TopK dut(.clock(clock),.reset(reset),.io_enable(en),.io_inData(data),.io_idx_0(idx[0+:3]),.io_idxValid_0(vld[0]),.io_idx_1(idx[3+:3]),.io_idxValid_1(vld[1]),.io_idx_2(idx[6+:3]),.io_idxValid_2(vld[2]),.io_idx_3(idx[9+:3]),.io_idxValid_3(vld[3]),.io_idx_4(idx[12+:3]),.io_idxValid_4(vld[4]),.io_idx_5(idx[15+:3]),.io_idxValid_5(vld[5]),.io_idx_6(idx[18+:3]),.io_idxValid_6(vld[6]));
integer cycles=0,hits=0;
task tick(input integer enable,input [15:0] value);begin
 @(negedge clock); en=enable;data=value; @(posedge clock); #1;cycles=cycles+1;
 if(vld[0]) begin if(cycles!=8 || idx[0+:3]!=1) $fatal(1,"rank 0 timing/index"); hits=hits+1; $display("RANK 0 cycle=%0d",cycles); end
if(vld[1]) begin if(cycles!=9 || idx[3+:3]!=3) $fatal(1,"rank 1 timing/index"); hits=hits+1; $display("RANK 1 cycle=%0d",cycles); end
if(vld[2]) begin if(cycles!=10 || idx[6+:3]!=5) $fatal(1,"rank 2 timing/index"); hits=hits+1; $display("RANK 2 cycle=%0d",cycles); end
if(vld[3]) begin if(cycles!=11 || idx[9+:3]!=7) $fatal(1,"rank 3 timing/index"); hits=hits+1; $display("RANK 3 cycle=%0d",cycles); end
if(vld[4]) begin if(cycles!=12 || idx[12+:3]!=0) $fatal(1,"rank 4 timing/index"); hits=hits+1; $display("RANK 4 cycle=%0d",cycles); end
if(vld[5]) begin if(cycles!=13 || idx[15+:3]!=6) $fatal(1,"rank 5 timing/index"); hits=hits+1; $display("RANK 5 cycle=%0d",cycles); end
if(vld[6]) begin if(cycles!=14 || idx[18+:3]!=4) $fatal(1,"rank 6 timing/index"); hits=hits+1; $display("RANK 6 cycle=%0d",cycles); end
end endtask
initial begin repeat(3) @(negedge clock);reset=0;
tick(1,16'd4);
tick(1,16'd8);
tick(1,16'd1);
tick(1,16'd7);
tick(1,16'd2);
tick(1,16'd6);
tick(1,16'd3);
tick(1,16'd5);
repeat(8) tick(0,0);
if(hits!=7) $fatal(1,"missing ranks");
$display("FAST_CASE cycles=14");$display("FAST_PASS cases=1");$finish;end
endmodule
