//> using scala "2.13.12"
//> using dep "edu.berkeley.cs::chisel3:3.6.1"
//> using plugin "edu.berkeley.cs:::chisel3-plugin:3.6.1"
import chisel3.stage.ChiselStage
object Probe extends App {
(new ChiselStage).emitVerilog(new predict_unit.TopK(8,7,16,0), Array("--target-dir", args(0)))
}
