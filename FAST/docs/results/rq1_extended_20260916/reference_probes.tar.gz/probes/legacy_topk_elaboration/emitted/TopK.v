module TopFirst(
  input         clock,
  input         reset,
  input         io_enable, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 12:14]
  input  [15:0] io_inData, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 12:14]
  output [15:0] io_outData, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 12:14]
  output [2:0]  io_maxIdx, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 12:14]
  output [2:0]  io_outIdx, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 12:14]
  output        io_outValid // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 12:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
`endif // RANDOMIZE_REG_INIT
  reg [15:0] maxReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 21:23]
  reg [15:0] runnerUpReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 22:28]
  reg [2:0] posCounter; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 23:27]
  reg [2:0] maxIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 24:25]
  reg [2:0] runnerUpIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 25:30]
  reg  validPulse; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 26:27]
  wire [2:0] _posCounter_T_1 = posCounter + 3'h1; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 41:30]
  wire  _T_1 = posCounter == 3'h7; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 43:21]
  wire  _GEN_12 = io_enable & _T_1; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 30:19 57:16]
  assign io_outData = runnerUpReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 60:14]
  assign io_maxIdx = maxIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 62:13]
  assign io_outIdx = runnerUpIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 61:13]
  assign io_outValid = validPulse; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 63:15]
  always @(posedge clock) begin
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 21:23]
      maxReg <= 16'sh0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 21:23]
    end else if (io_enable) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 30:19]
      if (posCounter == 3'h7) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 43:40]
        maxReg <= 16'sh0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 51:14]
      end else if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 31:30]
        maxReg <= io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 34:14]
      end
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 22:28]
      runnerUpReg <= 16'sh0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 22:28]
    end else if (io_enable) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 30:19]
      if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 31:30]
        runnerUpReg <= maxReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 32:19]
      end else begin
        runnerUpReg <= io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 37:19]
      end
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 23:27]
      posCounter <= 3'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 23:27]
    end else if (io_enable) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 30:19]
      if (posCounter == 3'h7) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 43:40]
        posCounter <= 3'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 44:18]
      end else begin
        posCounter <= _posCounter_T_1; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 41:16]
      end
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 24:25]
      maxIndex <= 3'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 24:25]
    end else if (io_enable) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 30:19]
      if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 31:30]
        maxIndex <= posCounter; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 35:16]
      end
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 25:30]
      runnerUpIndex <= 3'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 25:30]
    end else if (io_enable) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 30:19]
      if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 31:30]
        runnerUpIndex <= maxIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 33:21]
      end else begin
        runnerUpIndex <= posCounter; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 38:21]
      end
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 26:27]
      validPulse <= 1'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 26:27]
    end else begin
      validPulse <= _GEN_12;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  maxReg = _RAND_0[15:0];
  _RAND_1 = {1{`RANDOM}};
  runnerUpReg = _RAND_1[15:0];
  _RAND_2 = {1{`RANDOM}};
  posCounter = _RAND_2[2:0];
  _RAND_3 = {1{`RANDOM}};
  maxIndex = _RAND_3[2:0];
  _RAND_4 = {1{`RANDOM}};
  runnerUpIndex = _RAND_4[2:0];
  _RAND_5 = {1{`RANDOM}};
  validPulse = _RAND_5[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module TopStage(
  input         clock,
  input         reset,
  input         io_inIdxValid, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
  input  [2:0]  io_inIdx, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
  input  [15:0] io_inData, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
  output [15:0] io_outData, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
  output [2:0]  io_maxIdx, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
  output [2:0]  io_outIdx, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
  output        io_outValid // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 68:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
`endif // RANDOMIZE_REG_INIT
  reg [15:0] maxReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 78:23]
  reg [15:0] runnerUpReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 79:28]
  reg [2:0] maxIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 80:25]
  reg [2:0] runnerUpIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 81:30]
  reg  validReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 82:25]
  assign io_outData = runnerUpReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 102:14]
  assign io_maxIdx = maxIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 104:13]
  assign io_outIdx = runnerUpIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 103:13]
  assign io_outValid = validReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 105:15]
  always @(posedge clock) begin
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 78:23]
      maxReg <= 16'sh0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 78:23]
    end else if (io_inIdxValid) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 94:23]
      maxReg <= 16'sh0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 97:12]
    end else if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 84:28]
      maxReg <= io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 87:12]
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 79:28]
      runnerUpReg <= 16'sh0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 79:28]
    end else if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 84:28]
      runnerUpReg <= maxReg; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 85:17]
    end else begin
      runnerUpReg <= io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 90:17]
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 80:25]
      maxIndex <= 3'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 80:25]
    end else if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 84:28]
      maxIndex <= io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 88:14]
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 81:30]
      runnerUpIndex <= 3'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 81:30]
    end else if ($signed(io_inData) > $signed(maxReg)) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 84:28]
      runnerUpIndex <= maxIndex; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 86:19]
    end else begin
      runnerUpIndex <= io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 91:19]
    end
    if (reset) begin // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 82:25]
      validReg <= 1'h0; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 82:25]
    end else begin
      validReg <= io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 100:12]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  maxReg = _RAND_0[15:0];
  _RAND_1 = {1{`RANDOM}};
  runnerUpReg = _RAND_1[15:0];
  _RAND_2 = {1{`RANDOM}};
  maxIndex = _RAND_2[2:0];
  _RAND_3 = {1{`RANDOM}};
  runnerUpIndex = _RAND_3[2:0];
  _RAND_4 = {1{`RANDOM}};
  validReg = _RAND_4[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module TopK(
  input         clock,
  input         reset,
  input         io_enable, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  input  [15:0] io_inData, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_0, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_1, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_2, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_3, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_4, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_5, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [15:0] io_outData_6, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_0, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_1, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_2, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_3, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_4, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_5, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output [2:0]  io_idx_6, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_0, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_1, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_2, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_3, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_4, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_5, // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
  output        io_idxValid_6 // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 111:14]
);
  wire  first_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire  first_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire  first_io_enable; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire [15:0] first_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire [15:0] first_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire [2:0] first_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire [2:0] first_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire  first_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
  wire  stages_0_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_0_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_0_io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_0_io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_0_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_0_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_0_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_0_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_0_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_1_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_1_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_1_io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_1_io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_1_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_1_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_1_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_1_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_1_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_2_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_2_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_2_io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_2_io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_2_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_2_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_2_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_2_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_2_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_3_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_3_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_3_io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_3_io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_3_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_3_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_3_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_3_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_3_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_4_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_4_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_4_io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_4_io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_4_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_4_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_4_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_4_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_4_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_5_clock; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_5_reset; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_5_io_inIdxValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_5_io_inIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_5_io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [15:0] stages_5_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_5_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire [2:0] stages_5_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  wire  stages_5_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
  TopFirst first ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 119:21]
    .clock(first_clock),
    .reset(first_reset),
    .io_enable(first_io_enable),
    .io_inData(first_io_inData),
    .io_outData(first_io_outData),
    .io_maxIdx(first_io_maxIdx),
    .io_outIdx(first_io_outIdx),
    .io_outValid(first_io_outValid)
  );
  TopStage stages_0 ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
    .clock(stages_0_clock),
    .reset(stages_0_reset),
    .io_inIdxValid(stages_0_io_inIdxValid),
    .io_inIdx(stages_0_io_inIdx),
    .io_inData(stages_0_io_inData),
    .io_outData(stages_0_io_outData),
    .io_maxIdx(stages_0_io_maxIdx),
    .io_outIdx(stages_0_io_outIdx),
    .io_outValid(stages_0_io_outValid)
  );
  TopStage stages_1 ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
    .clock(stages_1_clock),
    .reset(stages_1_reset),
    .io_inIdxValid(stages_1_io_inIdxValid),
    .io_inIdx(stages_1_io_inIdx),
    .io_inData(stages_1_io_inData),
    .io_outData(stages_1_io_outData),
    .io_maxIdx(stages_1_io_maxIdx),
    .io_outIdx(stages_1_io_outIdx),
    .io_outValid(stages_1_io_outValid)
  );
  TopStage stages_2 ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
    .clock(stages_2_clock),
    .reset(stages_2_reset),
    .io_inIdxValid(stages_2_io_inIdxValid),
    .io_inIdx(stages_2_io_inIdx),
    .io_inData(stages_2_io_inData),
    .io_outData(stages_2_io_outData),
    .io_maxIdx(stages_2_io_maxIdx),
    .io_outIdx(stages_2_io_outIdx),
    .io_outValid(stages_2_io_outValid)
  );
  TopStage stages_3 ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
    .clock(stages_3_clock),
    .reset(stages_3_reset),
    .io_inIdxValid(stages_3_io_inIdxValid),
    .io_inIdx(stages_3_io_inIdx),
    .io_inData(stages_3_io_inData),
    .io_outData(stages_3_io_outData),
    .io_maxIdx(stages_3_io_maxIdx),
    .io_outIdx(stages_3_io_outIdx),
    .io_outValid(stages_3_io_outValid)
  );
  TopStage stages_4 ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
    .clock(stages_4_clock),
    .reset(stages_4_reset),
    .io_inIdxValid(stages_4_io_inIdxValid),
    .io_inIdx(stages_4_io_inIdx),
    .io_inData(stages_4_io_inData),
    .io_outData(stages_4_io_outData),
    .io_maxIdx(stages_4_io_maxIdx),
    .io_outIdx(stages_4_io_outIdx),
    .io_outValid(stages_4_io_outValid)
  );
  TopStage stages_5 ( // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 120:38]
    .clock(stages_5_clock),
    .reset(stages_5_reset),
    .io_inIdxValid(stages_5_io_inIdxValid),
    .io_inIdx(stages_5_io_inIdx),
    .io_inData(stages_5_io_inData),
    .io_outData(stages_5_io_outData),
    .io_maxIdx(stages_5_io_maxIdx),
    .io_outIdx(stages_5_io_outIdx),
    .io_outValid(stages_5_io_outValid)
  );
  assign io_outData_0 = first_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 137:17]
  assign io_outData_1 = stages_0_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 142:19]
  assign io_outData_2 = stages_1_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 142:19]
  assign io_outData_3 = stages_2_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 142:19]
  assign io_outData_4 = stages_3_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 142:19]
  assign io_outData_5 = stages_4_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 142:19]
  assign io_outData_6 = stages_5_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 142:19]
  assign io_idx_0 = first_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 138:13]
  assign io_idx_1 = stages_0_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 143:15]
  assign io_idx_2 = stages_1_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 143:15]
  assign io_idx_3 = stages_2_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 143:15]
  assign io_idx_4 = stages_3_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 143:15]
  assign io_idx_5 = stages_4_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 143:15]
  assign io_idx_6 = stages_5_io_maxIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 143:15]
  assign io_idxValid_0 = first_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 139:18]
  assign io_idxValid_1 = stages_0_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 144:20]
  assign io_idxValid_2 = stages_1_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 144:20]
  assign io_idxValid_3 = stages_2_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 144:20]
  assign io_idxValid_4 = stages_3_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 144:20]
  assign io_idxValid_5 = stages_4_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 144:20]
  assign io_idxValid_6 = stages_5_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 144:20]
  assign first_clock = clock;
  assign first_reset = reset;
  assign first_io_enable = io_enable; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 123:19]
  assign first_io_inData = io_inData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 122:19]
  assign stages_0_clock = clock;
  assign stages_0_reset = reset;
  assign stages_0_io_inIdxValid = first_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 128:29]
  assign stages_0_io_inIdx = first_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 127:24]
  assign stages_0_io_inData = first_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 126:25]
  assign stages_1_clock = clock;
  assign stages_1_reset = reset;
  assign stages_1_io_inIdxValid = stages_0_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 133:31]
  assign stages_1_io_inIdx = stages_0_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 132:26]
  assign stages_1_io_inData = stages_0_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 131:27]
  assign stages_2_clock = clock;
  assign stages_2_reset = reset;
  assign stages_2_io_inIdxValid = stages_1_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 133:31]
  assign stages_2_io_inIdx = stages_1_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 132:26]
  assign stages_2_io_inData = stages_1_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 131:27]
  assign stages_3_clock = clock;
  assign stages_3_reset = reset;
  assign stages_3_io_inIdxValid = stages_2_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 133:31]
  assign stages_3_io_inIdx = stages_2_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 132:26]
  assign stages_3_io_inData = stages_2_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 131:27]
  assign stages_4_clock = clock;
  assign stages_4_reset = reset;
  assign stages_4_io_inIdxValid = stages_3_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 133:31]
  assign stages_4_io_inIdx = stages_3_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 132:26]
  assign stages_4_io_inData = stages_3_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 131:27]
  assign stages_5_clock = clock;
  assign stages_5_reset = reset;
  assign stages_5_io_inIdxValid = stages_4_io_outValid; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 133:31]
  assign stages_5_io_inIdx = stages_4_io_outIdx; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 132:26]
  assign stages_5_io_inData = stages_4_io_outData; // @[home/gz2522/Micro-Hackthon/FAST/hardware/chisel/src/main/scala/predict_unit/topk.scala 131:27]
endmodule
