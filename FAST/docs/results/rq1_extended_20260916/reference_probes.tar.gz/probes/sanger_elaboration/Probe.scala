//> using scala "2.13.12"
//> using dep "edu.berkeley.cs::chisel3:3.6.1"
//> using plugin "edu.berkeley.cs:::chisel3-plugin:3.6.1"
import chisel3.stage.ChiselStage
object Probe extends App {
(new ChiselStage).emitVerilog(new pe_row.Pack(8,4,4,3,3,8), Array("--target-dir", args(0)))
(new ChiselStage).emitVerilog(new pe_row.Dense_PE_Array(20,8,0,11,8,8), Array("--target-dir", args(0)))
(new ChiselStage).emitVerilog(new pe_row.Sparse_PE_Array(4,32,16,8,8,4,4,4), Array("--target-dir", args(0)))
}
