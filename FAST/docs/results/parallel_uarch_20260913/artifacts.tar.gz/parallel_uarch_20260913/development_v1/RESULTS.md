# 完整系统生成：Chisel / Verilog 集成验证

这是新主线的 bring-up 记录，不是 Critic 消融，也不是两种 HDL 的公平性能比较。

算法为 4-bit threshold-attention：QK 阈值筛选、加权求和、整数归一化。它不等于 DynaX 或 softmax attention。每轮使用独立 Python 参考驱动的 100 个全系统数值用例。

面积为完整生成顶层的 Nangate45 综合单元面积；功耗为 OpenSTA 全局活动率预布局估计，能量为该估计功耗乘以实测周期对应的延迟。没有布局布线或逐网工作负载活动标注。

| 运行 | 轮次 | 语言 | threshold | 验证 | 面积 µm² | 功耗 mW | 延迟 ns | 能量 nJ | slack ns | 可行 |
|---|---:|---|---:|---|---:|---:|---:|---:|---:|---|
| parallel_17596900 | 1 | — | 64 | failed | — | — | — | — | — | 否 |

## parallel_17596900

状态：`failed`；参考库完整性：`True`；保留的 Pareto 轮次：`[]`。

约束与预算：`{"algorithm": "threshold_attention", "prompt": "Design a complete threshold-sparse attention accelerator from q/k/v inputs to normalized output. Analyze the allowed threshold configurations, then co-design the complete datapath and control. Prefer reusable modules; explore energy-latency tradeoffs within measured quality, area and clock constraints.", "constraints": {"max_quality_loss": 0.15, "max_area_um2": 30000, "frequency_mhz": 100}, "max_loops": 1, "compiler_attempts": 2, "module_attempts": 3, "seed": 17, "kernel_profile_budget": 16, "activity": 0.1, "hdl": "chisel", "template_read_budget": 2, "module_workers": 3, "assembly_attempts": 3}`

LLM 调用次数：`{"kernel": 1, "compiler": 4, "critic": 0, "uarch": 0, "uarch_assembly": 0}`。

### 轮次 1

重入：`kernel`；状态：`failed`。

可信 Kernel 分析：`{"config": {"threshold": 64}, "quality_loss": 0.07025641025641026, "quality_metric": "mean absolute output error / 15 vs threshold=0", "quality_scope": "260 deterministic synthetic profiling queries; not model perplexity", "sparsity": 0.31634615384615383, "active_keys_histogram": {"0": 20, "1": 27, "2": 47, "3": 74, "4": 92}, "samples": 260, "seed": 17}`。

失败原因：`RuntimeError: Compiler/UArch build budget exhausted; see compiler_feedback.json`。

[完整结果](raw/parallel_17596900/summary.json) · [事件与反馈](raw/parallel_17596900/events.json)

## 证据使用边界

本记录证明的是指定契约下的系统生成、验证、测量和角色重入。单次变好或变差都不足以证明 Critic 相比无 Critic / 规则 Critic 更有效。下一步应冻结工作负载、初始设计和预算，做多 seed 的有/无 Critic 对照，并增加真实 DynaX 契约和工作负载活动标注。

raw 保留原日志中的绝对路径；它们对应运行时的 scratch 目录。归档的相对目录保持原层次。source 是执行时的冻结源码快照；当前工作区可能有后续兼容性修复，不能反向归算为本次运行的行为。
