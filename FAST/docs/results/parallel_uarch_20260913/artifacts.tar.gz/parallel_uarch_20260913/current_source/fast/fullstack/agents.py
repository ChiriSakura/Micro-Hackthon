"""Five distinct roles; all raw requests/replies are recorded before parsing."""
from __future__ import annotations

import json
from pathlib import Path
import time

from .library import save


class JsonAgent:
    def __init__(self, llm, role: str, audit: Path):
        self.llm, self.role, self.audit = llm, role, audit
        self.calls = 0

    def ask(self, instruction: str, context: dict) -> dict:
        self.calls += 1
        path = self.audit / self.role / f'{self.calls:04d}.json'
        prompt = (f'You are FAST {self.role} Agent. Return exactly one JSON object, no markdown.\n'
                  + instruction + '\nCONTEXT:\n' + json.dumps(context, ensure_ascii=False))
        record = {'role': self.role, 'prompt': prompt, 'started_unix': time.time()}
        save(path, record)
        try:
            reply = self.llm.prompt(prompt)
            record.update(response=reply.result, success=reply.success, stderr=reply.stderr,
                          wall_seconds=time.time()-record['started_unix'])
            save(path, record)
            if not reply.success:
                raise ValueError(f'{self.role} LLM failed: {reply.stderr}')
            body = reply.result.strip()
            if body.startswith('```'):
                body = body.split('\n', 1)[1].rsplit('```', 1)[0].strip()
            result = json.loads(body)
            if not isinstance(result, dict):
                raise ValueError('Expected a JSON object')
            return result
        except Exception as exc:
            record['error'] = f'{type(exc).__name__}: {exc}'
            save(path, record)
            raise


class KernelAgent(JsonAgent):
    def run(self, context):
        return self.ask('Select a legal algorithm configuration from config_space using the task prompt and measured_config_profiles. '
            'Do not change the specified algorithm. Return {"config": {...}, "rationale": "..."}. '
            'The trusted plugin will execute profiling and measure quality/sparsity; never invent measurements.', context)


class CompilerAgent(JsonAgent):
    def run(self, context):
        if not context.get('library_read_completed'):
            return self.ask('This is the library selection phase, before system planning. '
                'Inspect hardware_catalog and select the relevant reference code for the task. '
                'Return ONLY {"read_templates":["catalog_id"]}; use [] if none is appropriate. '
                'Do not return a system plan or simulate tool results. The actual code will be supplied '
                'on the next call, when you will design and assign module-specific references.', context)
        return self.ask('Design a COMPLETE synthesizable RTL system for the specified algorithm contract. '
            'Choose decomposition, dataflow, scheduling, buffer organization and numeric widths. '
            'Library retrieval is complete. reference_code contains the actual code you requested. '
            'Return ONLY one final system-plan object. Do not output or echo read_templates or any other object. '
            'Assign reference_ids separately for each module. '
            'Assign only IDs you have read; UArch receives only the references you bind to its module. '
            'Use [] only when no supplied template is appropriate and explain the from-scratch design. '
            'Reference templates are read-only examples; you may design new modules and topology. '
            'Reference classes are not automatically linked into the new design: adapt their logic inside '
            'the assigned module, or declare every required generated child explicitly in the module graph. '
            'Reference numeric formats may differ: explicitly account for unsigned/signed ranges, binary '
            'points, carry growth and zero-extension when adapting them to the task numeric bounds. '
            'Choose language chisel or verilog; obey task.hdl when not auto. Chisel backend is Scala 2.13.12/Chisel 3.6.1; '
            'Verilog backend is Verilog-2005. No external IP or blackboxes. Every dependency is a child module '
            'that must be instantiated; every module must be reachable from top. Use a few well-defined modules. '
            'All top ports must EXACTLY match algorithm ports. Declare each port separately with concrete numeric widths. '
            'Specify concrete child connections/protocol and cycle timing in implementation. '
            'You are the planner: prepare a separate design_prompt for EVERY module before dispatch. '
            'Independent non-top modules run in parallel UArch sessions; dependent modules wait for verified children. '
            'The top is reserved for a SEPARATE assembly UArch after all non-top modules pass. '
            'Make the top an integration/control wrapper around the planned compute modules. '
            'For each non-top module provide tests: 1..32 declarative scenarios with name and steps. '
            'Each step has inputs (unsigned bit-pattern integers), cycles (0..256), expected (output integers). '
            'First step of EACH scenario initializes ALL inputs except clock. Inputs persist between steps. '
            'The runner drives inputs with clock LOW, waits for combinational settling, applies cycles rising edges, '
            'then checks expected outputs with clock LOW. No automatic reset: specify reset steps when needed. '
            'Use cycles=0 for combinational modules. Every scenario checks every output at least once. '
            'Include normal and numeric boundary cases; compute expected values from module math BEFORE implementation. '
            'Double-check packed decimal inputs fit their port widths and dot products include EVERY lane. '
            'For example a synchronous b:=a register test begins with '
            '{"inputs":{"reset":1,"a":0},"cycles":1,"expected":{"b":0}}, then '
            '{"inputs":{"reset":0,"a":7},"cycles":1,"expected":{"b":7}}. '
            'For YOUR module, initialize every additional input (such as in_valid) as well. '
            'Use small, easily verified cases and calculate pipeline edge counts explicitly. '
            'If in_valid is held high for L cycles, L transactions enter a pipeline. Dropping it for ONE '
            'cycle does NOT flush an L-stage pipeline: wait L cycles before expecting out_valid=0. '
            'These tests are frozen before workers start; an inconsistent test/latency contract requires replanning. '
            'Address any UArch/verification feedback; do not change the algorithm math or trusted top contract. '
            'For Chisel, every named module is a zero-argument RawModule class, with individually named IO vals '
            '(no io Bundle prefix); explicitly plan clock/reset connections and use withClockAndReset for registers. '
            'Return {"language":"chisel|verilog", "top":"Name", "rationale":"...", "modules":[{"name":"...", "purpose":"...", '
            '"ports":[{"name":"...", "direction":"input|output", "width":1}], '
            '"dependencies":["Child"], "reference_ids":["catalog_id"], '
            '"implementation":"detailed architecture, arithmetic, connections, and how to adapt selected references", '
            '"design_prompt":"self-contained module assignment with function, protocol, timing and reference adaptation", '
            '"tests":[{"name":"boundary", "steps":[{"inputs":{"a":0},"cycles":0,"expected":{"b":0}}]}]}]}. '
            'Use tests:[] for the top, whose independent tests come from the algorithm plugin.', context)


class UArchAgent(JsonAgent):
    def run(self, context):
        return self.ask('Implement exactly the requested module of the Compiler system plan. '
            'Follow compiler_prompt. You own only this module; accepted dependency sources are immutable. '
            'Planner tests cannot be changed by you. If their expectations contradict the math or timing, request replanning. '
            'If you conclude that a test expects the wrong result or wrong valid timing, return ONLY '
            '{"replan_reason":"identify test name/step, actual expected math or timing, and required correction"}. '
            'Do not submit another implementation you already know will fail the same inconsistent test. '
            'Return {"source":"complete module source in system_plan.language", "rationale":"..."}. '
            'If language is chisel: use only chisel3 imports, one zero-argument class with the exact module name '
            'extending RawModule; internal Bundle/Record helper types are allowed. Do not redefine child modules. '
            'Use individually named IO vals (no io Bundle), Clock() for clock, Bool() for reset; '
            'use withClockAndReset(clock, reset) for ALL Reg/RegInit/RegNext/RegEnable creation and updates, '
            'and Module(new Child) for dependencies. Chisel UInt + truncates carry: use +& for widening sums '
            'and explicitly size each lane before packing with Cat. Assignment to a wider output does not '
            'recover carry bits lost inside intermediate expressions or concatenations. '
            'No package declaration, standalone App/main, file/process/network APIs, BlackBox, inline Verilog, '
            'compiler directives, dontTouch, print, assertion, or external libraries. Registers and IO must be fully assigned. '
            'For Chisel combinational modules without a clock port, use only combinational hardware. '
            'For Verilog: '
            'Use synthesizable Verilog-2005, explicit ports exactly as specified; no includes, testbench, '
            'system tasks, initial blocks, blackboxes, external modules or preprocessor conditionals. '
            'Instantiate exactly the declared child module types using their agreed interfaces. '
            'Widen unsigned expressions before addition/multiplication to avoid silent truncation; '
            'respect finite numeric bounds and synchronous reset/handshake contract. '
            'Implement the entire function, never placeholder outputs. '
            'Compiler has assigned reference_code and reference_provenance specifically for this module. '
            'Use that code as design guidance and explain the adaptation; return a new independent file. '
            'Critic UArch instructions may revise internal scheduling/latency while preserving the external handshake. '
            'If that conflicts with a fixed-cycle dependency in the plan, request a Compiler replan. '
            'If the plan is inconsistent, return {"replan_reason":"specific interface/architecture conflict"}. '
            'After a failed check, use the diagnostics to repair this module.', context)


class AssemblyUArchAgent(UArchAgent):
    def run(self, context):
        return super().run({**context, 'assignment':
            'You are the single SYSTEM ASSEMBLY UArch. All non-top modules have passed their frozen '
            'planner tests. Implement only the top integration/control wrapper. Connect accepted children '
            'using their actual ports and protocols. You cannot rewrite children. Whole-system golden '
            'verification failures are returned here for local top repair. If a child or plan must change, '
            'return replan_reason with the specific failing interface/function; do not conceal it in the top.'})


class CriticAgent(JsonAgent):
    def run(self, context):
        return self.ask('Analyze only the completed whole-system numerical verification and physical results. '
            'Optimize latency-energy Pareto subject to quality, cell area and clock constraints. '
            'Separate measurement from hypothesis. Power is a uniform-activity pre-layout estimate. '
            'Assign one actionable cross-layer intervention: kernel (legal sparse config), compiler '
            '(topology/scheduling), uarch (implementation under same module interfaces), or stop. '
            'Use history and retained Pareto designs; a regressing last round does not erase earlier best designs. '
            'Return {"layer":"kernel|compiler|uarch|stop", "reason":"...", '
            '"evidence":["evaluation.area_um2"], "instructions":"concrete change and expected effect"}. '
            'Choose evidence strings VERBATIM from available_evidence; include at least one. '
            'Do not prepend current. Do not invent a path or cite system_plan as a measured metric. '
            'Address validation_feedback if a previous reply was rejected.', context)


def validate_critique(value: dict, current: dict) -> dict:
    if value.get('layer') not in ('kernel', 'compiler', 'uarch', 'stop'):
        raise ValueError('Critic returned an invalid reentry layer')
    if not value.get('reason') or not value.get('instructions') or not value.get('evidence'):
        raise ValueError('Critic must provide reasoning, instructions and evidence')
    for path in value['evidence']:
        cursor = current
        if not isinstance(path, str) or not path.startswith(('evaluation.', 'profile.')):
            raise ValueError('Critic evidence must reference measured evaluation/profile')
        for part in path.split('.'):
            if not isinstance(cursor, dict) or part not in cursor:
                raise ValueError(f'Unknown Critic evidence path: {path}')
            cursor = cursor[part]
        if cursor is None:
            raise ValueError(f'Critic cites absent evidence: {path}')
    return value
