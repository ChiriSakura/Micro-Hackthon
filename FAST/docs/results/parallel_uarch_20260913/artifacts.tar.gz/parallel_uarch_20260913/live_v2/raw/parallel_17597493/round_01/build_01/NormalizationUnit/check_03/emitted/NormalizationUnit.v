module NormalizationUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 6:17]
  input         in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 7:20]
  input  [14:0] in_numerator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 8:24]
  input  [10:0] in_denominator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 9:26]
  output        out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 10:21]
  output [3:0]  out_result // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 11:22]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
`endif // RANDOMIZE_REG_INIT
  reg  s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:59]
  reg [14:0] s1_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 21:63]
  reg [10:0] s1_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 22:65]
  reg  pipeline_regs_0_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [15:0] pipeline_regs_0_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_0_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_0_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_0_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_0_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [15:0] pipeline_regs_1_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [15:0] pipeline_regs_2_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [15:0] pipeline_regs_3_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg [14:0] pipeline_regs_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  reg  pipeline_regs_4_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
  wire [14:0] initial_state_divisor = {4'h0,s1_denominator}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 75:36]
  wire  initial_state_divideByZero = s1_denominator == 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 76:49]
  wire [15:0] shifted_remainder = {15'h0,s1_numerator[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [15:0] _GEN_0 = {{1'd0}, initial_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire [16:0] trial_sub = shifted_remainder - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits = shifted_remainder >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_remainder = fits ? trial_sub[15:0] : shifted_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_quotient = {14'h0,fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_dividend = {s1_numerator[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_1 = {next_remainder[14:0],next_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_1 = shifted_remainder_1 - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_1 = shifted_remainder_1 >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_1_remainder = fits_1 ? trial_sub_1[15:0] : shifted_remainder_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_1_quotient = {next_quotient[13:0],fits_1}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_1_dividend = {next_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_2 = {next_1_remainder[14:0],next_1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_2 = shifted_remainder_2 - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_2 = shifted_remainder_2 >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [14:0] next_2_quotient = {next_1_quotient[13:0],fits_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_2_dividend = {next_1_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_3 = {pipeline_regs_0_remainder[14:0],pipeline_regs_0_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [15:0] _GEN_6 = {{1'd0}, pipeline_regs_0_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire [16:0] trial_sub_3 = shifted_remainder_3 - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_3 = shifted_remainder_3 >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_3_remainder = fits_3 ? trial_sub_3[15:0] : shifted_remainder_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_3_quotient = {pipeline_regs_0_quotient[13:0],fits_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_3_dividend = {pipeline_regs_0_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_4 = {next_3_remainder[14:0],next_3_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_4 = shifted_remainder_4 - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_4 = shifted_remainder_4 >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_4_remainder = fits_4 ? trial_sub_4[15:0] : shifted_remainder_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_4_quotient = {next_3_quotient[13:0],fits_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_4_dividend = {next_3_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_5 = {next_4_remainder[14:0],next_4_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_5 = shifted_remainder_5 - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_5 = shifted_remainder_5 >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [14:0] next_5_quotient = {next_4_quotient[13:0],fits_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_5_dividend = {next_4_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_6 = {pipeline_regs_1_remainder[14:0],pipeline_regs_1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [15:0] _GEN_12 = {{1'd0}, pipeline_regs_1_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire [16:0] trial_sub_6 = shifted_remainder_6 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_6 = shifted_remainder_6 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_6_remainder = fits_6 ? trial_sub_6[15:0] : shifted_remainder_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_6_quotient = {pipeline_regs_1_quotient[13:0],fits_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_6_dividend = {pipeline_regs_1_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_7 = {next_6_remainder[14:0],next_6_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_7 = shifted_remainder_7 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_7 = shifted_remainder_7 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_7_remainder = fits_7 ? trial_sub_7[15:0] : shifted_remainder_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_7_quotient = {next_6_quotient[13:0],fits_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_7_dividend = {next_6_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_8 = {next_7_remainder[14:0],next_7_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_8 = shifted_remainder_8 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_8 = shifted_remainder_8 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [14:0] next_8_quotient = {next_7_quotient[13:0],fits_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_8_dividend = {next_7_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_9 = {pipeline_regs_2_remainder[14:0],pipeline_regs_2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [15:0] _GEN_18 = {{1'd0}, pipeline_regs_2_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire [16:0] trial_sub_9 = shifted_remainder_9 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_9 = shifted_remainder_9 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_9_remainder = fits_9 ? trial_sub_9[15:0] : shifted_remainder_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_9_quotient = {pipeline_regs_2_quotient[13:0],fits_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_9_dividend = {pipeline_regs_2_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_10 = {next_9_remainder[14:0],next_9_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_10 = shifted_remainder_10 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_10 = shifted_remainder_10 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_10_remainder = fits_10 ? trial_sub_10[15:0] : shifted_remainder_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_10_quotient = {next_9_quotient[13:0],fits_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_10_dividend = {next_9_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_11 = {next_10_remainder[14:0],next_10_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_11 = shifted_remainder_11 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_11 = shifted_remainder_11 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [14:0] next_11_quotient = {next_10_quotient[13:0],fits_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_11_dividend = {next_10_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_12 = {pipeline_regs_3_remainder[14:0],pipeline_regs_3_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [15:0] _GEN_24 = {{1'd0}, pipeline_regs_3_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire [16:0] trial_sub_12 = shifted_remainder_12 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_12 = shifted_remainder_12 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_12_remainder = fits_12 ? trial_sub_12[15:0] : shifted_remainder_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_12_quotient = {pipeline_regs_3_quotient[13:0],fits_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_12_dividend = {pipeline_regs_3_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_13 = {next_12_remainder[14:0],next_12_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire [16:0] trial_sub_13 = shifted_remainder_13 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 53:46]
  wire  fits_13 = shifted_remainder_13 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [15:0] next_13_remainder = fits_13 ? trial_sub_13[15:0] : shifted_remainder_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
  wire [14:0] next_13_quotient = {next_12_quotient[13:0],fits_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] next_13_dividend = {next_12_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:26]
  wire [15:0] shifted_remainder_14 = {next_13_remainder[14:0],next_13_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 50:32]
  wire  fits_14 = shifted_remainder_14 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 54:34]
  wire [14:0] next_14_quotient = {next_13_quotient[13:0],fits_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 58:26]
  wire [14:0] result_quotient = pipeline_regs_4_divideByZero ? 15'h0 : pipeline_regs_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 94:28]
  assign out_valid = pipeline_regs_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 100:13]
  assign out_result = result_quotient[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 97:32]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:59]
      s1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:59]
    end else begin
      s1_valid <= in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:59]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 21:63]
      s1_numerator <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 21:63]
    end else begin
      s1_numerator <= in_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 21:63]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 22:65]
      s1_denominator <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 22:65]
    end else begin
      s1_denominator <= in_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 22:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_0_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_0_valid <= s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_0_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else if (fits_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
      pipeline_regs_0_remainder <= trial_sub_2[15:0];
    end else begin
      pipeline_regs_0_remainder <= shifted_remainder_2;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_0_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_0_quotient <= next_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_0_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_0_dividend <= next_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_0_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_0_divisor <= initial_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_0_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_0_divideByZero <= initial_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_1_valid <= pipeline_regs_0_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_1_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else if (fits_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
      pipeline_regs_1_remainder <= trial_sub_5[15:0];
    end else begin
      pipeline_regs_1_remainder <= shifted_remainder_5;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_1_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_1_quotient <= next_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_1_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_1_dividend <= next_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_1_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_1_divisor <= pipeline_regs_0_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_1_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_1_divideByZero <= pipeline_regs_0_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_2_valid <= pipeline_regs_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_2_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else if (fits_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
      pipeline_regs_2_remainder <= trial_sub_8[15:0];
    end else begin
      pipeline_regs_2_remainder <= shifted_remainder_8;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_2_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_2_quotient <= next_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_2_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_2_dividend <= next_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_2_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_2_divisor <= pipeline_regs_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_2_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_2_divideByZero <= pipeline_regs_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_3_valid <= pipeline_regs_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_3_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else if (fits_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 57:26]
      pipeline_regs_3_remainder <= trial_sub_11[15:0];
    end else begin
      pipeline_regs_3_remainder <= shifted_remainder_11;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_3_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_3_quotient <= next_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_3_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_3_dividend <= next_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_3_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_3_divisor <= pipeline_regs_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_3_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_3_divideByZero <= pipeline_regs_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_4_valid <= pipeline_regs_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_4_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_4_quotient <= next_14_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
      pipeline_regs_4_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 67:76]
    end else begin
      pipeline_regs_4_divideByZero <= pipeline_regs_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:22]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  s1_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  s1_numerator = _RAND_1[14:0];
  _RAND_2 = {1{`RANDOM}};
  s1_denominator = _RAND_2[10:0];
  _RAND_3 = {1{`RANDOM}};
  pipeline_regs_0_valid = _RAND_3[0:0];
  _RAND_4 = {1{`RANDOM}};
  pipeline_regs_0_remainder = _RAND_4[15:0];
  _RAND_5 = {1{`RANDOM}};
  pipeline_regs_0_quotient = _RAND_5[14:0];
  _RAND_6 = {1{`RANDOM}};
  pipeline_regs_0_dividend = _RAND_6[14:0];
  _RAND_7 = {1{`RANDOM}};
  pipeline_regs_0_divisor = _RAND_7[14:0];
  _RAND_8 = {1{`RANDOM}};
  pipeline_regs_0_divideByZero = _RAND_8[0:0];
  _RAND_9 = {1{`RANDOM}};
  pipeline_regs_1_valid = _RAND_9[0:0];
  _RAND_10 = {1{`RANDOM}};
  pipeline_regs_1_remainder = _RAND_10[15:0];
  _RAND_11 = {1{`RANDOM}};
  pipeline_regs_1_quotient = _RAND_11[14:0];
  _RAND_12 = {1{`RANDOM}};
  pipeline_regs_1_dividend = _RAND_12[14:0];
  _RAND_13 = {1{`RANDOM}};
  pipeline_regs_1_divisor = _RAND_13[14:0];
  _RAND_14 = {1{`RANDOM}};
  pipeline_regs_1_divideByZero = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  pipeline_regs_2_valid = _RAND_15[0:0];
  _RAND_16 = {1{`RANDOM}};
  pipeline_regs_2_remainder = _RAND_16[15:0];
  _RAND_17 = {1{`RANDOM}};
  pipeline_regs_2_quotient = _RAND_17[14:0];
  _RAND_18 = {1{`RANDOM}};
  pipeline_regs_2_dividend = _RAND_18[14:0];
  _RAND_19 = {1{`RANDOM}};
  pipeline_regs_2_divisor = _RAND_19[14:0];
  _RAND_20 = {1{`RANDOM}};
  pipeline_regs_2_divideByZero = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  pipeline_regs_3_valid = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  pipeline_regs_3_remainder = _RAND_22[15:0];
  _RAND_23 = {1{`RANDOM}};
  pipeline_regs_3_quotient = _RAND_23[14:0];
  _RAND_24 = {1{`RANDOM}};
  pipeline_regs_3_dividend = _RAND_24[14:0];
  _RAND_25 = {1{`RANDOM}};
  pipeline_regs_3_divisor = _RAND_25[14:0];
  _RAND_26 = {1{`RANDOM}};
  pipeline_regs_3_divideByZero = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  pipeline_regs_4_valid = _RAND_27[0:0];
  _RAND_28 = {1{`RANDOM}};
  pipeline_regs_4_quotient = _RAND_28[14:0];
  _RAND_29 = {1{`RANDOM}};
  pipeline_regs_4_divideByZero = _RAND_29[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
