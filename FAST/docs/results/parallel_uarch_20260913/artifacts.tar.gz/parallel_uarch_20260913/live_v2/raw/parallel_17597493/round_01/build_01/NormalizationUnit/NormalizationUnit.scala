import chisel3._
import chisel3.util._

class NormalizationUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val in_valid = IO(Input(Bool()))
  val in_numerator = IO(Input(UInt(15.W)))
  val in_denominator = IO(Input(UInt(11.W)))
  val out_valid = IO(Output(Bool()))
  val out_result = IO(Output(UInt(4.W)))

  // This module implements a 6-cycle latency unsigned integer divider.
  // The architecture is a 1-cycle input register stage followed by a 5-stage
  // pipelined restoring divider core, matching the design prompt.

  // --- Stage 1: Input Registration ---
  // Register inputs to hold them stable for the pipeline. The valid signal for the
  // entire pipeline is initiated here, starting the 6-cycle latency period.
  val s1_valid = withClockAndReset(clock, reset) { RegNext(in_valid, false.B) }
  val s1_numerator = withClockAndReset(clock, reset) { RegNext(in_numerator, 0.U) }
  val s1_denominator = withClockAndReset(clock, reset) { RegNext(in_denominator, 0.U) }

  // --- 5-Stage Divider Core ---

  // Bundle to hold the state that is passed down the pipeline.
  // This is adapted from the `DivState` in the `pipelined_divider` reference.
  // Sign-related fields are removed as this is an unsigned divider.
  class DividerState extends Bundle {
    val valid        = Bool()
    val remainder    = UInt(16.W) // Needs to be 1 bit wider than divisor for trial subtraction
    val quotient     = UInt(15.W)
    val dividend     = UInt(15.W)
    val divisor      = UInt(15.W)
    val divideByZero = Bool()
  }

  // Combinational logic for a single radix-2 restoring division step.
  // Adapted from the `step` function in the reference design.
  def division_step(state: DividerState): DividerState = {
    val next = Wire(new DividerState)
    
    // Propagate control and static values through the step
    next.valid        := state.valid
    next.divisor      := state.divisor
    next.divideByZero := state.divideByZero

    // Core restoring division algorithm:
    // 1. Shift partial remainder left and bring in the next dividend bit.
    val shifted_remainder = Cat(state.remainder(14, 0), state.dividend(14))
    
    // 2. Trial subtraction to see if the divisor fits.
    val trial_sub = shifted_remainder.asUInt -& state.divisor.asUInt
    val fits = shifted_remainder >= state.divisor

    // 3. Update remainder and quotient based on the subtraction result.
    next.remainder := Mux(fits, trial_sub(15, 0), shifted_remainder)
    next.quotient  := Cat(state.quotient(13, 0), fits)
    
    // 4. Shift dividend left to prepare for the next iteration.
    next.dividend  := Cat(state.dividend(13, 0), 0.U(1.W))
    
    next
  }

  // Instantiate the 5 pipeline stage registers.
  val pipeline_regs = Seq.fill(5)(withClockAndReset(clock, reset) { RegInit(0.U.asTypeOf(new DividerState)) })

  // Define the initial state for the pipeline, fed from the input registers.
  val initial_state = Wire(new DividerState)
  initial_state.valid        := s1_valid
  initial_state.remainder    := 0.U
  initial_state.quotient     := 0.U
  initial_state.dividend     := s1_numerator
  initial_state.divisor      := Cat(0.U(4.W), s1_denominator) // Zero-extend 11-bit denominator to 15 bits
  initial_state.divideByZero := (s1_denominator === 0.U)

  // Unroll the pipeline logic, connecting the stages.
  var current_stage_out = initial_state
  for (i <- 0 until 5) {
    // Each combinational stage between registers performs 3 division iterations.
    var combinational_logic_out = current_stage_out
    for (j <- 0 until 3) {
      combinational_logic_out = division_step(combinational_logic_out)
    }
    pipeline_regs(i) := combinational_logic_out
    current_stage_out = pipeline_regs(i)
  }

  val final_state = pipeline_regs.last

  // --- Output Logic ---
  // Select 0 if division by zero occurred, otherwise use the calculated quotient.
  val result_quotient = Mux(final_state.divideByZero, 0.U, final_state.quotient)

  // Truncate the final 15-bit result to the required 4-bit output width.
  out_result := result_quotient(3, 0)
  
  // The valid signal has propagated through the 1 (input) + 5 (divider) = 6 pipeline stages.
  out_valid := final_state.valid
}