import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val in_q = IO(Input(UInt(8.W)))
  val in_k = IO(Input(UInt(8.W)))
  val out_score = IO(Output(UInt(9.W)))

  // Unpack inputs into 4-bit components as per the specification.
  // in_q[3:0] is the first element (d=0), in_q[7:4] is the second (d=1).
  val q0 = in_q(3, 0)
  val q1 = in_q(7, 4)

  // in_k[3:0] is the first element (d=0), in_k[7:4] is the second (d=1).
  val k0 = in_k(3, 0)
  val k1 = in_k(7, 4)

  // Compute the two products. A 4-bit by 4-bit multiplication results in an 8-bit value.
  val prod0 = q0 * k0
  val prod1 = q1 * k1

  // Sum the two 8-bit products. The widening add operator `+&` is used as requested
  // to produce a 9-bit result, which prevents overflow. The maximum possible score is
  // (15*15) + (15*15) = 225 + 225 = 450, which requires 9 bits (2^9 = 512).
  out_score := prod0 +& prod1
}
