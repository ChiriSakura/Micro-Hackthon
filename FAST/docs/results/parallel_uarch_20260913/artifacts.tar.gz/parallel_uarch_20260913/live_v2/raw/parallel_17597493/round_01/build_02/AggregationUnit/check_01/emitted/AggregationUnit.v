module AggregationUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 4:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 5:17]
  input         in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 6:20]
  input  [35:0] in_scores, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 7:21]
  input  [15:0] in_v, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 8:16]
  output        out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 9:21]
  output [10:0] out_sum_weights, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 10:27]
  output [14:0] out_weighted_value_sum // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 11:34]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
`endif // RANDOMIZE_REG_INIT
  wire [8:0] scores_0 = in_scores[8:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 18:29]
  wire [3:0] vs_0 = in_v[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:20]
  wire [8:0] scores_1 = in_scores[17:9]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 18:29]
  wire [3:0] vs_1 = in_v[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:20]
  wire [8:0] scores_2 = in_scores[26:18]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 18:29]
  wire [3:0] vs_2 = in_v[11:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:20]
  wire [8:0] scores_3 = in_scores[35:27]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 18:29]
  wire [3:0] vs_3 = in_v[15:12]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:20]
  wire [8:0] weights_0 = scores_0 >= 9'h40 ? scores_0 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
  wire [12:0] weighted_values_0 = weights_0 * vs_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:40]
  wire [8:0] weights_1 = scores_1 >= 9'h40 ? scores_1 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
  wire [12:0] weighted_values_1 = weights_1 * vs_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:40]
  wire [8:0] weights_2 = scores_2 >= 9'h40 ? scores_2 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
  wire [12:0] weighted_values_2 = weights_2 * vs_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:40]
  wire [8:0] weights_3 = scores_3 >= 9'h40 ? scores_3 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
  wire [12:0] weighted_values_3 = weights_3 * vs_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:40]
  reg  valid_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 33:27]
  reg [8:0] weights_s1_0_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
  reg [12:0] weighted_values_s1_0_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
  reg [8:0] weights_s1_1_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
  reg [12:0] weighted_values_s1_1_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
  reg [8:0] weights_s1_2_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
  reg [12:0] weighted_values_s1_2_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
  reg [8:0] weights_s1_3_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
  reg [12:0] weighted_values_s1_3_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
  wire [9:0] sum_weights_01 = weights_s1_0_REG + weights_s1_1_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 42:40]
  wire [9:0] sum_weights_23 = weights_s1_2_REG + weights_s1_3_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 43:40]
  wire [13:0] sum_weighted_values_01 = weighted_values_s1_0_REG + weighted_values_s1_1_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 44:56]
  wire [13:0] sum_weighted_values_23 = weighted_values_s1_2_REG + weighted_values_s1_3_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 45:56]
  reg  valid_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:27]
  reg [9:0] sum_weights_01_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:36]
  reg [9:0] sum_weights_23_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 50:36]
  reg [13:0] sum_weighted_values_01_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 51:44]
  reg [13:0] sum_weighted_values_23_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 52:44]
  reg  out_valid_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 55:25]
  wire [10:0] _out_sum_weights_T = sum_weights_01_s2 + sum_weights_23_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:50]
  reg [10:0] out_sum_weights_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:31]
  wire [14:0] _out_weighted_value_sum_T = sum_weighted_values_01_s2 + sum_weighted_values_23_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:65]
  reg [14:0] out_weighted_value_sum_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:38]
  assign out_valid = out_valid_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 55:15]
  assign out_sum_weights = out_sum_weights_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:21]
  assign out_weighted_value_sum = out_weighted_value_sum_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:28]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 33:27]
      valid_s1 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 33:27]
    end else begin
      valid_s1 <= in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 33:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
      weights_s1_0_REG <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
    end else if (scores_0 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
      weights_s1_0_REG <= scores_0;
    end else begin
      weights_s1_0_REG <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
      weighted_values_s1_0_REG <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end else begin
      weighted_values_s1_0_REG <= weighted_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
      weights_s1_1_REG <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
    end else if (scores_1 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
      weights_s1_1_REG <= scores_1;
    end else begin
      weights_s1_1_REG <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
      weighted_values_s1_1_REG <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end else begin
      weighted_values_s1_1_REG <= weighted_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
      weights_s1_2_REG <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
    end else if (scores_2 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
      weights_s1_2_REG <= scores_2;
    end else begin
      weights_s1_2_REG <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
      weighted_values_s1_2_REG <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end else begin
      weighted_values_s1_2_REG <= weighted_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
      weights_s1_3_REG <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 37:31]
    end else if (scores_3 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 28:24]
      weights_s1_3_REG <= scores_3;
    end else begin
      weights_s1_3_REG <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
      weighted_values_s1_3_REG <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end else begin
      weighted_values_s1_3_REG <= weighted_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 38:39]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:27]
      valid_s2 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:27]
    end else begin
      valid_s2 <= valid_s1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:36]
      sum_weights_01_s2 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:36]
    end else begin
      sum_weights_01_s2 <= sum_weights_01; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:36]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 50:36]
      sum_weights_23_s2 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 50:36]
    end else begin
      sum_weights_23_s2 <= sum_weights_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 50:36]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 51:44]
      sum_weighted_values_01_s2 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 51:44]
    end else begin
      sum_weighted_values_01_s2 <= sum_weighted_values_01; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 51:44]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 52:44]
      sum_weighted_values_23_s2 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 52:44]
    end else begin
      sum_weighted_values_23_s2 <= sum_weighted_values_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 52:44]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 55:25]
      out_valid_REG <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 55:25]
    end else begin
      out_valid_REG <= valid_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 55:25]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:31]
      out_sum_weights_REG <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:31]
    end else begin
      out_sum_weights_REG <= _out_sum_weights_T; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:31]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:38]
      out_weighted_value_sum_REG <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:38]
    end else begin
      out_weighted_value_sum_REG <= _out_weighted_value_sum_T; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:38]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  valid_s1 = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  weights_s1_0_REG = _RAND_1[8:0];
  _RAND_2 = {1{`RANDOM}};
  weighted_values_s1_0_REG = _RAND_2[12:0];
  _RAND_3 = {1{`RANDOM}};
  weights_s1_1_REG = _RAND_3[8:0];
  _RAND_4 = {1{`RANDOM}};
  weighted_values_s1_1_REG = _RAND_4[12:0];
  _RAND_5 = {1{`RANDOM}};
  weights_s1_2_REG = _RAND_5[8:0];
  _RAND_6 = {1{`RANDOM}};
  weighted_values_s1_2_REG = _RAND_6[12:0];
  _RAND_7 = {1{`RANDOM}};
  weights_s1_3_REG = _RAND_7[8:0];
  _RAND_8 = {1{`RANDOM}};
  weighted_values_s1_3_REG = _RAND_8[12:0];
  _RAND_9 = {1{`RANDOM}};
  valid_s2 = _RAND_9[0:0];
  _RAND_10 = {1{`RANDOM}};
  sum_weights_01_s2 = _RAND_10[9:0];
  _RAND_11 = {1{`RANDOM}};
  sum_weights_23_s2 = _RAND_11[9:0];
  _RAND_12 = {1{`RANDOM}};
  sum_weighted_values_01_s2 = _RAND_12[13:0];
  _RAND_13 = {1{`RANDOM}};
  sum_weighted_values_23_s2 = _RAND_13[13:0];
  _RAND_14 = {1{`RANDOM}};
  out_valid_REG = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  out_sum_weights_REG = _RAND_15[10:0];
  _RAND_16 = {1{`RANDOM}};
  out_weighted_value_sum_REG = _RAND_16[14:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
