module FASTTestbench;
reg [7:0] in_q;
reg [7:0] in_k;
wire [8:0] out_score;
ScoreCalculator dut(.in_q(in_q),.in_k(in_k),.out_score(out_score));
initial begin
in_q=8'd0;
in_k=8'd0;
#5;
if (out_score !== 9'd0) $fatal(1,"module case=0 step=0 output=out_score expected=0 actual=%0d",out_score);
$display("FAST_CASE cycles=1");
in_q=8'd255;
in_k=8'd255;
#5;
if (out_score !== 9'd450) $fatal(1,"module case=1 step=0 output=out_score expected=450 actual=%0d",out_score);
$display("FAST_CASE cycles=1");
in_q=8'd33;
in_k=8'd67;
#5;
if (out_score !== 9'd11) $fatal(1,"module case=2 step=0 output=out_score expected=11 actual=%0d",out_score);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=3");
$finish;
end
endmodule