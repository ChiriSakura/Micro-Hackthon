module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] in_valid;
reg [35:0] in_scores;
reg [15:0] in_v;
wire [0:0] out_valid;
wire [10:0] out_sum_weights;
wire [14:0] out_weighted_value_sum;
AggregationUnit dut(.clock(clock),.reset(reset),.in_valid(in_valid),.in_scores(in_scores),.in_v(in_v),.out_valid(out_valid),.out_sum_weights(out_sum_weights),.out_weighted_value_sum(out_weighted_value_sum));
initial begin
clock=0;
reset=1'd1;
in_valid=1'd0;
in_scores=36'd0;
in_v=16'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=0 step=0 output=out_valid expected=0 actual=%0d",out_valid);
if (out_sum_weights !== 11'd0) $fatal(1,"module case=0 step=0 output=out_sum_weights expected=0 actual=%0d",out_sum_weights);
if (out_weighted_value_sum !== 15'd0) $fatal(1,"module case=0 step=0 output=out_weighted_value_sum expected=0 actual=%0d",out_weighted_value_sum);
reset=1'd0;
in_valid=1'd1;
in_scores=36'd5376583690;
in_v=16'd17185;
#5;
repeat (3) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd1) $fatal(1,"module case=0 step=1 output=out_valid expected=1 actual=%0d",out_valid);
if (out_sum_weights !== 11'd0) $fatal(1,"module case=0 step=1 output=out_sum_weights expected=0 actual=%0d",out_sum_weights);
if (out_weighted_value_sum !== 15'd0) $fatal(1,"module case=0 step=1 output=out_weighted_value_sum expected=0 actual=%0d",out_weighted_value_sum);
in_valid=1'd0;
#5;
repeat (3) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=0 step=2 output=out_valid expected=0 actual=%0d",out_valid);
$display("FAST_CASE cycles=1");
reset=1'd1;
in_valid=1'd0;
in_scores=36'd0;
in_v=16'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=1 step=0 output=out_valid expected=0 actual=%0d",out_valid);
if (out_sum_weights !== 11'd0) $fatal(1,"module case=1 step=0 output=out_sum_weights expected=0 actual=%0d",out_sum_weights);
if (out_weighted_value_sum !== 15'd0) $fatal(1,"module case=1 step=0 output=out_weighted_value_sum expected=0 actual=%0d",out_weighted_value_sum);
reset=1'd0;
in_valid=1'd1;
in_scores=36'd13448038500;
in_v=16'd17185;
#5;
repeat (3) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd1) $fatal(1,"module case=1 step=1 output=out_valid expected=1 actual=%0d",out_valid);
if (out_sum_weights !== 11'd400) $fatal(1,"module case=1 step=1 output=out_sum_weights expected=400 actual=%0d",out_sum_weights);
if (out_weighted_value_sum !== 15'd1000) $fatal(1,"module case=1 step=1 output=out_weighted_value_sum expected=1000 actual=%0d",out_weighted_value_sum);
$display("FAST_CASE cycles=1");
reset=1'd1;
in_valid=1'd0;
in_scores=36'd0;
in_v=16'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=2 step=0 output=out_valid expected=0 actual=%0d",out_valid);
if (out_sum_weights !== 11'd0) $fatal(1,"module case=2 step=0 output=out_sum_weights expected=0 actual=%0d",out_sum_weights);
if (out_weighted_value_sum !== 15'd0) $fatal(1,"module case=2 step=0 output=out_weighted_value_sum expected=0 actual=%0d",out_weighted_value_sum);
reset=1'd0;
in_valid=1'd1;
in_scores=36'd7759404092;
in_v=16'd34661;
#5;
repeat (3) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd1) $fatal(1,"module case=2 step=1 output=out_valid expected=1 actual=%0d",out_valid);
if (out_sum_weights !== 11'd240) $fatal(1,"module case=2 step=1 output=out_sum_weights expected=240 actual=%0d",out_sum_weights);
if (out_weighted_value_sum !== 15'd1700) $fatal(1,"module case=2 step=1 output=out_weighted_value_sum expected=1700 actual=%0d",out_weighted_value_sum);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=3");
$finish;
end
endmodule