module AggregationUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 6:17]
  input         in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 7:20]
  input  [35:0] in_scores, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 8:21]
  input  [15:0] in_v, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 9:16]
  output        out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 10:21]
  output [10:0] out_sum_weights, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 11:27]
  output [14:0] out_weighted_value_sum // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 12:34]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
`endif // RANDOMIZE_REG_INIT
  wire [8:0] scores_0 = in_scores[8:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:29]
  wire [3:0] vs_0 = in_v[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 20:20]
  wire [8:0] scores_1 = in_scores[17:9]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:29]
  wire [3:0] vs_1 = in_v[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 20:20]
  wire [8:0] scores_2 = in_scores[26:18]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:29]
  wire [3:0] vs_2 = in_v[11:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 20:20]
  wire [8:0] scores_3 = in_scores[35:27]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 19:29]
  wire [3:0] vs_3 = in_v[15:12]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 20:20]
  wire [8:0] s1_weights_0 = scores_0 >= 9'h40 ? scores_0 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
  wire [12:0] s1_weighted_values_0 = s1_weights_0 * vs_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 30:46]
  wire [8:0] s1_weights_1 = scores_1 >= 9'h40 ? scores_1 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
  wire [12:0] s1_weighted_values_1 = s1_weights_1 * vs_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 30:46]
  wire [8:0] s1_weights_2 = scores_2 >= 9'h40 ? scores_2 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
  wire [12:0] s1_weighted_values_2 = s1_weights_2 * vs_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 30:46]
  wire [8:0] s1_weights_3 = scores_3 >= 9'h40 ? scores_3 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
  wire [12:0] s1_weighted_values_3 = s1_weights_3 * vs_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 30:46]
  reg  s2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 34:27]
  reg [8:0] s2_weights_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
  reg [8:0] s2_weights_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
  reg [8:0] s2_weights_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
  reg [8:0] s2_weights_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
  reg [12:0] s2_weighted_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
  reg [12:0] s2_weighted_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
  reg [12:0] s2_weighted_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
  reg [12:0] s2_weighted_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
  wire [9:0] s2_sum_weights_01 = s2_weights_0 + s2_weights_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 39:43]
  wire [9:0] s2_sum_weights_23 = s2_weights_2 + s2_weights_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 40:43]
  wire [13:0] s2_sum_weighted_values_01 = s2_weighted_values_0 + s2_weighted_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 41:59]
  wire [13:0] s2_sum_weighted_values_23 = s2_weighted_values_2 + s2_weighted_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 42:59]
  reg  s3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 45:27]
  reg [9:0] s3_sum_weights_01; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 46:36]
  reg [9:0] s3_sum_weights_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 47:36]
  reg [13:0] s3_sum_weighted_values_01; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:44]
  reg [13:0] s3_sum_weighted_values_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:44]
  wire [10:0] s3_final_sum_weights = s3_sum_weights_01 + s3_sum_weights_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 52:50]
  wire [14:0] s3_final_weighted_value_sum = s3_sum_weighted_values_01 + s3_sum_weighted_values_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 53:65]
  reg  out_valid_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:25]
  reg [10:0] out_sum_weights_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:31]
  reg [14:0] out_weighted_value_sum_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 58:38]
  assign out_valid = out_valid_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:15]
  assign out_sum_weights = out_sum_weights_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:21]
  assign out_weighted_value_sum = out_weighted_value_sum_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 58:28]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 34:27]
      s2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 34:27]
    end else begin
      s2_valid <= in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 34:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
      s2_weights_0 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
    end else if (scores_0 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
      s2_weights_0 <= scores_0;
    end else begin
      s2_weights_0 <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
      s2_weights_1 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
    end else if (scores_1 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
      s2_weights_1 <= scores_1;
    end else begin
      s2_weights_1 <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
      s2_weights_2 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
    end else if (scores_2 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
      s2_weights_2 <= scores_2;
    end else begin
      s2_weights_2 <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
      s2_weights_3 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 35:29]
    end else if (scores_3 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 29:27]
      s2_weights_3 <= scores_3;
    end else begin
      s2_weights_3 <= 9'h0;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
      s2_weighted_values_0 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end else begin
      s2_weighted_values_0 <= s1_weighted_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
      s2_weighted_values_1 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end else begin
      s2_weighted_values_1 <= s1_weighted_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
      s2_weighted_values_2 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end else begin
      s2_weighted_values_2 <= s1_weighted_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
      s2_weighted_values_3 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end else begin
      s2_weighted_values_3 <= s1_weighted_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 36:37]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 45:27]
      s3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 45:27]
    end else begin
      s3_valid <= s2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 45:27]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 46:36]
      s3_sum_weights_01 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 46:36]
    end else begin
      s3_sum_weights_01 <= s2_sum_weights_01; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 46:36]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 47:36]
      s3_sum_weights_23 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 47:36]
    end else begin
      s3_sum_weights_23 <= s2_sum_weights_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 47:36]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:44]
      s3_sum_weighted_values_01 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:44]
    end else begin
      s3_sum_weighted_values_01 <= s2_sum_weighted_values_01; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 48:44]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:44]
      s3_sum_weighted_values_23 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:44]
    end else begin
      s3_sum_weighted_values_23 <= s2_sum_weighted_values_23; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 49:44]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:25]
      out_valid_REG <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:25]
    end else begin
      out_valid_REG <= s3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 56:25]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:31]
      out_sum_weights_REG <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:31]
    end else begin
      out_sum_weights_REG <= s3_final_sum_weights; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 57:31]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 58:38]
      out_weighted_value_sum_REG <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 58:38]
    end else begin
      out_weighted_value_sum_REG <= s3_final_weighted_value_sum; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/AggregationUnit/AggregationUnit.scala 58:38]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  s2_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  s2_weights_0 = _RAND_1[8:0];
  _RAND_2 = {1{`RANDOM}};
  s2_weights_1 = _RAND_2[8:0];
  _RAND_3 = {1{`RANDOM}};
  s2_weights_2 = _RAND_3[8:0];
  _RAND_4 = {1{`RANDOM}};
  s2_weights_3 = _RAND_4[8:0];
  _RAND_5 = {1{`RANDOM}};
  s2_weighted_values_0 = _RAND_5[12:0];
  _RAND_6 = {1{`RANDOM}};
  s2_weighted_values_1 = _RAND_6[12:0];
  _RAND_7 = {1{`RANDOM}};
  s2_weighted_values_2 = _RAND_7[12:0];
  _RAND_8 = {1{`RANDOM}};
  s2_weighted_values_3 = _RAND_8[12:0];
  _RAND_9 = {1{`RANDOM}};
  s3_valid = _RAND_9[0:0];
  _RAND_10 = {1{`RANDOM}};
  s3_sum_weights_01 = _RAND_10[9:0];
  _RAND_11 = {1{`RANDOM}};
  s3_sum_weights_23 = _RAND_11[9:0];
  _RAND_12 = {1{`RANDOM}};
  s3_sum_weighted_values_01 = _RAND_12[13:0];
  _RAND_13 = {1{`RANDOM}};
  s3_sum_weighted_values_23 = _RAND_13[13:0];
  _RAND_14 = {1{`RANDOM}};
  out_valid_REG = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  out_sum_weights_REG = _RAND_15[10:0];
  _RAND_16 = {1{`RANDOM}};
  out_weighted_value_sum_REG = _RAND_16[14:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
