module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] in_valid;
reg [14:0] in_numerator;
reg [10:0] in_denominator;
wire [0:0] out_valid;
wire [3:0] out_result;
NormalizationUnit dut(.clock(clock),.reset(reset),.in_valid(in_valid),.in_numerator(in_numerator),.in_denominator(in_denominator),.out_valid(out_valid),.out_result(out_result));
initial begin
clock=0;
reset=1'd1;
in_valid=1'd0;
in_numerator=15'd0;
in_denominator=11'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=0 step=0 output=out_valid expected=0 actual=%0d",out_valid);
if (out_result !== 4'd0) $fatal(1,"module case=0 step=0 output=out_result expected=0 actual=%0d",out_result);
reset=1'd0;
in_valid=1'd1;
in_numerator=15'd1000;
in_denominator=11'd0;
#5;
repeat (6) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd1) $fatal(1,"module case=0 step=1 output=out_valid expected=1 actual=%0d",out_valid);
if (out_result !== 4'd0) $fatal(1,"module case=0 step=1 output=out_result expected=0 actual=%0d",out_result);
in_valid=1'd0;
#5;
repeat (6) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=0 step=2 output=out_valid expected=0 actual=%0d",out_valid);
$display("FAST_CASE cycles=1");
reset=1'd1;
in_valid=1'd0;
in_numerator=15'd0;
in_denominator=11'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=1 step=0 output=out_valid expected=0 actual=%0d",out_valid);
if (out_result !== 4'd0) $fatal(1,"module case=1 step=0 output=out_result expected=0 actual=%0d",out_result);
reset=1'd0;
in_valid=1'd1;
in_numerator=15'd1700;
in_denominator=11'd240;
#5;
repeat (6) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd1) $fatal(1,"module case=1 step=1 output=out_valid expected=1 actual=%0d",out_valid);
if (out_result !== 4'd7) $fatal(1,"module case=1 step=1 output=out_result expected=7 actual=%0d",out_result);
$display("FAST_CASE cycles=1");
reset=1'd1;
in_valid=1'd0;
in_numerator=15'd0;
in_denominator=11'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd0) $fatal(1,"module case=2 step=0 output=out_valid expected=0 actual=%0d",out_valid);
if (out_result !== 4'd0) $fatal(1,"module case=2 step=0 output=out_result expected=0 actual=%0d",out_result);
reset=1'd0;
in_valid=1'd1;
in_numerator=15'd27000;
in_denominator=11'd1800;
#5;
repeat (6) begin clock=1; #5; clock=0; #5; end
if (out_valid !== 1'd1) $fatal(1,"module case=2 step=1 output=out_valid expected=1 actual=%0d",out_valid);
if (out_result !== 4'd15) $fatal(1,"module case=2 step=1 output=out_result expected=15 actual=%0d",out_result);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=3");
$finish;
end
endmodule