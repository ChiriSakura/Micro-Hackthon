module AggregationUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 6:17]
  input         in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 7:20]
  input  [35:0] in_scores, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 8:21]
  input  [15:0] in_v, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 9:16]
  output        out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 10:21]
  output [10:0] out_sum_weights, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 11:27]
  output [14:0] out_weighted_value_sum // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 12:34]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
`endif // RANDOMIZE_REG_INIT
  wire [8:0] scores_s1_0 = in_scores[8:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 19:32]
  wire [3:0] vs_s1_0 = in_v[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 20:23]
  wire [8:0] scores_s1_1 = in_scores[17:9]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 19:32]
  wire [3:0] vs_s1_1 = in_v[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 20:23]
  wire [8:0] scores_s1_2 = in_scores[26:18]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 19:32]
  wire [3:0] vs_s1_2 = in_v[11:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 20:23]
  wire [8:0] scores_s1_3 = in_scores[35:27]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 19:32]
  wire [3:0] vs_s1_3 = in_v[15:12]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 20:23]
  wire [8:0] w = scores_s1_0 >= 9'h40 ? scores_s1_0 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
  wire [12:0] weighted_values_s1_0 = w * vs_s1_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 31:34]
  wire [8:0] w_1 = scores_s1_1 >= 9'h40 ? scores_s1_1 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
  wire [12:0] weighted_values_s1_1 = w_1 * vs_s1_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 31:34]
  wire [8:0] w_2 = scores_s1_2 >= 9'h40 ? scores_s1_2 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
  wire [12:0] weighted_values_s1_2 = w_2 * vs_s1_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 31:34]
  wire [8:0] w_3 = scores_s1_3 >= 9'h40 ? scores_s1_3 : 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
  wire [12:0] weighted_values_s1_3 = w_3 * vs_s1_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 31:34]
  reg  valid_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 35:27]
  reg [8:0] weights_s2_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 36:25]
  reg [8:0] weights_s2_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 36:25]
  reg [8:0] weights_s2_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 36:25]
  reg [8:0] weights_s2_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 36:25]
  reg [12:0] weighted_values_s2_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 37:33]
  reg [12:0] weighted_values_s2_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 37:33]
  reg [12:0] weighted_values_s2_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 37:33]
  reg [12:0] weighted_values_s2_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 37:33]
  wire [9:0] psum_w_01_s2 = weights_s2_0 + weights_s2_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 50:38]
  wire [9:0] psum_w_23_s2 = weights_s2_2 + weights_s2_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 51:38]
  wire [13:0] psum_wv_01_s2 = weighted_values_s2_0 + weighted_values_s2_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 52:47]
  wire [13:0] psum_wv_23_s2 = weighted_values_s2_2 + weighted_values_s2_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 53:47]
  reg  valid_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 56:27]
  reg [9:0] psum_w_01_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 57:27]
  reg [9:0] psum_w_23_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 58:27]
  reg [13:0] psum_wv_01_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 59:28]
  reg [13:0] psum_wv_23_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 60:28]
  wire [10:0] sum_w_s3 = psum_w_01_s3 + psum_w_23_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 76:33]
  wire [14:0] sum_wv_s3 = psum_wv_01_s3 + psum_wv_23_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 77:35]
  reg  out_valid_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 80:32]
  reg [10:0] out_sum_weights_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 81:34]
  reg [14:0] out_weighted_value_sum_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 82:41]
  assign out_valid = out_valid_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 94:15]
  assign out_sum_weights = out_sum_weights_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 95:21]
  assign out_weighted_value_sum = out_weighted_value_sum_reg; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 96:28]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 35:27]
      valid_s2 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 35:27]
    end else begin
      valid_s2 <= in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 39:14]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      if (scores_s1_0 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
        weights_s2_0 <= scores_s1_0;
      end else begin
        weights_s2_0 <= 9'h0;
      end
    end else begin
      weights_s2_0 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 45:18]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      if (scores_s1_1 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
        weights_s2_1 <= scores_s1_1;
      end else begin
        weights_s2_1 <= 9'h0;
      end
    end else begin
      weights_s2_1 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 45:18]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      if (scores_s1_2 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
        weights_s2_2 <= scores_s1_2;
      end else begin
        weights_s2_2 <= 9'h0;
      end
    end else begin
      weights_s2_2 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 45:18]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      if (scores_s1_3 >= 9'h40) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 29:18]
        weights_s2_3 <= scores_s1_3;
      end else begin
        weights_s2_3 <= 9'h0;
      end
    end else begin
      weights_s2_3 <= 9'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 45:18]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      weighted_values_s2_0 <= weighted_values_s1_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 42:26]
    end else begin
      weighted_values_s2_0 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 46:26]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      weighted_values_s2_1 <= weighted_values_s1_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 42:26]
    end else begin
      weighted_values_s2_1 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 46:26]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      weighted_values_s2_2 <= weighted_values_s1_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 42:26]
    end else begin
      weighted_values_s2_2 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 46:26]
    end
    if (in_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 40:20]
      weighted_values_s2_3 <= weighted_values_s1_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 42:26]
    end else begin
      weighted_values_s2_3 <= 13'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 46:26]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 56:27]
      valid_s3 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 56:27]
    end else begin
      valid_s3 <= valid_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 62:14]
    end
    if (valid_s2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 63:20]
      psum_w_01_s3 <= psum_w_01_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 64:20]
    end else begin
      psum_w_01_s3 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 69:20]
    end
    if (valid_s2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 63:20]
      psum_w_23_s3 <= psum_w_23_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 65:20]
    end else begin
      psum_w_23_s3 <= 10'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 70:20]
    end
    if (valid_s2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 63:20]
      psum_wv_01_s3 <= psum_wv_01_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 66:21]
    end else begin
      psum_wv_01_s3 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 71:21]
    end
    if (valid_s2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 63:20]
      psum_wv_23_s3 <= psum_wv_23_s2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 67:21]
    end else begin
      psum_wv_23_s3 <= 14'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 72:21]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 80:32]
      out_valid_reg <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 80:32]
    end else begin
      out_valid_reg <= valid_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 84:19]
    end
    if (valid_s3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 85:20]
      out_sum_weights_reg <= sum_w_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 86:27]
    end else begin
      out_sum_weights_reg <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 89:27]
    end
    if (valid_s3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 85:20]
      out_weighted_value_sum_reg <= sum_wv_s3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 87:34]
    end else begin
      out_weighted_value_sum_reg <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/AggregationUnit/AggregationUnit.scala 90:34]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  valid_s2 = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  weights_s2_0 = _RAND_1[8:0];
  _RAND_2 = {1{`RANDOM}};
  weights_s2_1 = _RAND_2[8:0];
  _RAND_3 = {1{`RANDOM}};
  weights_s2_2 = _RAND_3[8:0];
  _RAND_4 = {1{`RANDOM}};
  weights_s2_3 = _RAND_4[8:0];
  _RAND_5 = {1{`RANDOM}};
  weighted_values_s2_0 = _RAND_5[12:0];
  _RAND_6 = {1{`RANDOM}};
  weighted_values_s2_1 = _RAND_6[12:0];
  _RAND_7 = {1{`RANDOM}};
  weighted_values_s2_2 = _RAND_7[12:0];
  _RAND_8 = {1{`RANDOM}};
  weighted_values_s2_3 = _RAND_8[12:0];
  _RAND_9 = {1{`RANDOM}};
  valid_s3 = _RAND_9[0:0];
  _RAND_10 = {1{`RANDOM}};
  psum_w_01_s3 = _RAND_10[9:0];
  _RAND_11 = {1{`RANDOM}};
  psum_w_23_s3 = _RAND_11[9:0];
  _RAND_12 = {1{`RANDOM}};
  psum_wv_01_s3 = _RAND_12[13:0];
  _RAND_13 = {1{`RANDOM}};
  psum_wv_23_s3 = _RAND_13[13:0];
  _RAND_14 = {1{`RANDOM}};
  out_valid_reg = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  out_sum_weights_reg = _RAND_15[10:0];
  _RAND_16 = {1{`RANDOM}};
  out_weighted_value_sum_reg = _RAND_16[14:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
