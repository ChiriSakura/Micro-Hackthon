import chisel3._
import chisel3.util._

class AggregationUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val in_valid = IO(Input(Bool()))
  val in_scores = IO(Input(UInt(36.W)))
  val in_v = IO(Input(UInt(16.W)))
  val out_valid = IO(Output(Bool()))
  val out_sum_weights = IO(Output(UInt(11.W)))
  val out_weighted_value_sum = IO(Output(UInt(15.W)))

  // --- Stage 1: Combinational Logic ---
  // Unpack inputs and perform thresholding and multiplication.
  val scores_s1 = Wire(Vec(4, UInt(9.W)))
  val vs_s1 = Wire(Vec(4, UInt(4.W)))
  for (i <- 0 until 4) {
    scores_s1(i) := in_scores(i * 9 + 8, i * 9)
    vs_s1(i) := in_v(i * 4 + 3, i * 4)
  }

  val threshold = 64.U(9.W)
  val weights_s1 = Wire(Vec(4, UInt(9.W)))
  val weighted_values_s1 = Wire(Vec(4, UInt(13.W)))

  for (i <- 0 until 4) {
    val score = scores_s1(i)
    val w = Mux(score >= threshold, score, 0.U(9.W))
    weights_s1(i) := w
    // Use widening multiplication to prevent internal truncation before assignment.
    weighted_values_s1(i) := (w.zext() * vs_s1(i).zext()).asUInt
  }

  withClockAndReset(clock, reset) {
    // --- Pipeline Stage 1 -> 2 Registers ---
    // This stage has a latency of 1 cycle.
    val valid_s2 = RegNext(in_valid, false.B)
    val weights_s2 = RegInit(VecInit(Seq.fill(4)(0.U(9.W))))
    val weighted_values_s2 = RegInit(VecInit(Seq.fill(4)(0.U(13.W))))

    when(in_valid) {
      weights_s2 := weights_s1
      weighted_values_s2 := weighted_values_s1
    }

    // --- Stage 2: Combinational Logic & Stage 2 -> 3 Registers ---
    // This stage has a latency of 1 cycle.
    val psum_w_01_s2 = weights_s2(0) +& weights_s2(1)
    val psum_w_23_s2 = weights_s2(2) +& weights_s2(3)
    val psum_wv_01_s2 = weighted_values_s2(0) +& weighted_values_s2(1)
    val psum_wv_23_s2 = weighted_values_s2(2) +& weighted_values_s2(3)

    val valid_s3 = RegNext(valid_s2, false.B)
    val psum_w_01_s3 = RegInit(0.U(10.W))
    val psum_w_23_s3 = RegInit(0.U(10.W))
    val psum_wv_01_s3 = RegInit(0.U(14.W))
    val psum_wv_23_s3 = RegInit(0.U(14.W))

    when(valid_s2) {
      psum_w_01_s3 := psum_w_01_s2
      psum_w_23_s3 := psum_w_23_s2
      psum_wv_01_s3 := psum_wv_01_s2
      psum_wv_23_s3 := psum_wv_23_s2
    }

    // --- Stage 3: Combinational Logic & Stage 3 -> Output Registers ---
    // This stage has a latency of 1 cycle, for a total of 3.
    val sum_w_s3 = psum_w_01_s3 +& psum_w_23_s3
    val sum_wv_s3 = psum_wv_01_s3 +& psum_wv_23_s3

    val out_valid_reg = RegNext(valid_s3, false.B)
    val out_sum_weights_reg = RegInit(0.U(11.W))
    val out_weighted_value_sum_reg = RegInit(0.U(15.W))

    when(valid_s3) {
      out_sum_weights_reg := sum_w_s3
      out_weighted_value_sum_reg := sum_wv_s3
    }
    
    // Connect to module outputs
    out_valid := out_valid_reg
    out_sum_weights := out_sum_weights_reg
    out_weighted_value_sum := out_weighted_value_sum_reg
  }
}
