import chisel3._
import chisel3.util._

class NormalizationUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val in_valid = IO(Input(Bool()))
  val in_numerator = IO(Input(UInt(15.W)))
  val in_denominator = IO(Input(UInt(11.W)))
  val out_valid = IO(Output(Bool()))
  val out_result = IO(Output(UInt(4.W)))

  // Internal bundle to carry state through the division pipeline.
  class DivState extends Bundle {
    val remainder    = UInt(16.W) // Remainder can grow to 16 bits during trial subtraction
    val quotient     = UInt(15.W)
    val dividend     = UInt(15.W)
    val divisor      = UInt(15.W)
    val divideByZero = Bool()
    val valid        = Bool()
  }

  // Helper function for one step of radix-2 restoring division.
  def step(state_in: DivState): DivState = {
    val state_out = Wire(new DivState)
    state_out := state_in // Default assignment

    // Shift remainder and bring in the most significant bit of the dividend.
    val shifted = Cat(state_in.remainder(14, 0), state_in.dividend(14))
    val fits = shifted >= state_in.divisor
    val diff = shifted - state_in.divisor

    state_out.remainder := Mux(fits, diff, shifted)
    state_out.quotient  := Cat(state_in.quotient(13, 0), fits)
    state_out.dividend  := state_in.dividend << 1

    state_out
  }

  // Helper to perform 3 division steps combinationally.
  def do_3_steps(state_in: DivState): DivState = {
    val s1 = step(state_in)
    val s2 = step(s1)
    val s3 = step(s2)
    s3
  }

  // Total latency is 6 cycles: 1 for input register + 5 for divider core.

  // Stage 1: Input registration. Latency cycle 1.
  val s1_in_valid = withClockAndReset(clock, reset) { RegNext(in_valid, false.B) }
  val s1_numerator = withClockAndReset(clock, reset) { RegNext(in_numerator, 0.U) }
  val s1_denominator = withClockAndReset(clock, reset) { RegNext(in_denominator, 0.U) }

  // Stage 2: Initialize division state. Combinational logic before the first pipeline register.
  val s2_in_state = Wire(new DivState)
  s2_in_state.remainder    := 0.U
  s2_in_state.quotient     := 0.U
  s2_in_state.dividend     := s1_numerator
  s2_in_state.divisor      := Cat(0.U(4.W), s1_denominator)
  s2_in_state.divideByZero := (s1_denominator === 0.U)
  s2_in_state.valid        := s1_in_valid

  val s2_out_state = do_3_steps(s2_in_state)
  val s3_in_state = withClockAndReset(clock, reset) { RegNext(s2_out_state, 0.U.asTypeOf(new DivState)) } // Latency cycle 2

  // Stages 3-6: 5-stage pipelined divider core.
  val s3_out_state = do_3_steps(s3_in_state)
  val s4_in_state = withClockAndReset(clock, reset) { RegNext(s3_out_state, 0.U.asTypeOf(new DivState)) } // Latency cycle 3

  val s4_out_state = do_3_steps(s4_in_state)
  val s5_in_state = withClockAndReset(clock, reset) { RegNext(s4_out_state, 0.U.asTypeOf(new DivState)) } // Latency cycle 4

  val s5_out_state = do_3_steps(s5_in_state)
  val s6_in_state = withClockAndReset(clock, reset) { RegNext(s5_out_state, 0.U.asTypeOf(new DivState)) } // Latency cycle 5

  val s6_out_state = do_3_steps(s6_in_state)
  val final_state = withClockAndReset(clock, reset) { RegNext(s6_out_state, 0.U.asTypeOf(new DivState)) } // Latency cycle 6

  // Output logic
  out_valid := final_state.valid
  out_result := Mux(final_state.divideByZero, 0.U, final_state.quotient(3, 0))
}
