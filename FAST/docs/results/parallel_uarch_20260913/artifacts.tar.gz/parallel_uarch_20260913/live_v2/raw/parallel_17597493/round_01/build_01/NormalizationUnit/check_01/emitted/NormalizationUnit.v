module NormalizationUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 6:17]
  input         in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 7:20]
  input  [14:0] in_numerator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 8:24]
  input  [10:0] in_denominator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 9:26]
  output        out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 10:21]
  output [3:0]  out_result // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 11:22]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
`endif // RANDOMIZE_REG_INIT
  reg [14:0] stage1_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 19:67]
  reg [10:0] stage1_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:69]
  wire [14:0] initial_state_divisor = {4'h0,stage1_denominator}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 61:31]
  wire  initial_state_divideByZero = stage1_denominator == 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 62:53]
  wire [15:0] shifted_rem = {15'h0,stage1_numerator[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [15:0] _GEN_6 = {{1'd0}, initial_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire [16:0] trial = shifted_rem - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits = shifted_rem >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_remainder = fits ? trial[15:0] : shifted_rem; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_quotient = {14'h0,fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_dividend = {stage1_numerator[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_1 = {next_remainder[14:0],next_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_1 = shifted_rem_1 - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_1 = shifted_rem_1 >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_1_remainder = fits_1 ? trial_1[15:0] : shifted_rem_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_1_quotient = {next_quotient[13:0],fits_1}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_1_dividend = {next_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_2 = {next_1_remainder[14:0],next_1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_2 = shifted_rem_2 - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_2 = shifted_rem_2 >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [14:0] next_2_quotient = {next_1_quotient[13:0],fits_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_2_dividend = {next_1_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  reg [15:0] REG_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg  REG_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  wire [15:0] shifted_rem_3 = {REG_remainder[14:0],REG_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [15:0] _GEN_12 = {{1'd0}, REG_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire [16:0] trial_3 = shifted_rem_3 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_3 = shifted_rem_3 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_3_remainder = fits_3 ? trial_3[15:0] : shifted_rem_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_3_quotient = {REG_quotient[13:0],fits_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_3_dividend = {REG_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_4 = {next_3_remainder[14:0],next_3_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_4 = shifted_rem_4 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_4 = shifted_rem_4 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_4_remainder = fits_4 ? trial_4[15:0] : shifted_rem_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_4_quotient = {next_3_quotient[13:0],fits_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_4_dividend = {next_3_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_5 = {next_4_remainder[14:0],next_4_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_5 = shifted_rem_5 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_5 = shifted_rem_5 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [14:0] next_5_quotient = {next_4_quotient[13:0],fits_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_5_dividend = {next_4_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  reg [15:0] REG_1_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg  REG_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  wire [15:0] shifted_rem_6 = {REG_1_remainder[14:0],REG_1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [15:0] _GEN_18 = {{1'd0}, REG_1_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire [16:0] trial_6 = shifted_rem_6 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_6 = shifted_rem_6 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_6_remainder = fits_6 ? trial_6[15:0] : shifted_rem_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_6_quotient = {REG_1_quotient[13:0],fits_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_6_dividend = {REG_1_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_7 = {next_6_remainder[14:0],next_6_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_7 = shifted_rem_7 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_7 = shifted_rem_7 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_7_remainder = fits_7 ? trial_7[15:0] : shifted_rem_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_7_quotient = {next_6_quotient[13:0],fits_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_7_dividend = {next_6_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_8 = {next_7_remainder[14:0],next_7_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_8 = shifted_rem_8 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_8 = shifted_rem_8 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [14:0] next_8_quotient = {next_7_quotient[13:0],fits_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_8_dividend = {next_7_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  reg [15:0] REG_2_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg  REG_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  wire [15:0] shifted_rem_9 = {REG_2_remainder[14:0],REG_2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [15:0] _GEN_24 = {{1'd0}, REG_2_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire [16:0] trial_9 = shifted_rem_9 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_9 = shifted_rem_9 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_9_remainder = fits_9 ? trial_9[15:0] : shifted_rem_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_9_quotient = {REG_2_quotient[13:0],fits_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_9_dividend = {REG_2_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_10 = {next_9_remainder[14:0],next_9_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_10 = shifted_rem_10 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_10 = shifted_rem_10 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_10_remainder = fits_10 ? trial_10[15:0] : shifted_rem_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_10_quotient = {next_9_quotient[13:0],fits_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_10_dividend = {next_9_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_11 = {next_10_remainder[14:0],next_10_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_11 = shifted_rem_11 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_11 = shifted_rem_11 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [14:0] next_11_quotient = {next_10_quotient[13:0],fits_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_11_dividend = {next_10_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  reg [15:0] REG_3_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg [14:0] REG_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg  REG_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  wire [15:0] shifted_rem_12 = {REG_3_remainder[14:0],REG_3_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [15:0] _GEN_30 = {{1'd0}, REG_3_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire [16:0] trial_12 = shifted_rem_12 - _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_12 = shifted_rem_12 >= _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_12_remainder = fits_12 ? trial_12[15:0] : shifted_rem_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_12_quotient = {REG_3_quotient[13:0],fits_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_12_dividend = {REG_3_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_13 = {next_12_remainder[14:0],next_12_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire [16:0] trial_13 = shifted_rem_13 - _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 42:36]
  wire  fits_13 = shifted_rem_13 >= _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [15:0] next_13_remainder = fits_13 ? trial_13[15:0] : shifted_rem_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
  wire [14:0] next_13_quotient = {next_12_quotient[13:0],fits_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  wire [14:0] next_13_dividend = {next_12_dividend[13:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 51:25]
  wire [15:0] shifted_rem_14 = {next_13_remainder[14:0],next_13_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 39:26]
  wire  fits_14 = shifted_rem_14 >= _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 43:28]
  wire [14:0] next_14_quotient = {next_13_quotient[13:0],fits_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 49:25]
  reg [14:0] REG_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  reg  REG_4_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
  wire [14:0] result_with_dbz = REG_4_divideByZero ? 15'h0 : REG_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 86:28]
  reg  out_valid_r; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
  reg  out_valid_r_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
  reg  out_valid_r_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
  reg  out_valid_r_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
  reg  out_valid_r_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
  reg  out_valid_r_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
  assign out_valid = out_valid_r_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:13]
  assign out_result = result_with_dbz[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 89:32]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 19:67]
      stage1_numerator <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 19:67]
    end else begin
      stage1_numerator <= in_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 19:67]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:69]
      stage1_denominator <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:69]
    end else begin
      stage1_denominator <= in_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 20:69]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else if (fits_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
      REG_remainder <= trial_2[15:0];
    end else begin
      REG_remainder <= shifted_rem_2;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_quotient <= next_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_dividend <= next_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_divisor <= initial_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_divideByZero <= initial_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_1_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else if (fits_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
      REG_1_remainder <= trial_5[15:0];
    end else begin
      REG_1_remainder <= shifted_rem_5;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_1_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_1_quotient <= next_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_1_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_1_dividend <= next_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_1_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_1_divisor <= REG_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_1_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_1_divideByZero <= REG_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_2_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else if (fits_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
      REG_2_remainder <= trial_8[15:0];
    end else begin
      REG_2_remainder <= shifted_rem_8;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_2_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_2_quotient <= next_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_2_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_2_dividend <= next_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_2_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_2_divisor <= REG_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_2_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_2_divideByZero <= REG_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_3_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else if (fits_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 47:26]
      REG_3_remainder <= trial_11[15:0];
    end else begin
      REG_3_remainder <= shifted_rem_11;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_3_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_3_quotient <= next_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_3_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_3_dividend <= next_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_3_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_3_divisor <= REG_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_3_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_3_divideByZero <= REG_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_4_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_4_quotient <= next_14_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
      REG_4_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end else begin
      REG_4_divideByZero <= REG_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 77:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
      out_valid_r <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
    end else begin
      out_valid_r <= in_valid;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
      out_valid_r_1 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
    end else begin
      out_valid_r_1 <= out_valid_r;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
      out_valid_r_2 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
    end else begin
      out_valid_r_2 <= out_valid_r_1;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
      out_valid_r_3 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
    end else begin
      out_valid_r_3 <= out_valid_r_2;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
      out_valid_r_4 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
    end else begin
      out_valid_r_4 <= out_valid_r_3;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
      out_valid_r_5 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/NormalizationUnit/NormalizationUnit.scala 92:63]
    end else begin
      out_valid_r_5 <= out_valid_r_4;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  stage1_numerator = _RAND_0[14:0];
  _RAND_1 = {1{`RANDOM}};
  stage1_denominator = _RAND_1[10:0];
  _RAND_2 = {1{`RANDOM}};
  REG_remainder = _RAND_2[15:0];
  _RAND_3 = {1{`RANDOM}};
  REG_quotient = _RAND_3[14:0];
  _RAND_4 = {1{`RANDOM}};
  REG_dividend = _RAND_4[14:0];
  _RAND_5 = {1{`RANDOM}};
  REG_divisor = _RAND_5[14:0];
  _RAND_6 = {1{`RANDOM}};
  REG_divideByZero = _RAND_6[0:0];
  _RAND_7 = {1{`RANDOM}};
  REG_1_remainder = _RAND_7[15:0];
  _RAND_8 = {1{`RANDOM}};
  REG_1_quotient = _RAND_8[14:0];
  _RAND_9 = {1{`RANDOM}};
  REG_1_dividend = _RAND_9[14:0];
  _RAND_10 = {1{`RANDOM}};
  REG_1_divisor = _RAND_10[14:0];
  _RAND_11 = {1{`RANDOM}};
  REG_1_divideByZero = _RAND_11[0:0];
  _RAND_12 = {1{`RANDOM}};
  REG_2_remainder = _RAND_12[15:0];
  _RAND_13 = {1{`RANDOM}};
  REG_2_quotient = _RAND_13[14:0];
  _RAND_14 = {1{`RANDOM}};
  REG_2_dividend = _RAND_14[14:0];
  _RAND_15 = {1{`RANDOM}};
  REG_2_divisor = _RAND_15[14:0];
  _RAND_16 = {1{`RANDOM}};
  REG_2_divideByZero = _RAND_16[0:0];
  _RAND_17 = {1{`RANDOM}};
  REG_3_remainder = _RAND_17[15:0];
  _RAND_18 = {1{`RANDOM}};
  REG_3_quotient = _RAND_18[14:0];
  _RAND_19 = {1{`RANDOM}};
  REG_3_dividend = _RAND_19[14:0];
  _RAND_20 = {1{`RANDOM}};
  REG_3_divisor = _RAND_20[14:0];
  _RAND_21 = {1{`RANDOM}};
  REG_3_divideByZero = _RAND_21[0:0];
  _RAND_22 = {1{`RANDOM}};
  REG_4_quotient = _RAND_22[14:0];
  _RAND_23 = {1{`RANDOM}};
  REG_4_divideByZero = _RAND_23[0:0];
  _RAND_24 = {1{`RANDOM}};
  out_valid_r = _RAND_24[0:0];
  _RAND_25 = {1{`RANDOM}};
  out_valid_r_1 = _RAND_25[0:0];
  _RAND_26 = {1{`RANDOM}};
  out_valid_r_2 = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  out_valid_r_3 = _RAND_27[0:0];
  _RAND_28 = {1{`RANDOM}};
  out_valid_r_4 = _RAND_28[0:0];
  _RAND_29 = {1{`RANDOM}};
  out_valid_r_5 = _RAND_29[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
