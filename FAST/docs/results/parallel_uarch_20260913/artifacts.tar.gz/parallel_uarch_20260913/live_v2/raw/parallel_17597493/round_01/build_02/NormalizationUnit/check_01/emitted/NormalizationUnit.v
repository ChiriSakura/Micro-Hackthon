module NormalizationUnit(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 5:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 6:17]
  input         in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 7:20]
  input  [14:0] in_numerator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 8:24]
  input  [10:0] in_denominator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 9:26]
  output        out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 10:21]
  output [3:0]  out_result // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 11:22]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
`endif // RANDOMIZE_REG_INIT
  reg  s1_in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 51:62]
  reg [14:0] s1_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 52:63]
  reg [10:0] s1_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 53:65]
  wire [14:0] s2_in_state_divisor = {4'h0,s1_denominator}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 60:34]
  wire  s2_in_state_divideByZero = s1_denominator == 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 61:47]
  wire [15:0] s2_out_state_s1_shifted = {15'h0,s1_numerator[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire [15:0] _GEN_0 = {{1'd0}, s2_in_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire  s2_out_state_s1_fits = s2_out_state_s1_shifted >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s2_out_state_s1_diff = s2_out_state_s1_shifted - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s2_out_state_s1_remainder = s2_out_state_s1_fits ? s2_out_state_s1_diff : s2_out_state_s1_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s2_out_state_s1_quotient = {14'h0,s2_out_state_s1_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s2_out_state_s1_state_out_dividend_T = {s1_numerator, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s2_out_state_s1_dividend = _s2_out_state_s1_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s2_out_state_s2_shifted = {s2_out_state_s1_remainder[14:0],s2_out_state_s1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s2_out_state_s2_fits = s2_out_state_s2_shifted >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s2_out_state_s2_diff = s2_out_state_s2_shifted - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s2_out_state_s2_remainder = s2_out_state_s2_fits ? s2_out_state_s2_diff : s2_out_state_s2_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s2_out_state_s2_quotient = {s2_out_state_s1_quotient[13:0],s2_out_state_s2_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s2_out_state_s2_state_out_dividend_T = {s2_out_state_s1_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s2_out_state_s2_dividend = _s2_out_state_s2_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s2_out_state_s3_shifted = {s2_out_state_s2_remainder[14:0],s2_out_state_s2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s2_out_state_s3_fits = s2_out_state_s3_shifted >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s2_out_state_s3_diff = s2_out_state_s3_shifted - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [14:0] s2_out_state_quotient = {s2_out_state_s2_quotient[13:0],s2_out_state_s3_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s2_out_state_s3_state_out_dividend_T = {s2_out_state_s2_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  reg [15:0] s3_in_state_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
  reg [14:0] s3_in_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
  reg [14:0] s3_in_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
  reg [14:0] s3_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
  reg  s3_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
  reg  s3_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
  wire [15:0] s3_out_state_s1_shifted = {s3_in_state_remainder[14:0],s3_in_state_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire [15:0] _GEN_6 = {{1'd0}, s3_in_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire  s3_out_state_s1_fits = s3_out_state_s1_shifted >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s3_out_state_s1_diff = s3_out_state_s1_shifted - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s3_out_state_s1_remainder = s3_out_state_s1_fits ? s3_out_state_s1_diff : s3_out_state_s1_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s3_out_state_s1_quotient = {s3_in_state_quotient[13:0],s3_out_state_s1_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s3_out_state_s1_state_out_dividend_T = {s3_in_state_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s3_out_state_s1_dividend = _s3_out_state_s1_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s3_out_state_s2_shifted = {s3_out_state_s1_remainder[14:0],s3_out_state_s1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s3_out_state_s2_fits = s3_out_state_s2_shifted >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s3_out_state_s2_diff = s3_out_state_s2_shifted - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s3_out_state_s2_remainder = s3_out_state_s2_fits ? s3_out_state_s2_diff : s3_out_state_s2_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s3_out_state_s2_quotient = {s3_out_state_s1_quotient[13:0],s3_out_state_s2_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s3_out_state_s2_state_out_dividend_T = {s3_out_state_s1_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s3_out_state_s2_dividend = _s3_out_state_s2_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s3_out_state_s3_shifted = {s3_out_state_s2_remainder[14:0],s3_out_state_s2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s3_out_state_s3_fits = s3_out_state_s3_shifted >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s3_out_state_s3_diff = s3_out_state_s3_shifted - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [14:0] s3_out_state_quotient = {s3_out_state_s2_quotient[13:0],s3_out_state_s3_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s3_out_state_s3_state_out_dividend_T = {s3_out_state_s2_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  reg [15:0] s4_in_state_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
  reg [14:0] s4_in_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
  reg [14:0] s4_in_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
  reg [14:0] s4_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
  reg  s4_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
  reg  s4_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
  wire [15:0] s4_out_state_s1_shifted = {s4_in_state_remainder[14:0],s4_in_state_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire [15:0] _GEN_12 = {{1'd0}, s4_in_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire  s4_out_state_s1_fits = s4_out_state_s1_shifted >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s4_out_state_s1_diff = s4_out_state_s1_shifted - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s4_out_state_s1_remainder = s4_out_state_s1_fits ? s4_out_state_s1_diff : s4_out_state_s1_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s4_out_state_s1_quotient = {s4_in_state_quotient[13:0],s4_out_state_s1_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s4_out_state_s1_state_out_dividend_T = {s4_in_state_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s4_out_state_s1_dividend = _s4_out_state_s1_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s4_out_state_s2_shifted = {s4_out_state_s1_remainder[14:0],s4_out_state_s1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s4_out_state_s2_fits = s4_out_state_s2_shifted >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s4_out_state_s2_diff = s4_out_state_s2_shifted - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s4_out_state_s2_remainder = s4_out_state_s2_fits ? s4_out_state_s2_diff : s4_out_state_s2_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s4_out_state_s2_quotient = {s4_out_state_s1_quotient[13:0],s4_out_state_s2_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s4_out_state_s2_state_out_dividend_T = {s4_out_state_s1_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s4_out_state_s2_dividend = _s4_out_state_s2_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s4_out_state_s3_shifted = {s4_out_state_s2_remainder[14:0],s4_out_state_s2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s4_out_state_s3_fits = s4_out_state_s3_shifted >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s4_out_state_s3_diff = s4_out_state_s3_shifted - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [14:0] s4_out_state_quotient = {s4_out_state_s2_quotient[13:0],s4_out_state_s3_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s4_out_state_s3_state_out_dividend_T = {s4_out_state_s2_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  reg [15:0] s5_in_state_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
  reg [14:0] s5_in_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
  reg [14:0] s5_in_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
  reg [14:0] s5_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
  reg  s5_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
  reg  s5_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
  wire [15:0] s5_out_state_s1_shifted = {s5_in_state_remainder[14:0],s5_in_state_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire [15:0] _GEN_18 = {{1'd0}, s5_in_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire  s5_out_state_s1_fits = s5_out_state_s1_shifted >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s5_out_state_s1_diff = s5_out_state_s1_shifted - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s5_out_state_s1_remainder = s5_out_state_s1_fits ? s5_out_state_s1_diff : s5_out_state_s1_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s5_out_state_s1_quotient = {s5_in_state_quotient[13:0],s5_out_state_s1_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s5_out_state_s1_state_out_dividend_T = {s5_in_state_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s5_out_state_s1_dividend = _s5_out_state_s1_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s5_out_state_s2_shifted = {s5_out_state_s1_remainder[14:0],s5_out_state_s1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s5_out_state_s2_fits = s5_out_state_s2_shifted >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s5_out_state_s2_diff = s5_out_state_s2_shifted - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s5_out_state_s2_remainder = s5_out_state_s2_fits ? s5_out_state_s2_diff : s5_out_state_s2_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s5_out_state_s2_quotient = {s5_out_state_s1_quotient[13:0],s5_out_state_s2_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s5_out_state_s2_state_out_dividend_T = {s5_out_state_s1_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s5_out_state_s2_dividend = _s5_out_state_s2_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s5_out_state_s3_shifted = {s5_out_state_s2_remainder[14:0],s5_out_state_s2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s5_out_state_s3_fits = s5_out_state_s3_shifted >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s5_out_state_s3_diff = s5_out_state_s3_shifted - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [14:0] s5_out_state_quotient = {s5_out_state_s2_quotient[13:0],s5_out_state_s3_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s5_out_state_s3_state_out_dividend_T = {s5_out_state_s2_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  reg [15:0] s6_in_state_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
  reg [14:0] s6_in_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
  reg [14:0] s6_in_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
  reg [14:0] s6_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
  reg  s6_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
  reg  s6_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
  wire [15:0] s6_out_state_s1_shifted = {s6_in_state_remainder[14:0],s6_in_state_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire [15:0] _GEN_24 = {{1'd0}, s6_in_state_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire  s6_out_state_s1_fits = s6_out_state_s1_shifted >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s6_out_state_s1_diff = s6_out_state_s1_shifted - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s6_out_state_s1_remainder = s6_out_state_s1_fits ? s6_out_state_s1_diff : s6_out_state_s1_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s6_out_state_s1_quotient = {s6_in_state_quotient[13:0],s6_out_state_s1_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s6_out_state_s1_state_out_dividend_T = {s6_in_state_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s6_out_state_s1_dividend = _s6_out_state_s1_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s6_out_state_s2_shifted = {s6_out_state_s1_remainder[14:0],s6_out_state_s1_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s6_out_state_s2_fits = s6_out_state_s2_shifted >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [15:0] s6_out_state_s2_diff = s6_out_state_s2_shifted - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 31:24]
  wire [15:0] s6_out_state_s2_remainder = s6_out_state_s2_fits ? s6_out_state_s2_diff : s6_out_state_s2_shifted; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
  wire [14:0] s6_out_state_s2_quotient = {s6_out_state_s1_quotient[13:0],s6_out_state_s2_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  wire [15:0] _s6_out_state_s2_state_out_dividend_T = {s6_out_state_s1_dividend, 1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 35:46]
  wire [14:0] s6_out_state_s2_dividend = _s6_out_state_s2_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [15:0] s6_out_state_s3_shifted = {s6_out_state_s2_remainder[14:0],s6_out_state_s2_dividend[14]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 29:22]
  wire  s6_out_state_s3_fits = s6_out_state_s3_shifted >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 30:24]
  wire [14:0] s6_out_state_quotient = {s6_out_state_s2_quotient[13:0],s6_out_state_s3_fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 34:31]
  reg [14:0] final_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
  reg  final_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
  reg  final_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
  wire [14:0] s2_out_state_dividend = _s2_out_state_s3_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [14:0] s3_out_state_dividend = _s3_out_state_s3_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [14:0] s4_out_state_dividend = _s4_out_state_s3_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  wire [14:0] s5_out_state_dividend = _s5_out_state_s3_state_out_dividend_T[14:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 25:25 35:25]
  assign out_valid = final_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 81:13]
  assign out_result = final_state_divideByZero ? 4'h0 : final_state_quotient[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 82:20]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 51:62]
      s1_in_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 51:62]
    end else begin
      s1_in_valid <= in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 51:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 52:63]
      s1_numerator <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 52:63]
    end else begin
      s1_numerator <= in_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 52:63]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 53:65]
      s1_denominator <= 11'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 53:65]
    end else begin
      s1_denominator <= in_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 53:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
      s3_in_state_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end else if (s2_out_state_s3_fits) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
      s3_in_state_remainder <= s2_out_state_s3_diff;
    end else begin
      s3_in_state_remainder <= s2_out_state_s3_shifted;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
      s3_in_state_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end else begin
      s3_in_state_quotient <= s2_out_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
      s3_in_state_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end else begin
      s3_in_state_dividend <= s2_out_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
      s3_in_state_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end else begin
      s3_in_state_divisor <= s2_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
      s3_in_state_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end else begin
      s3_in_state_divideByZero <= s2_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
      s3_in_state_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end else begin
      s3_in_state_valid <= s1_in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 65:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
      s4_in_state_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end else if (s3_out_state_s3_fits) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
      s4_in_state_remainder <= s3_out_state_s3_diff;
    end else begin
      s4_in_state_remainder <= s3_out_state_s3_shifted;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
      s4_in_state_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end else begin
      s4_in_state_quotient <= s3_out_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
      s4_in_state_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end else begin
      s4_in_state_dividend <= s3_out_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
      s4_in_state_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end else begin
      s4_in_state_divisor <= s3_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
      s4_in_state_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end else begin
      s4_in_state_divideByZero <= s3_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
      s4_in_state_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end else begin
      s4_in_state_valid <= s3_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 69:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
      s5_in_state_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end else if (s4_out_state_s3_fits) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
      s5_in_state_remainder <= s4_out_state_s3_diff;
    end else begin
      s5_in_state_remainder <= s4_out_state_s3_shifted;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
      s5_in_state_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end else begin
      s5_in_state_quotient <= s4_out_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
      s5_in_state_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end else begin
      s5_in_state_dividend <= s4_out_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
      s5_in_state_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end else begin
      s5_in_state_divisor <= s4_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
      s5_in_state_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end else begin
      s5_in_state_divideByZero <= s4_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
      s5_in_state_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end else begin
      s5_in_state_valid <= s4_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 72:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
      s6_in_state_remainder <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end else if (s5_out_state_s3_fits) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 33:31]
      s6_in_state_remainder <= s5_out_state_s3_diff;
    end else begin
      s6_in_state_remainder <= s5_out_state_s3_shifted;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
      s6_in_state_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end else begin
      s6_in_state_quotient <= s5_out_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
      s6_in_state_dividend <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end else begin
      s6_in_state_dividend <= s5_out_state_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
      s6_in_state_divisor <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end else begin
      s6_in_state_divisor <= s5_in_state_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
      s6_in_state_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end else begin
      s6_in_state_divideByZero <= s5_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
      s6_in_state_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end else begin
      s6_in_state_valid <= s5_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 75:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
      final_state_quotient <= 15'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
    end else begin
      final_state_quotient <= s6_out_state_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
      final_state_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
    end else begin
      final_state_divideByZero <= s6_in_state_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
      final_state_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
    end else begin
      final_state_valid <= s6_in_state_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_02/NormalizationUnit/NormalizationUnit.scala 78:62]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  s1_in_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  s1_numerator = _RAND_1[14:0];
  _RAND_2 = {1{`RANDOM}};
  s1_denominator = _RAND_2[10:0];
  _RAND_3 = {1{`RANDOM}};
  s3_in_state_remainder = _RAND_3[15:0];
  _RAND_4 = {1{`RANDOM}};
  s3_in_state_quotient = _RAND_4[14:0];
  _RAND_5 = {1{`RANDOM}};
  s3_in_state_dividend = _RAND_5[14:0];
  _RAND_6 = {1{`RANDOM}};
  s3_in_state_divisor = _RAND_6[14:0];
  _RAND_7 = {1{`RANDOM}};
  s3_in_state_divideByZero = _RAND_7[0:0];
  _RAND_8 = {1{`RANDOM}};
  s3_in_state_valid = _RAND_8[0:0];
  _RAND_9 = {1{`RANDOM}};
  s4_in_state_remainder = _RAND_9[15:0];
  _RAND_10 = {1{`RANDOM}};
  s4_in_state_quotient = _RAND_10[14:0];
  _RAND_11 = {1{`RANDOM}};
  s4_in_state_dividend = _RAND_11[14:0];
  _RAND_12 = {1{`RANDOM}};
  s4_in_state_divisor = _RAND_12[14:0];
  _RAND_13 = {1{`RANDOM}};
  s4_in_state_divideByZero = _RAND_13[0:0];
  _RAND_14 = {1{`RANDOM}};
  s4_in_state_valid = _RAND_14[0:0];
  _RAND_15 = {1{`RANDOM}};
  s5_in_state_remainder = _RAND_15[15:0];
  _RAND_16 = {1{`RANDOM}};
  s5_in_state_quotient = _RAND_16[14:0];
  _RAND_17 = {1{`RANDOM}};
  s5_in_state_dividend = _RAND_17[14:0];
  _RAND_18 = {1{`RANDOM}};
  s5_in_state_divisor = _RAND_18[14:0];
  _RAND_19 = {1{`RANDOM}};
  s5_in_state_divideByZero = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  s5_in_state_valid = _RAND_20[0:0];
  _RAND_21 = {1{`RANDOM}};
  s6_in_state_remainder = _RAND_21[15:0];
  _RAND_22 = {1{`RANDOM}};
  s6_in_state_quotient = _RAND_22[14:0];
  _RAND_23 = {1{`RANDOM}};
  s6_in_state_dividend = _RAND_23[14:0];
  _RAND_24 = {1{`RANDOM}};
  s6_in_state_divisor = _RAND_24[14:0];
  _RAND_25 = {1{`RANDOM}};
  s6_in_state_divideByZero = _RAND_25[0:0];
  _RAND_26 = {1{`RANDOM}};
  s6_in_state_valid = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  final_state_quotient = _RAND_27[14:0];
  _RAND_28 = {1{`RANDOM}};
  final_state_divideByZero = _RAND_28[0:0];
  _RAND_29 = {1{`RANDOM}};
  final_state_valid = _RAND_29[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
