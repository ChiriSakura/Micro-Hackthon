import chisel3._
import chisel3.util._

class AggregationUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val in_valid = IO(Input(Bool()))
  val in_scores = IO(Input(UInt(36.W)))
  val in_v = IO(Input(UInt(16.W)))
  val out_valid = IO(Output(Bool()))
  val out_sum_weights = IO(Output(UInt(11.W)))
  val out_weighted_value_sum = IO(Output(UInt(15.W)))

  withClockAndReset(clock, reset) {
    // --- Stage 1: Thresholding and Multiplication (Combinational Logic) ---
    val scores = Wire(Vec(4, UInt(9.W)))
    val vs = Wire(Vec(4, UInt(4.W)))
    for (i <- 0 until 4) {
      scores(i) := in_scores(i * 9 + 8, i * 9)
      vs(i) := in_v(i * 4 + 3, i * 4)
    }

    val threshold = 64.U(9.W)

    val s1_weights = Wire(Vec(4, UInt(9.W)))
    val s1_weighted_values = Wire(Vec(4, UInt(13.W)))

    for (i <- 0 until 4) {
      s1_weights(i) := Mux(scores(i) >= threshold, scores(i), 0.U(9.W))
      s1_weighted_values(i) := s1_weights(i) * vs(i)
    }

    // --- Pipeline Registers: Stage 1 -> Stage 2 ---
    val s2_valid = RegNext(in_valid, false.B)
    val s2_weights = RegNext(s1_weights, VecInit(Seq.fill(4)(0.U(9.W))))
    val s2_weighted_values = RegNext(s1_weighted_values, VecInit(Seq.fill(4)(0.U(13.W))))

    // --- Stage 2: First Level of Adder Tree (Combinational Logic) ---
    val s2_sum_weights_01 = s2_weights(0) +& s2_weights(1)
    val s2_sum_weights_23 = s2_weights(2) +& s2_weights(3)
    val s2_sum_weighted_values_01 = s2_weighted_values(0) +& s2_weighted_values(1)
    val s2_sum_weighted_values_23 = s2_weighted_values(2) +& s2_weighted_values(3)

    // --- Pipeline Registers: Stage 2 -> Stage 3 ---
    val s3_valid = RegNext(s2_valid, false.B)
    val s3_sum_weights_01 = RegNext(s2_sum_weights_01, 0.U(10.W))
    val s3_sum_weights_23 = RegNext(s2_sum_weights_23, 0.U(10.W))
    val s3_sum_weighted_values_01 = RegNext(s2_sum_weighted_values_01, 0.U(14.W))
    val s3_sum_weighted_values_23 = RegNext(s2_sum_weighted_values_23, 0.U(14.W))

    // --- Stage 3: Second Level of Adder Tree (Combinational Logic) ---
    val s3_final_sum_weights = s3_sum_weights_01 +& s3_sum_weights_23
    val s3_final_weighted_value_sum = s3_sum_weighted_values_01 +& s3_sum_weighted_values_23

    // --- Output Registers (End of Stage 3) ---
    out_valid := RegNext(s3_valid, false.B)
    out_sum_weights := RegNext(s3_final_sum_weights, 0.U(11.W))
    out_weighted_value_sum := RegNext(s3_final_weighted_value_sum, 0.U(15.W))
  }
}
