import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val in_q = IO(Input(UInt(8.W)))
  val in_k = IO(Input(UInt(8.W)))
  val out_score = IO(Output(UInt(9.W)))

  // Unpack the 4-bit components from the 8-bit inputs
  val q0 = in_q(3, 0)
  val q1 = in_q(7, 4)
  val k0 = in_k(3, 0)
  val k1 = in_k(7, 4)

  // Perform the 4x4 multiplications. The result of each is 8 bits.
  val prod0 = q0 * k0
  val prod1 = q1 * k1

  // Perform a widening addition to produce a 9-bit result.
  // The maximum value is (15*15) + (15*15) = 225 + 225 = 450, which requires 9 bits.
  // Using +& ensures the sum is widened to capture the carry bit, as a standard '+'
  // on two 8-bit operands would truncate the result to 8 bits.
  val sum = prod0 +& prod1

  // Assign the result to the output port.
  out_score := sum
}
