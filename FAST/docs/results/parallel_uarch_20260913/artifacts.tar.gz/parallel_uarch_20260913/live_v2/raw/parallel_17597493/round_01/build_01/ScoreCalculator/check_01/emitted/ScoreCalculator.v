module ScoreCalculator(
  input  [7:0] in_q, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 5:16]
  input  [7:0] in_k, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 6:16]
  output [8:0] out_score // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 7:21]
);
  wire [3:0] q0 = in_q[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 10:16]
  wire [3:0] q1 = in_q[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 11:16]
  wire [3:0] k0 = in_k[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 12:16]
  wire [3:0] k1 = in_k[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 13:16]
  wire [7:0] prod0 = q0 * k0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 16:18]
  wire [7:0] prod1 = q1 * k1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 17:18]
  assign out_score = prod0 + prod1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/parallel_17597493/round_01/build_01/ScoreCalculator/ScoreCalculator.scala 23:19]
endmodule
