module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] valid_in;
reg [255:0] e_values_in;
reg [127:0] v_in;
reg [7:0] threshold_in;
wire [0:0] valid_out;
wire [27:0] N_out;
wire [19:0] D_out;
wire [15:0] keep_mask_out;
SelectionReduce dut(.clock(clock),.reset(reset),.valid_in(valid_in),.e_values_in(e_values_in),.v_in(v_in),.threshold_in(threshold_in),.valid_out(valid_out),.N_out(N_out),.D_out(D_out),.keep_mask_out(keep_mask_out));
initial begin
clock=0;
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=0 step=0 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=0 step=0 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=0 step=0 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=0 step=4 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=0 step=4 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=0 step=4 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=0 step=4 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=6 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=0 step=6 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=0 step=6 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=0 step=6 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=1 step=0 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=1 step=0 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=1 step=0 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd115792089237316195423570985008687907853269984665640564039457584007913129639935;
v_in=128'd169473963133173273960190490760135540607;
threshold_in=8'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=1 step=4 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd133167120) $fatal(1,"module case=1 step=4 output=N_out expected=133167120 actual=%0d",N_out);
if (D_out !== 20'd1048560) $fatal(1,"module case=1 step=4 output=D_out expected=1048560 actual=%0d",D_out);
if (keep_mask_out !== 16'd65535) $fatal(1,"module case=1 step=4 output=keep_mask_out expected=65535 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=6 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=1 step=6 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=1 step=6 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=1 step=6 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=2 step=0 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=2 step=0 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=2 step=0 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd1766874025136433896750911497805568136923323180981774075523881651146915841;
v_in=128'd170808403787765189503184116671632670848;
threshold_in=8'd255;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=2 step=4 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=2 step=4 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=2 step=4 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=2 step=4 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=6 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=2 step=6 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=2 step=6 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=2 step=6 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=0 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=0 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=0 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd115792089237316195423570985008687907853269984665640564039457584007913129639935;
v_in=128'd169473963133173273960190490760135540607;
threshold_in=8'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd1766874025136433896750911497805568136923323180981774075523881651146915841;
v_in=128'd170808403787765189503184116671632670848;
threshold_in=8'd255;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=4 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=4 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=4 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=4 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd5010116670097283853620555544268666914047797972008237117970993721247686503107;
v_in=128'd46475263507977999705072762963541771308;
threshold_in=8'd229;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=5 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd133167120) $fatal(1,"module case=3 step=5 output=N_out expected=133167120 actual=%0d",N_out);
if (D_out !== 20'd1048560) $fatal(1,"module case=3 step=5 output=D_out expected=1048560 actual=%0d",D_out);
if (keep_mask_out !== 16'd65535) $fatal(1,"module case=3 step=5 output=keep_mask_out expected=65535 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd45383511537053108977470747370112445575325670222535028361530856088470021397431;
v_in=128'd285388984468875895299858827384914420132;
threshold_in=8'd182;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=6 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=6 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=6 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=6 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd3516573387333524165636348088976522062717236233742922796876431204174870240230;
v_in=128'd271066983621877908968918638637085777385;
threshold_in=8'd188;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=7 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=8 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=8 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=8 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=8 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd30499223771419532792218833727938902228852761334796758295973264271012125321163;
v_in=128'd134808318576073201960818475585439957734;
threshold_in=8'd161;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=9 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=9 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=9 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=9 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd89447219081499912568263165251681554051723680360650046553553540171806858103804;
v_in=128'd100410661617164621728880605661371221925;
threshold_in=8'd88;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=10 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=10 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=10 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=10 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd110815738967045451916128719282809271007738673564133716610704803328413440590087;
v_in=128'd309688687385713580622001913556156099167;
threshold_in=8'd100;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=11 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=12 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=12 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=12 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=12 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd91350048629003099782129489340920554426029484564904303965811158724918014559794;
v_in=128'd91090957346587171220431891002169113106;
threshold_in=8'd61;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=13 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=13 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=13 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=13 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd98896745960326480644557504187281072416905596541881303743231449678345275789485;
v_in=128'd200999688351700916608141738444020469253;
threshold_in=8'd57;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=14 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=14 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=14 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=14 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd54407928219654787423435254283465245218743835960895646735338189480467531404456;
v_in=128'd337947328938574706939679198540211632767;
threshold_in=8'd67;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=15 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=16 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=16 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=16 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=16 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd102690881629969037811052598518101033380359820819909362111223081199997092780422;
v_in=128'd188684146931185076404534381447925553049;
threshold_in=8'd205;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=17 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=17 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=17 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=17 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd19241418157368720722598100112040802382336408313571492194320716429734019939290;
v_in=128'd249302171831961860911357666017528957610;
threshold_in=8'd106;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=18 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=18 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=18 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=18 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd31736939120442933073086880787980772185061108675908992128431147647378615752341;
v_in=128'd67527032971394995272803565087551843241;
threshold_in=8'd109;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=19 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=20 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=20 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=20 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=20 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd57896928055670665928733867960092856710703453994410772906766553944782138277888;
v_in=128'd170808403787765189503184116671632670848;
threshold_in=8'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=21 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=21 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=21 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=21 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd57895161181645529494837117048595051142566530671229791132691030063130991362047;
v_in=128'd169473963133173273960190490760135540607;
threshold_in=8'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=22 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=22 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=22 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=22 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd57896928055670665928733867960092856710703453994410772906766553944782138277888;
v_in=128'd169473963133173273960190490760135540607;
threshold_in=8'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=23 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=24 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd201326592) $fatal(1,"module case=3 step=24 output=N_out expected=201326592 actual=%0d",N_out);
if (D_out !== 20'd524288) $fatal(1,"module case=3 step=24 output=D_out expected=524288 actual=%0d",D_out);
if (keep_mask_out !== 16'd65535) $fatal(1,"module case=3 step=24 output=keep_mask_out expected=65535 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd1;
e_values_in=256'd57895161181645529494837117048595051142566530671229791132691030063130991362047;
v_in=128'd170808403787765189503184116671632670848;
threshold_in=8'd3;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=25 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd66582544) $fatal(1,"module case=3 step=25 output=N_out expected=66582544 actual=%0d",N_out);
if (D_out !== 20'd524272) $fatal(1,"module case=3 step=25 output=D_out expected=524272 actual=%0d",D_out);
if (keep_mask_out !== 16'd65535) $fatal(1,"module case=3 step=25 output=keep_mask_out expected=65535 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=26 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd66584576) $fatal(1,"module case=3 step=26 output=N_out expected=66584576 actual=%0d",N_out);
if (D_out !== 20'd524288) $fatal(1,"module case=3 step=26 output=D_out expected=524288 actual=%0d",D_out);
if (keep_mask_out !== 16'd65535) $fatal(1,"module case=3 step=26 output=keep_mask_out expected=65535 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=27 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=28 output=valid_out expected=1 actual=%0d",valid_out);
if (N_out !== 28'd201328640) $fatal(1,"module case=3 step=28 output=N_out expected=201328640 actual=%0d",N_out);
if (D_out !== 20'd524272) $fatal(1,"module case=3 step=28 output=D_out expected=524272 actual=%0d",D_out);
if (keep_mask_out !== 16'd65535) $fatal(1,"module case=3 step=28 output=keep_mask_out expected=65535 actual=%0d",keep_mask_out);
reset=1'd0;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=29 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
e_values_in=256'd0;
v_in=128'd0;
threshold_in=8'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=30 output=valid_out expected=0 actual=%0d",valid_out);
if (N_out !== 28'd0) $fatal(1,"module case=3 step=30 output=N_out expected=0 actual=%0d",N_out);
if (D_out !== 20'd0) $fatal(1,"module case=3 step=30 output=D_out expected=0 actual=%0d",D_out);
if (keep_mask_out !== 16'd0) $fatal(1,"module case=3 step=30 output=keep_mask_out expected=0 actual=%0d",keep_mask_out);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule