import chisel3._
import chisel3.util._

class SelectionReduce extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val e_values_in = IO(Input(UInt(256.W)))
  val v_in = IO(Input(UInt(128.W)))
  val threshold_in = IO(Input(UInt(8.W)))
  val valid_out = IO(Output(Bool()))
  val N_out = IO(Output(SInt(28.W)))
  val D_out = IO(Output(UInt(20.W)))
  val keep_mask_out = IO(Output(UInt(16.W)))

  // --- Pipeline Valid Signals ---
  val s1_valid = withClockAndReset(clock, reset) { RegNext(valid_in, false.B) }
  val s2_valid = withClockAndReset(clock, reset) { RegNext(s1_valid, false.B) }
  val s3_valid = withClockAndReset(clock, reset) { RegNext(s2_valid, false.B) }
  val s4_valid = withClockAndReset(clock, reset) { RegNext(s3_valid, false.B) }
  valid_out := s4_valid

  // --- Input Unpacking ---
  val e_values = VecInit.tabulate(16)(i => e_values_in(16 * i + 15, 16 * i))
  val v_values = VecInit.tabulate(16)(i => v_in(8 * i + 7, 8 * i).asSInt)

  // --- Stage 1: Sum of exponentials (S) ---
  val S = e_values.reduceTree(_ +& _) // UInt(20.W), balanced tree

  val s1_S = withClockAndReset(clock, reset) { RegEnable(S, 0.U(20.W), valid_in) }
  val s1_threshold = withClockAndReset(clock, reset) { RegEnable(threshold_in, 0.U(8.W), valid_in) }
  val s1_e_values = withClockAndReset(clock, reset) { RegEnable(e_values, VecInit.fill(16)(0.U(16.W)), valid_in) }
  val s1_v_values = withClockAndReset(clock, reset) { RegEnable(v_values, VecInit.fill(16)(0.S(8.W)), valid_in) }

  // --- Stage 2: Selection (keep_mask) ---
  val S_thresh = s1_S * s1_threshold // UInt(28.W)
  val keep_mask = VecInit.tabulate(16)(i => (s1_e_values(i) << 8) > S_thresh)

  val s2_keep_mask = withClockAndReset(clock, reset) { RegEnable(keep_mask, VecInit.fill(16)(false.B), s1_valid) }
  val s2_e_values = withClockAndReset(clock, reset) { RegEnable(s1_e_values, VecInit.fill(16)(0.U(16.W)), s1_valid) }
  val s2_v_values = withClockAndReset(clock, reset) { RegEnable(s1_v_values, VecInit.fill(16)(0.S(8.W)), s1_valid) }

  // --- Stage 3: Term generation (n_term, d_term) ---
  val d_terms = Wire(Vec(16, UInt(16.W)))
  val n_terms = Wire(Vec(16, SInt(24.W)))
  for (i <- 0 until 16) {
    d_terms(i) := Mux(s2_keep_mask(i), s2_e_values(i), 0.U(16.W))
    n_terms(i) := Mux(s2_keep_mask(i), s2_e_values(i) * s2_v_values(i), 0.S(24.W))
  }

  val s3_d_terms = withClockAndReset(clock, reset) { RegEnable(d_terms, VecInit.fill(16)(0.U(16.W)), s2_valid) }
  val s3_n_terms = withClockAndReset(clock, reset) { RegEnable(n_terms, VecInit.fill(16)(0.S(24.W)), s2_valid) }
  val s3_keep_mask = withClockAndReset(clock, reset) { RegEnable(s2_keep_mask, VecInit.fill(16)(false.B), s2_valid) }

  // --- Stage 4: Reduction (N, D) ---
  val D = s3_d_terms.reduceTree(_ +& _) // UInt(20.W), balanced tree
  val N = s3_n_terms.reduceTree(_ +& _) // SInt(28.W), balanced tree

  val s4_D = withClockAndReset(clock, reset) { RegEnable(D, 0.U(20.W), s3_valid) }
  val s4_N = withClockAndReset(clock, reset) { RegEnable(N, 0.S(28.W), s3_valid) }
  val s4_keep_mask = withClockAndReset(clock, reset) { RegEnable(s3_keep_mask.asUInt, 0.U(16.W), s3_valid) }

  // --- Output Assignment ---
  D_out := s4_D
  N_out := s4_N
  keep_mask_out := s4_keep_mask
}
