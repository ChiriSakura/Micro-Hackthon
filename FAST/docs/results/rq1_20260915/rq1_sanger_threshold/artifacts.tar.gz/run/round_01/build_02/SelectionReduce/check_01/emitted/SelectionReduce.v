module SelectionReduce(
  input          clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 5:17]
  input          reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 6:17]
  input          valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 7:20]
  input  [255:0] e_values_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 8:23]
  input  [127:0] v_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 9:16]
  input  [7:0]   threshold_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 10:24]
  output         valid_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 11:21]
  output [27:0]  N_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 12:17]
  output [19:0]  D_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 13:17]
  output [15:0]  keep_mask_out // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 14:25]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [31:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [31:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [31:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [31:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [31:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [31:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [31:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
  reg [31:0] _RAND_63;
  reg [31:0] _RAND_64;
  reg [31:0] _RAND_65;
  reg [31:0] _RAND_66;
  reg [31:0] _RAND_67;
  reg [31:0] _RAND_68;
  reg [31:0] _RAND_69;
  reg [31:0] _RAND_70;
  reg [31:0] _RAND_71;
  reg [31:0] _RAND_72;
  reg [31:0] _RAND_73;
  reg [31:0] _RAND_74;
  reg [31:0] _RAND_75;
  reg [31:0] _RAND_76;
  reg [31:0] _RAND_77;
  reg [31:0] _RAND_78;
  reg [31:0] _RAND_79;
  reg [31:0] _RAND_80;
  reg [31:0] _RAND_81;
  reg [31:0] _RAND_82;
  reg [31:0] _RAND_83;
  reg [31:0] _RAND_84;
  reg [31:0] _RAND_85;
  reg [31:0] _RAND_86;
  reg [31:0] _RAND_87;
  reg [31:0] _RAND_88;
  reg [31:0] _RAND_89;
  reg [31:0] _RAND_90;
  reg [31:0] _RAND_91;
  reg [31:0] _RAND_92;
  reg [31:0] _RAND_93;
  reg [31:0] _RAND_94;
  reg [31:0] _RAND_95;
  reg [31:0] _RAND_96;
  reg [31:0] _RAND_97;
  reg [31:0] _RAND_98;
  reg [31:0] _RAND_99;
  reg [31:0] _RAND_100;
  reg [31:0] _RAND_101;
  reg [31:0] _RAND_102;
  reg [31:0] _RAND_103;
  reg [31:0] _RAND_104;
  reg [31:0] _RAND_105;
  reg [31:0] _RAND_106;
  reg [31:0] _RAND_107;
  reg [31:0] _RAND_108;
  reg [31:0] _RAND_109;
  reg [31:0] _RAND_110;
  reg [31:0] _RAND_111;
  reg [31:0] _RAND_112;
  reg [31:0] _RAND_113;
  reg [31:0] _RAND_114;
  reg [31:0] _RAND_115;
  reg [31:0] _RAND_116;
  reg [31:0] _RAND_117;
  reg [31:0] _RAND_118;
  reg [31:0] _RAND_119;
  reg [31:0] _RAND_120;
  reg [31:0] _RAND_121;
  reg [31:0] _RAND_122;
  reg [31:0] _RAND_123;
  reg [31:0] _RAND_124;
  reg [31:0] _RAND_125;
  reg [31:0] _RAND_126;
  reg [31:0] _RAND_127;
  reg [31:0] _RAND_128;
  reg [31:0] _RAND_129;
  reg [31:0] _RAND_130;
  reg [31:0] _RAND_131;
  reg [31:0] _RAND_132;
  reg [31:0] _RAND_133;
  reg [31:0] _RAND_134;
  reg [31:0] _RAND_135;
  reg [31:0] _RAND_136;
`endif // RANDOMIZE_REG_INIT
  reg  s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 17:59]
  reg  s2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 18:59]
  reg  s3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 19:59]
  reg  s4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 20:59]
  wire [15:0] e_values_0 = e_values_in[15:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_1 = e_values_in[31:16]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_2 = e_values_in[47:32]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_3 = e_values_in[63:48]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_4 = e_values_in[79:64]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_5 = e_values_in[95:80]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_6 = e_values_in[111:96]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_7 = e_values_in[127:112]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_8 = e_values_in[143:128]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_9 = e_values_in[159:144]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_10 = e_values_in[175:160]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_11 = e_values_in[191:176]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_12 = e_values_in[207:192]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_13 = e_values_in[223:208]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_14 = e_values_in[239:224]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [15:0] e_values_15 = e_values_in[255:240]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 24:59]
  wire [7:0] v_values_0 = v_in[7:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_1 = v_in[15:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_2 = v_in[23:16]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_3 = v_in[31:24]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_4 = v_in[39:32]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_5 = v_in[47:40]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_6 = v_in[55:48]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_7 = v_in[63:56]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_8 = v_in[71:64]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_9 = v_in[79:72]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_10 = v_in[87:80]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_11 = v_in[95:88]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_12 = v_in[103:96]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_13 = v_in[111:104]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_14 = v_in[119:112]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [7:0] v_values_15 = v_in[127:120]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 25:71]
  wire [16:0] _S_T = e_values_0 + e_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [16:0] _GEN_133 = {{1'd0}, e_values_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [17:0] _S_T_1 = _S_T + _GEN_133; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [17:0] _GEN_134 = {{2'd0}, e_values_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [18:0] _S_T_2 = _S_T_1 + _GEN_134; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [18:0] _GEN_135 = {{3'd0}, e_values_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [19:0] _S_T_3 = _S_T_2 + _GEN_135; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [19:0] _GEN_136 = {{4'd0}, e_values_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [20:0] _S_T_4 = _S_T_3 + _GEN_136; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [20:0] _GEN_137 = {{5'd0}, e_values_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [21:0] _S_T_5 = _S_T_4 + _GEN_137; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [21:0] _GEN_138 = {{6'd0}, e_values_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [22:0] _S_T_6 = _S_T_5 + _GEN_138; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [22:0] _GEN_139 = {{7'd0}, e_values_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [23:0] _S_T_7 = _S_T_6 + _GEN_139; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [23:0] _GEN_140 = {{8'd0}, e_values_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [24:0] _S_T_8 = _S_T_7 + _GEN_140; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [24:0] _GEN_141 = {{9'd0}, e_values_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [25:0] _S_T_9 = _S_T_8 + _GEN_141; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [25:0] _GEN_142 = {{10'd0}, e_values_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [26:0] _S_T_10 = _S_T_9 + _GEN_142; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [26:0] _GEN_143 = {{11'd0}, e_values_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [27:0] _S_T_11 = _S_T_10 + _GEN_143; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [27:0] _GEN_144 = {{12'd0}, e_values_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [28:0] _S_T_12 = _S_T_11 + _GEN_144; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [28:0] _GEN_145 = {{13'd0}, e_values_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [29:0] _S_T_13 = _S_T_12 + _GEN_145; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [29:0] _GEN_146 = {{14'd0}, e_values_15}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  wire [30:0] S = _S_T_13 + _GEN_146; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 28:29]
  reg [19:0] s1_S; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 29:57]
  wire [30:0] _GEN_0 = valid_in ? S : {{11'd0}, s1_S}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 29:{57,57,57}]
  reg [7:0] s1_threshold; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 30:65]
  reg [15:0] s1_e_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [15:0] s1_e_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
  reg [7:0] s1_v_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  reg [7:0] s1_v_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
  wire [27:0] S_thresh = s1_S * s1_threshold; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 35:23]
  wire [23:0] _keep_mask_T = {s1_e_values_0, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_147 = {{4'd0}, _keep_mask_T}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_0 = _GEN_147 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_2 = {s1_e_values_1, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_148 = {{4'd0}, _keep_mask_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_1 = _GEN_148 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_4 = {s1_e_values_2, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_149 = {{4'd0}, _keep_mask_T_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_2 = _GEN_149 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_6 = {s1_e_values_3, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_150 = {{4'd0}, _keep_mask_T_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_3 = _GEN_150 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_8 = {s1_e_values_4, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_151 = {{4'd0}, _keep_mask_T_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_4 = _GEN_151 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_10 = {s1_e_values_5, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_152 = {{4'd0}, _keep_mask_T_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_5 = _GEN_152 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_12 = {s1_e_values_6, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_153 = {{4'd0}, _keep_mask_T_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_6 = _GEN_153 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_14 = {s1_e_values_7, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_154 = {{4'd0}, _keep_mask_T_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_7 = _GEN_154 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_16 = {s1_e_values_8, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_155 = {{4'd0}, _keep_mask_T_16}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_8 = _GEN_155 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_18 = {s1_e_values_9, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_156 = {{4'd0}, _keep_mask_T_18}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_9 = _GEN_156 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_20 = {s1_e_values_10, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_157 = {{4'd0}, _keep_mask_T_20}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_10 = _GEN_157 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_22 = {s1_e_values_11, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_158 = {{4'd0}, _keep_mask_T_22}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_11 = _GEN_158 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_24 = {s1_e_values_12, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_159 = {{4'd0}, _keep_mask_T_24}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_12 = _GEN_159 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_26 = {s1_e_values_13, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_160 = {{4'd0}, _keep_mask_T_26}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_13 = _GEN_160 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_28 = {s1_e_values_14, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_161 = {{4'd0}, _keep_mask_T_28}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_14 = _GEN_161 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire [23:0] _keep_mask_T_30 = {s1_e_values_15, 8'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:51]
  wire [27:0] _GEN_162 = {{4'd0}, _keep_mask_T_30}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  wire  keep_mask_15 = _GEN_162 > S_thresh; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 36:57]
  reg  s2_keep_mask_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg  s2_keep_mask_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
  reg [15:0] s2_e_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [15:0] s2_e_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
  reg [7:0] s2_v_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  reg [7:0] s2_v_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
  wire [16:0] _n_terms_0_T = {1'b0,$signed(s2_e_values_0)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_0_T_1 = $signed(s2_v_values_0) * $signed(_n_terms_0_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_0_T_3 = _n_terms_0_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_1_T = {1'b0,$signed(s2_e_values_1)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_1_T_1 = $signed(s2_v_values_1) * $signed(_n_terms_1_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_1_T_3 = _n_terms_1_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_2_T = {1'b0,$signed(s2_e_values_2)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_2_T_1 = $signed(s2_v_values_2) * $signed(_n_terms_2_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_2_T_3 = _n_terms_2_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_3_T = {1'b0,$signed(s2_e_values_3)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_3_T_1 = $signed(s2_v_values_3) * $signed(_n_terms_3_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_3_T_3 = _n_terms_3_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_4_T = {1'b0,$signed(s2_e_values_4)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_4_T_1 = $signed(s2_v_values_4) * $signed(_n_terms_4_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_4_T_3 = _n_terms_4_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_5_T = {1'b0,$signed(s2_e_values_5)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_5_T_1 = $signed(s2_v_values_5) * $signed(_n_terms_5_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_5_T_3 = _n_terms_5_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_6_T = {1'b0,$signed(s2_e_values_6)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_6_T_1 = $signed(s2_v_values_6) * $signed(_n_terms_6_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_6_T_3 = _n_terms_6_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_7_T = {1'b0,$signed(s2_e_values_7)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_7_T_1 = $signed(s2_v_values_7) * $signed(_n_terms_7_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_7_T_3 = _n_terms_7_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_8_T = {1'b0,$signed(s2_e_values_8)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_8_T_1 = $signed(s2_v_values_8) * $signed(_n_terms_8_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_8_T_3 = _n_terms_8_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_9_T = {1'b0,$signed(s2_e_values_9)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_9_T_1 = $signed(s2_v_values_9) * $signed(_n_terms_9_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_9_T_3 = _n_terms_9_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_10_T = {1'b0,$signed(s2_e_values_10)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_10_T_1 = $signed(s2_v_values_10) * $signed(_n_terms_10_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_10_T_3 = _n_terms_10_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_11_T = {1'b0,$signed(s2_e_values_11)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_11_T_1 = $signed(s2_v_values_11) * $signed(_n_terms_11_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_11_T_3 = _n_terms_11_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_12_T = {1'b0,$signed(s2_e_values_12)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_12_T_1 = $signed(s2_v_values_12) * $signed(_n_terms_12_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_12_T_3 = _n_terms_12_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_13_T = {1'b0,$signed(s2_e_values_13)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_13_T_1 = $signed(s2_v_values_13) * $signed(_n_terms_13_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_13_T_3 = _n_terms_13_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_14_T = {1'b0,$signed(s2_e_values_14)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_14_T_1 = $signed(s2_v_values_14) * $signed(_n_terms_14_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_14_T_3 = _n_terms_14_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [16:0] _n_terms_15_T = {1'b0,$signed(s2_e_values_15)}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [24:0] _n_terms_15_T_1 = $signed(s2_v_values_15) * $signed(_n_terms_15_T); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  wire [23:0] _n_terms_15_T_3 = _n_terms_15_T_1[23:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:55]
  reg [15:0] s3_d_terms_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [15:0] s3_d_terms_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
  reg [23:0] s3_n_terms_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg [23:0] s3_n_terms_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
  reg  s3_keep_mask_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  reg  s3_keep_mask_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
  wire [16:0] _D_T = s3_d_terms_0 + s3_d_terms_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [16:0] _GEN_163 = {{1'd0}, s3_d_terms_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [17:0] _D_T_1 = _D_T + _GEN_163; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [17:0] _GEN_164 = {{2'd0}, s3_d_terms_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [18:0] _D_T_2 = _D_T_1 + _GEN_164; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [18:0] _GEN_165 = {{3'd0}, s3_d_terms_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [19:0] _D_T_3 = _D_T_2 + _GEN_165; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [19:0] _GEN_166 = {{4'd0}, s3_d_terms_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [20:0] _D_T_4 = _D_T_3 + _GEN_166; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [20:0] _GEN_167 = {{5'd0}, s3_d_terms_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [21:0] _D_T_5 = _D_T_4 + _GEN_167; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [21:0] _GEN_168 = {{6'd0}, s3_d_terms_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [22:0] _D_T_6 = _D_T_5 + _GEN_168; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [22:0] _GEN_169 = {{7'd0}, s3_d_terms_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [23:0] _D_T_7 = _D_T_6 + _GEN_169; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [23:0] _GEN_170 = {{8'd0}, s3_d_terms_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [24:0] _D_T_8 = _D_T_7 + _GEN_170; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [24:0] _GEN_171 = {{9'd0}, s3_d_terms_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [25:0] _D_T_9 = _D_T_8 + _GEN_171; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [25:0] _GEN_172 = {{10'd0}, s3_d_terms_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [26:0] _D_T_10 = _D_T_9 + _GEN_172; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [26:0] _GEN_173 = {{11'd0}, s3_d_terms_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [27:0] _D_T_11 = _D_T_10 + _GEN_173; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [27:0] _GEN_174 = {{12'd0}, s3_d_terms_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [28:0] _D_T_12 = _D_T_11 + _GEN_174; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [28:0] _GEN_175 = {{13'd0}, s3_d_terms_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [29:0] _D_T_13 = _D_T_12 + _GEN_175; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [29:0] _GEN_176 = {{14'd0}, s3_d_terms_15}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [30:0] D = _D_T_13 + _GEN_176; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 53:31]
  wire [24:0] _N_T = $signed(s3_n_terms_0) + $signed(s3_n_terms_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [24:0] _GEN_177 = {{1{s3_n_terms_2[23]}},s3_n_terms_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [25:0] _N_T_1 = $signed(_N_T) + $signed(_GEN_177); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [25:0] _GEN_178 = {{2{s3_n_terms_3[23]}},s3_n_terms_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [26:0] _N_T_2 = $signed(_N_T_1) + $signed(_GEN_178); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [26:0] _GEN_179 = {{3{s3_n_terms_4[23]}},s3_n_terms_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [27:0] _N_T_3 = $signed(_N_T_2) + $signed(_GEN_179); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [27:0] _GEN_180 = {{4{s3_n_terms_5[23]}},s3_n_terms_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [28:0] _N_T_4 = $signed(_N_T_3) + $signed(_GEN_180); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [28:0] _GEN_181 = {{5{s3_n_terms_6[23]}},s3_n_terms_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [29:0] _N_T_5 = $signed(_N_T_4) + $signed(_GEN_181); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [29:0] _GEN_182 = {{6{s3_n_terms_7[23]}},s3_n_terms_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [30:0] _N_T_6 = $signed(_N_T_5) + $signed(_GEN_182); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [30:0] _GEN_183 = {{7{s3_n_terms_8[23]}},s3_n_terms_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [31:0] _N_T_7 = $signed(_N_T_6) + $signed(_GEN_183); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [31:0] _GEN_184 = {{8{s3_n_terms_9[23]}},s3_n_terms_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [32:0] _N_T_8 = $signed(_N_T_7) + $signed(_GEN_184); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [32:0] _GEN_185 = {{9{s3_n_terms_10[23]}},s3_n_terms_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [33:0] _N_T_9 = $signed(_N_T_8) + $signed(_GEN_185); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [33:0] _GEN_186 = {{10{s3_n_terms_11[23]}},s3_n_terms_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [34:0] _N_T_10 = $signed(_N_T_9) + $signed(_GEN_186); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [34:0] _GEN_187 = {{11{s3_n_terms_12[23]}},s3_n_terms_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [35:0] _N_T_11 = $signed(_N_T_10) + $signed(_GEN_187); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [35:0] _GEN_188 = {{12{s3_n_terms_13[23]}},s3_n_terms_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [36:0] _N_T_12 = $signed(_N_T_11) + $signed(_GEN_188); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [36:0] _GEN_189 = {{13{s3_n_terms_14[23]}},s3_n_terms_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [37:0] _N_T_13 = $signed(_N_T_12) + $signed(_GEN_189); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [37:0] _GEN_190 = {{14{s3_n_terms_15[23]}},s3_n_terms_15}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  wire [38:0] N = $signed(_N_T_13) + $signed(_GEN_190); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 54:31]
  reg [19:0] s4_D; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 55:57]
  wire [30:0] _GEN_130 = s3_valid ? D : {{11'd0}, s4_D}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 55:{57,57,57}]
  reg [27:0] s4_N; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 56:57]
  wire [38:0] _GEN_131 = s3_valid ? $signed(N) : $signed({{11{s4_N[27]}},s4_N}); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 56:{57,57,57}]
  wire [7:0] s4_keep_mask_lo = {s3_keep_mask_7,s3_keep_mask_6,s3_keep_mask_5,s3_keep_mask_4,s3_keep_mask_3,
    s3_keep_mask_2,s3_keep_mask_1,s3_keep_mask_0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:79]
  wire [15:0] _s4_keep_mask_T = {s3_keep_mask_15,s3_keep_mask_14,s3_keep_mask_13,s3_keep_mask_12,s3_keep_mask_11,
    s3_keep_mask_10,s3_keep_mask_9,s3_keep_mask_8,s4_keep_mask_lo}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:79]
  reg [15:0] s4_keep_mask; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:65]
  wire [30:0] _GEN_191 = reset ? 31'h0 : _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 29:{57,57}]
  wire [30:0] _GEN_192 = reset ? 31'h0 : _GEN_130; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 55:{57,57}]
  wire [38:0] _GEN_193 = reset ? $signed(39'sh0) : $signed(_GEN_131); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 56:{57,57}]
  assign valid_out = s4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 21:13]
  assign N_out = s4_N; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 61:9]
  assign D_out = s4_D; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 60:9]
  assign keep_mask_out = s4_keep_mask; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 62:17]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 17:59]
      s1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 17:59]
    end else begin
      s1_valid <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 17:59]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 18:59]
      s2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 18:59]
    end else begin
      s2_valid <= s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 18:59]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 19:59]
      s3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 19:59]
    end else begin
      s3_valid <= s2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 19:59]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 20:59]
      s4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 20:59]
    end else begin
      s4_valid <= s3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 20:59]
    end
    s1_S <= _GEN_191[19:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 29:{57,57}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 30:65]
      s1_threshold <= 8'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 30:65]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 30:65]
      s1_threshold <= threshold_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 30:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_0 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_0 <= e_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_1 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_1 <= e_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_2 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_2 <= e_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_3 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_3 <= e_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_4 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_4 <= e_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_5 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_5 <= e_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_6 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_6 <= e_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_7 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_7 <= e_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_8 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_8 <= e_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_9 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_9 <= e_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_10 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_10 <= e_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_11 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_11 <= e_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_12 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_12 <= e_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_13 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_13 <= e_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_14 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_14 <= e_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_15 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
      s1_e_values_15 <= e_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 31:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_0 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_0 <= v_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_1 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_1 <= v_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_2 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_2 <= v_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_3 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_3 <= v_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_4 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_4 <= v_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_5 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_5 <= v_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_6 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_6 <= v_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_7 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_7 <= v_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_8 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_8 <= v_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_9 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_9 <= v_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_10 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_10 <= v_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_11 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_11 <= v_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_12 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_12 <= v_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_13 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_13 <= v_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_14 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_14 <= v_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_15 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
      s1_v_values_15 <= v_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 32:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_0 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_0 <= keep_mask_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_1 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_1 <= keep_mask_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_2 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_2 <= keep_mask_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_3 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_3 <= keep_mask_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_4 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_4 <= keep_mask_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_5 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_5 <= keep_mask_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_6 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_6 <= keep_mask_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_7 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_7 <= keep_mask_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_8 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_8 <= keep_mask_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_9 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_9 <= keep_mask_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_10 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_10 <= keep_mask_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_11 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_11 <= keep_mask_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_12 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_12 <= keep_mask_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_13 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_13 <= keep_mask_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_14 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_14 <= keep_mask_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_15 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
      s2_keep_mask_15 <= keep_mask_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 37:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_0 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_0 <= s1_e_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_1 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_1 <= s1_e_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_2 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_2 <= s1_e_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_3 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_3 <= s1_e_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_4 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_4 <= s1_e_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_5 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_5 <= s1_e_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_6 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_6 <= s1_e_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_7 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_7 <= s1_e_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_8 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_8 <= s1_e_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_9 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_9 <= s1_e_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_10 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_10 <= s1_e_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_11 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_11 <= s1_e_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_12 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_12 <= s1_e_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_13 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_13 <= s1_e_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_14 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_14 <= s1_e_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_15 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
      s2_e_values_15 <= s1_e_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 38:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_0 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_0 <= s1_v_values_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_1 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_1 <= s1_v_values_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_2 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_2 <= s1_v_values_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_3 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_3 <= s1_v_values_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_4 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_4 <= s1_v_values_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_5 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_5 <= s1_v_values_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_6 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_6 <= s1_v_values_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_7 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_7 <= s1_v_values_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_8 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_8 <= s1_v_values_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_9 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_9 <= s1_v_values_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_10 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_10 <= s1_v_values_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_11 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_11 <= s1_v_values_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_12 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_12 <= s1_v_values_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_13 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_13 <= s1_v_values_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_14 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_14 <= s1_v_values_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_15 <= 8'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end else if (s1_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
      s2_v_values_15 <= s1_v_values_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 39:64]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_0 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_0) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_0 <= s2_e_values_0;
      end else begin
        s3_d_terms_0 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_1 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_1) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_1 <= s2_e_values_1;
      end else begin
        s3_d_terms_1 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_2 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_2 <= s2_e_values_2;
      end else begin
        s3_d_terms_2 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_3 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_3 <= s2_e_values_3;
      end else begin
        s3_d_terms_3 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_4 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_4) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_4 <= s2_e_values_4;
      end else begin
        s3_d_terms_4 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_5 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_5 <= s2_e_values_5;
      end else begin
        s3_d_terms_5 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_6 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_6) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_6 <= s2_e_values_6;
      end else begin
        s3_d_terms_6 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_7 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_7) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_7 <= s2_e_values_7;
      end else begin
        s3_d_terms_7 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_8 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_8 <= s2_e_values_8;
      end else begin
        s3_d_terms_8 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_9 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_9) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_9 <= s2_e_values_9;
      end else begin
        s3_d_terms_9 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_10 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_10) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_10 <= s2_e_values_10;
      end else begin
        s3_d_terms_10 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_11 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_11 <= s2_e_values_11;
      end else begin
        s3_d_terms_11 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_12 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_12) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_12 <= s2_e_values_12;
      end else begin
        s3_d_terms_12 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_13 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_13) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_13 <= s2_e_values_13;
      end else begin
        s3_d_terms_13 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_14 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_14) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_14 <= s2_e_values_14;
      end else begin
        s3_d_terms_14 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      s3_d_terms_15 <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 48:63]
      if (s2_keep_mask_15) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 45:22]
        s3_d_terms_15 <= s2_e_values_15;
      end else begin
        s3_d_terms_15 <= 16'h0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_0 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_0) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_0 <= _n_terms_0_T_3;
      end else begin
        s3_n_terms_0 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_1 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_1) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_1 <= _n_terms_1_T_3;
      end else begin
        s3_n_terms_1 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_2 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_2 <= _n_terms_2_T_3;
      end else begin
        s3_n_terms_2 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_3 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_3 <= _n_terms_3_T_3;
      end else begin
        s3_n_terms_3 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_4 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_4) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_4 <= _n_terms_4_T_3;
      end else begin
        s3_n_terms_4 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_5 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_5 <= _n_terms_5_T_3;
      end else begin
        s3_n_terms_5 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_6 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_6) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_6 <= _n_terms_6_T_3;
      end else begin
        s3_n_terms_6 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_7 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_7) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_7 <= _n_terms_7_T_3;
      end else begin
        s3_n_terms_7 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_8 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_8 <= _n_terms_8_T_3;
      end else begin
        s3_n_terms_8 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_9 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_9) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_9 <= _n_terms_9_T_3;
      end else begin
        s3_n_terms_9 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_10 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_10) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_10 <= _n_terms_10_T_3;
      end else begin
        s3_n_terms_10 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_11 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_11 <= _n_terms_11_T_3;
      end else begin
        s3_n_terms_11 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_12 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_12) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_12 <= _n_terms_12_T_3;
      end else begin
        s3_n_terms_12 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_13 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_13) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_13 <= _n_terms_13_T_3;
      end else begin
        s3_n_terms_13 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_14 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_14) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_14 <= _n_terms_14_T_3;
      end else begin
        s3_n_terms_14 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      s3_n_terms_15 <= 24'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 49:63]
      if (s2_keep_mask_15) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 46:22]
        s3_n_terms_15 <= _n_terms_15_T_3;
      end else begin
        s3_n_terms_15 <= 24'sh0;
      end
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_0 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_0 <= s2_keep_mask_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_1 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_1 <= s2_keep_mask_1; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_2 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_2 <= s2_keep_mask_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_3 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_3 <= s2_keep_mask_3; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_4 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_4 <= s2_keep_mask_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_5 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_5 <= s2_keep_mask_5; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_6 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_6 <= s2_keep_mask_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_7 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_7 <= s2_keep_mask_7; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_8 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_8 <= s2_keep_mask_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_9 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_9 <= s2_keep_mask_9; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_10 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_10 <= s2_keep_mask_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_11 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_11 <= s2_keep_mask_11; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_12 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_12 <= s2_keep_mask_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_13 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_13 <= s2_keep_mask_13; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_14 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_14 <= s2_keep_mask_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_15 <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end else if (s2_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
      s3_keep_mask_15 <= s2_keep_mask_15; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 50:65]
    end
    s4_D <= _GEN_192[19:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 55:{57,57}]
    s4_N <= _GEN_193[27:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 56:{57,57}]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:65]
      s4_keep_mask <= 16'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:65]
    end else if (s3_valid) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:65]
      s4_keep_mask <= _s4_keep_mask_T; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_02/SelectionReduce/SelectionReduce.scala 57:65]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  s1_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  s2_valid = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  s3_valid = _RAND_2[0:0];
  _RAND_3 = {1{`RANDOM}};
  s4_valid = _RAND_3[0:0];
  _RAND_4 = {1{`RANDOM}};
  s1_S = _RAND_4[19:0];
  _RAND_5 = {1{`RANDOM}};
  s1_threshold = _RAND_5[7:0];
  _RAND_6 = {1{`RANDOM}};
  s1_e_values_0 = _RAND_6[15:0];
  _RAND_7 = {1{`RANDOM}};
  s1_e_values_1 = _RAND_7[15:0];
  _RAND_8 = {1{`RANDOM}};
  s1_e_values_2 = _RAND_8[15:0];
  _RAND_9 = {1{`RANDOM}};
  s1_e_values_3 = _RAND_9[15:0];
  _RAND_10 = {1{`RANDOM}};
  s1_e_values_4 = _RAND_10[15:0];
  _RAND_11 = {1{`RANDOM}};
  s1_e_values_5 = _RAND_11[15:0];
  _RAND_12 = {1{`RANDOM}};
  s1_e_values_6 = _RAND_12[15:0];
  _RAND_13 = {1{`RANDOM}};
  s1_e_values_7 = _RAND_13[15:0];
  _RAND_14 = {1{`RANDOM}};
  s1_e_values_8 = _RAND_14[15:0];
  _RAND_15 = {1{`RANDOM}};
  s1_e_values_9 = _RAND_15[15:0];
  _RAND_16 = {1{`RANDOM}};
  s1_e_values_10 = _RAND_16[15:0];
  _RAND_17 = {1{`RANDOM}};
  s1_e_values_11 = _RAND_17[15:0];
  _RAND_18 = {1{`RANDOM}};
  s1_e_values_12 = _RAND_18[15:0];
  _RAND_19 = {1{`RANDOM}};
  s1_e_values_13 = _RAND_19[15:0];
  _RAND_20 = {1{`RANDOM}};
  s1_e_values_14 = _RAND_20[15:0];
  _RAND_21 = {1{`RANDOM}};
  s1_e_values_15 = _RAND_21[15:0];
  _RAND_22 = {1{`RANDOM}};
  s1_v_values_0 = _RAND_22[7:0];
  _RAND_23 = {1{`RANDOM}};
  s1_v_values_1 = _RAND_23[7:0];
  _RAND_24 = {1{`RANDOM}};
  s1_v_values_2 = _RAND_24[7:0];
  _RAND_25 = {1{`RANDOM}};
  s1_v_values_3 = _RAND_25[7:0];
  _RAND_26 = {1{`RANDOM}};
  s1_v_values_4 = _RAND_26[7:0];
  _RAND_27 = {1{`RANDOM}};
  s1_v_values_5 = _RAND_27[7:0];
  _RAND_28 = {1{`RANDOM}};
  s1_v_values_6 = _RAND_28[7:0];
  _RAND_29 = {1{`RANDOM}};
  s1_v_values_7 = _RAND_29[7:0];
  _RAND_30 = {1{`RANDOM}};
  s1_v_values_8 = _RAND_30[7:0];
  _RAND_31 = {1{`RANDOM}};
  s1_v_values_9 = _RAND_31[7:0];
  _RAND_32 = {1{`RANDOM}};
  s1_v_values_10 = _RAND_32[7:0];
  _RAND_33 = {1{`RANDOM}};
  s1_v_values_11 = _RAND_33[7:0];
  _RAND_34 = {1{`RANDOM}};
  s1_v_values_12 = _RAND_34[7:0];
  _RAND_35 = {1{`RANDOM}};
  s1_v_values_13 = _RAND_35[7:0];
  _RAND_36 = {1{`RANDOM}};
  s1_v_values_14 = _RAND_36[7:0];
  _RAND_37 = {1{`RANDOM}};
  s1_v_values_15 = _RAND_37[7:0];
  _RAND_38 = {1{`RANDOM}};
  s2_keep_mask_0 = _RAND_38[0:0];
  _RAND_39 = {1{`RANDOM}};
  s2_keep_mask_1 = _RAND_39[0:0];
  _RAND_40 = {1{`RANDOM}};
  s2_keep_mask_2 = _RAND_40[0:0];
  _RAND_41 = {1{`RANDOM}};
  s2_keep_mask_3 = _RAND_41[0:0];
  _RAND_42 = {1{`RANDOM}};
  s2_keep_mask_4 = _RAND_42[0:0];
  _RAND_43 = {1{`RANDOM}};
  s2_keep_mask_5 = _RAND_43[0:0];
  _RAND_44 = {1{`RANDOM}};
  s2_keep_mask_6 = _RAND_44[0:0];
  _RAND_45 = {1{`RANDOM}};
  s2_keep_mask_7 = _RAND_45[0:0];
  _RAND_46 = {1{`RANDOM}};
  s2_keep_mask_8 = _RAND_46[0:0];
  _RAND_47 = {1{`RANDOM}};
  s2_keep_mask_9 = _RAND_47[0:0];
  _RAND_48 = {1{`RANDOM}};
  s2_keep_mask_10 = _RAND_48[0:0];
  _RAND_49 = {1{`RANDOM}};
  s2_keep_mask_11 = _RAND_49[0:0];
  _RAND_50 = {1{`RANDOM}};
  s2_keep_mask_12 = _RAND_50[0:0];
  _RAND_51 = {1{`RANDOM}};
  s2_keep_mask_13 = _RAND_51[0:0];
  _RAND_52 = {1{`RANDOM}};
  s2_keep_mask_14 = _RAND_52[0:0];
  _RAND_53 = {1{`RANDOM}};
  s2_keep_mask_15 = _RAND_53[0:0];
  _RAND_54 = {1{`RANDOM}};
  s2_e_values_0 = _RAND_54[15:0];
  _RAND_55 = {1{`RANDOM}};
  s2_e_values_1 = _RAND_55[15:0];
  _RAND_56 = {1{`RANDOM}};
  s2_e_values_2 = _RAND_56[15:0];
  _RAND_57 = {1{`RANDOM}};
  s2_e_values_3 = _RAND_57[15:0];
  _RAND_58 = {1{`RANDOM}};
  s2_e_values_4 = _RAND_58[15:0];
  _RAND_59 = {1{`RANDOM}};
  s2_e_values_5 = _RAND_59[15:0];
  _RAND_60 = {1{`RANDOM}};
  s2_e_values_6 = _RAND_60[15:0];
  _RAND_61 = {1{`RANDOM}};
  s2_e_values_7 = _RAND_61[15:0];
  _RAND_62 = {1{`RANDOM}};
  s2_e_values_8 = _RAND_62[15:0];
  _RAND_63 = {1{`RANDOM}};
  s2_e_values_9 = _RAND_63[15:0];
  _RAND_64 = {1{`RANDOM}};
  s2_e_values_10 = _RAND_64[15:0];
  _RAND_65 = {1{`RANDOM}};
  s2_e_values_11 = _RAND_65[15:0];
  _RAND_66 = {1{`RANDOM}};
  s2_e_values_12 = _RAND_66[15:0];
  _RAND_67 = {1{`RANDOM}};
  s2_e_values_13 = _RAND_67[15:0];
  _RAND_68 = {1{`RANDOM}};
  s2_e_values_14 = _RAND_68[15:0];
  _RAND_69 = {1{`RANDOM}};
  s2_e_values_15 = _RAND_69[15:0];
  _RAND_70 = {1{`RANDOM}};
  s2_v_values_0 = _RAND_70[7:0];
  _RAND_71 = {1{`RANDOM}};
  s2_v_values_1 = _RAND_71[7:0];
  _RAND_72 = {1{`RANDOM}};
  s2_v_values_2 = _RAND_72[7:0];
  _RAND_73 = {1{`RANDOM}};
  s2_v_values_3 = _RAND_73[7:0];
  _RAND_74 = {1{`RANDOM}};
  s2_v_values_4 = _RAND_74[7:0];
  _RAND_75 = {1{`RANDOM}};
  s2_v_values_5 = _RAND_75[7:0];
  _RAND_76 = {1{`RANDOM}};
  s2_v_values_6 = _RAND_76[7:0];
  _RAND_77 = {1{`RANDOM}};
  s2_v_values_7 = _RAND_77[7:0];
  _RAND_78 = {1{`RANDOM}};
  s2_v_values_8 = _RAND_78[7:0];
  _RAND_79 = {1{`RANDOM}};
  s2_v_values_9 = _RAND_79[7:0];
  _RAND_80 = {1{`RANDOM}};
  s2_v_values_10 = _RAND_80[7:0];
  _RAND_81 = {1{`RANDOM}};
  s2_v_values_11 = _RAND_81[7:0];
  _RAND_82 = {1{`RANDOM}};
  s2_v_values_12 = _RAND_82[7:0];
  _RAND_83 = {1{`RANDOM}};
  s2_v_values_13 = _RAND_83[7:0];
  _RAND_84 = {1{`RANDOM}};
  s2_v_values_14 = _RAND_84[7:0];
  _RAND_85 = {1{`RANDOM}};
  s2_v_values_15 = _RAND_85[7:0];
  _RAND_86 = {1{`RANDOM}};
  s3_d_terms_0 = _RAND_86[15:0];
  _RAND_87 = {1{`RANDOM}};
  s3_d_terms_1 = _RAND_87[15:0];
  _RAND_88 = {1{`RANDOM}};
  s3_d_terms_2 = _RAND_88[15:0];
  _RAND_89 = {1{`RANDOM}};
  s3_d_terms_3 = _RAND_89[15:0];
  _RAND_90 = {1{`RANDOM}};
  s3_d_terms_4 = _RAND_90[15:0];
  _RAND_91 = {1{`RANDOM}};
  s3_d_terms_5 = _RAND_91[15:0];
  _RAND_92 = {1{`RANDOM}};
  s3_d_terms_6 = _RAND_92[15:0];
  _RAND_93 = {1{`RANDOM}};
  s3_d_terms_7 = _RAND_93[15:0];
  _RAND_94 = {1{`RANDOM}};
  s3_d_terms_8 = _RAND_94[15:0];
  _RAND_95 = {1{`RANDOM}};
  s3_d_terms_9 = _RAND_95[15:0];
  _RAND_96 = {1{`RANDOM}};
  s3_d_terms_10 = _RAND_96[15:0];
  _RAND_97 = {1{`RANDOM}};
  s3_d_terms_11 = _RAND_97[15:0];
  _RAND_98 = {1{`RANDOM}};
  s3_d_terms_12 = _RAND_98[15:0];
  _RAND_99 = {1{`RANDOM}};
  s3_d_terms_13 = _RAND_99[15:0];
  _RAND_100 = {1{`RANDOM}};
  s3_d_terms_14 = _RAND_100[15:0];
  _RAND_101 = {1{`RANDOM}};
  s3_d_terms_15 = _RAND_101[15:0];
  _RAND_102 = {1{`RANDOM}};
  s3_n_terms_0 = _RAND_102[23:0];
  _RAND_103 = {1{`RANDOM}};
  s3_n_terms_1 = _RAND_103[23:0];
  _RAND_104 = {1{`RANDOM}};
  s3_n_terms_2 = _RAND_104[23:0];
  _RAND_105 = {1{`RANDOM}};
  s3_n_terms_3 = _RAND_105[23:0];
  _RAND_106 = {1{`RANDOM}};
  s3_n_terms_4 = _RAND_106[23:0];
  _RAND_107 = {1{`RANDOM}};
  s3_n_terms_5 = _RAND_107[23:0];
  _RAND_108 = {1{`RANDOM}};
  s3_n_terms_6 = _RAND_108[23:0];
  _RAND_109 = {1{`RANDOM}};
  s3_n_terms_7 = _RAND_109[23:0];
  _RAND_110 = {1{`RANDOM}};
  s3_n_terms_8 = _RAND_110[23:0];
  _RAND_111 = {1{`RANDOM}};
  s3_n_terms_9 = _RAND_111[23:0];
  _RAND_112 = {1{`RANDOM}};
  s3_n_terms_10 = _RAND_112[23:0];
  _RAND_113 = {1{`RANDOM}};
  s3_n_terms_11 = _RAND_113[23:0];
  _RAND_114 = {1{`RANDOM}};
  s3_n_terms_12 = _RAND_114[23:0];
  _RAND_115 = {1{`RANDOM}};
  s3_n_terms_13 = _RAND_115[23:0];
  _RAND_116 = {1{`RANDOM}};
  s3_n_terms_14 = _RAND_116[23:0];
  _RAND_117 = {1{`RANDOM}};
  s3_n_terms_15 = _RAND_117[23:0];
  _RAND_118 = {1{`RANDOM}};
  s3_keep_mask_0 = _RAND_118[0:0];
  _RAND_119 = {1{`RANDOM}};
  s3_keep_mask_1 = _RAND_119[0:0];
  _RAND_120 = {1{`RANDOM}};
  s3_keep_mask_2 = _RAND_120[0:0];
  _RAND_121 = {1{`RANDOM}};
  s3_keep_mask_3 = _RAND_121[0:0];
  _RAND_122 = {1{`RANDOM}};
  s3_keep_mask_4 = _RAND_122[0:0];
  _RAND_123 = {1{`RANDOM}};
  s3_keep_mask_5 = _RAND_123[0:0];
  _RAND_124 = {1{`RANDOM}};
  s3_keep_mask_6 = _RAND_124[0:0];
  _RAND_125 = {1{`RANDOM}};
  s3_keep_mask_7 = _RAND_125[0:0];
  _RAND_126 = {1{`RANDOM}};
  s3_keep_mask_8 = _RAND_126[0:0];
  _RAND_127 = {1{`RANDOM}};
  s3_keep_mask_9 = _RAND_127[0:0];
  _RAND_128 = {1{`RANDOM}};
  s3_keep_mask_10 = _RAND_128[0:0];
  _RAND_129 = {1{`RANDOM}};
  s3_keep_mask_11 = _RAND_129[0:0];
  _RAND_130 = {1{`RANDOM}};
  s3_keep_mask_12 = _RAND_130[0:0];
  _RAND_131 = {1{`RANDOM}};
  s3_keep_mask_13 = _RAND_131[0:0];
  _RAND_132 = {1{`RANDOM}};
  s3_keep_mask_14 = _RAND_132[0:0];
  _RAND_133 = {1{`RANDOM}};
  s3_keep_mask_15 = _RAND_133[0:0];
  _RAND_134 = {1{`RANDOM}};
  s4_D = _RAND_134[19:0];
  _RAND_135 = {1{`RANDOM}};
  s4_N = _RAND_135[27:0];
  _RAND_136 = {1{`RANDOM}};
  s4_keep_mask = _RAND_136[15:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
