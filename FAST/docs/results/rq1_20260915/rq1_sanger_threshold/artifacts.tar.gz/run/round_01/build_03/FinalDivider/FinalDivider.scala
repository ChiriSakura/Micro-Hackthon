import chisel3._
import chisel3.util._
import chisel3.experimental.FixedPoint
import predict_unit.FixedPointDivPipelined

class FinalDivider extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val N_in = IO(Input(UInt(28.W)))
  val D_in = IO(Input(UInt(20.W)))
  val valid_out = IO(Output(Bool()))
  val result_out = IO(Output(UInt(16.W)))

  // The plan requires a 34-cycle latency. The linked 'pipelined_divider' reference has a latency of 'stages' (32 cycles).
  // To achieve the target latency, one pipeline stage is added at the input and one at the output.
  // Total latency = 1 (input reg) + 32 (divider) + 1 (output reg) = 34 cycles.

  // --- Input pipeline stage (1 cycle) ---
  val s1_valid = withClockAndReset(clock, reset) { RegNext(valid_in, false.B) }
  val s1_N_in = withClockAndReset(clock, reset) { RegNext(N_in) }
  val s1_D_in = withClockAndReset(clock, reset) { RegNext(D_in) }

  // --- Divider Instantiation and Connection (stages 2-33) ---

  // The linked reference 'FixedPointDivPipelined' is a standard Chisel 'Module' which requires an implicit clock and reset.
  // Since this 'FinalDivider' is a 'RawModule', we must provide the context explicitly using 'withClockAndReset'.
  // This fixes the 'No implicit clock' error from the previous attempt.
  val divider = withClockAndReset(clock, reset) {
    Module(new FixedPointDivPipelined(bitWidth = 32, point = 0, stages = 32))
  }

  divider.io.in_valid := s1_valid

  // Prepare numerator: N_in (s28) is scaled by 16 (left shift by 4).
  // N_in is a UInt port representing a two's complement number. .asSInt reinterprets it.
  // The shift operation on an SInt correctly sign-extends and widens the result to 32 bits.
  val num_s32 = (s1_N_in.asSInt << 4)
  divider.io.numerator := num_s32.asFixedPoint(0.BP)

  // Prepare denominator: D_in (u20) is zero-extended to 32 bits.
  // The divider takes a signed input. Zero-extending the unsigned D_in ensures it's treated as a positive number.
  val den_u32 = Cat(0.U(12.W), s1_D_in)
  divider.io.denominator := den_u32.asSInt.asFixedPoint(0.BP)

  // The divider core has a 32-cycle latency. Its output is valid at cycle C+33 relative to module input.
  val div_valid_out = divider.io.out_valid
  val div_result_out = divider.io.quotient // This is FixedPoint(32.W, 0.BP)

  // --- Output pipeline stage (1 cycle) ---
  val s34_valid = withClockAndReset(clock, reset) { RegNext(div_valid_out, false.B) }
  val s34_result = withClockAndReset(clock, reset) { RegNext(div_result_out) }

  // --- Final Output Assignment ---
  valid_out := s34_valid
  // Truncate the 32-bit signed result to 16 bits and output as a UInt bit pattern.
  result_out := s34_result.asSInt(15, 0).asUInt
}
