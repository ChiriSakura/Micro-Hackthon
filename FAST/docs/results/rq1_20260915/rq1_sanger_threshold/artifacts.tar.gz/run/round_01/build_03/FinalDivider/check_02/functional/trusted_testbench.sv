module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] valid_in;
reg [27:0] N_in;
reg [19:0] D_in;
wire [0:0] valid_out;
wire [15:0] result_out;
FinalDivider dut(.clock(clock),.reset(reset),.valid_in(valid_in),.N_in(N_in),.D_in(D_in),.valid_out(valid_out),.result_out(result_out));
initial begin
clock=0;
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=0 step=0 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd0;
D_in=20'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=6 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=7 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=8 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=9 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=10 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=11 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=12 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=13 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=14 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=15 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=16 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=17 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=18 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=19 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=20 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=21 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=22 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=23 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=24 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=25 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=26 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=27 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=28 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=29 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=30 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=31 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=32 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=33 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=0 step=34 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=0 step=34 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=35 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=36 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=0 step=36 output=result_out expected=0 actual=%0d",result_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=1 step=0 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd100;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=6 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=7 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=8 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=9 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=10 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=11 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=12 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=13 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=14 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=15 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=16 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=17 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=18 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=19 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=20 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=21 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=22 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=23 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=24 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=25 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=26 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=27 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=28 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=29 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=30 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=31 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=32 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=33 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=1 step=34 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=1 step=34 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=35 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=36 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=1 step=36 output=result_out expected=0 actual=%0d",result_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=2 step=0 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd134217727;
D_in=20'd1048575;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=6 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=7 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=8 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=9 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=10 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=11 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=12 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=13 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=14 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=15 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=16 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=17 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=18 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=19 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=20 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=21 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=22 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=23 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=24 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=25 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=26 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=27 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=28 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=29 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=30 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=31 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=32 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=33 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=2 step=34 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd2048) $fatal(1,"module case=2 step=34 output=result_out expected=2048 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=35 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=36 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=2 step=36 output=result_out expected=0 actual=%0d",result_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=3 step=0 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd0;
D_in=20'd1;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd100;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd134217727;
D_in=20'd1048575;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=3 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd6591832;
D_in=20'd984776;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=5 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd60343676;
D_in=20'd823839;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=6 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd75621076;
D_in=20'd90740;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=7 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=8 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd74459125;
D_in=20'd235811;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=9 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd124447943;
D_in=20'd292744;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=10 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd79135424;
D_in=20'd69448;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=11 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=12 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd32543666;
D_in=20'd286425;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=13 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd124108027;
D_in=20'd939001;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=14 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd221496879;
D_in=20'd429767;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=15 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=16 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd49988799;
D_in=20'd247774;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=17 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd10934157;
D_in=20'd845038;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=18 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
N_in=28'd183359260;
D_in=20'd416279;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=19 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=20 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=21 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=22 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=23 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=24 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=25 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=26 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=27 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=28 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=29 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=30 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=31 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=32 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=33 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=34 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=3 step=34 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=35 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=3 step=35 output=result_out expected=0 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=36 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd2048) $fatal(1,"module case=3 step=36 output=result_out expected=2048 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=37 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=38 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd107) $fatal(1,"module case=3 step=38 output=result_out expected=107 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=39 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd1171) $fatal(1,"module case=3 step=39 output=result_out expected=1171 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=40 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd13334) $fatal(1,"module case=3 step=40 output=result_out expected=13334 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=41 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=42 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd5052) $fatal(1,"module case=3 step=42 output=result_out expected=5052 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=43 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd6801) $fatal(1,"module case=3 step=43 output=result_out expected=6801 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=44 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd18231) $fatal(1,"module case=3 step=44 output=result_out expected=18231 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=45 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=46 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd1817) $fatal(1,"module case=3 step=46 output=result_out expected=1817 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=47 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd2114) $fatal(1,"module case=3 step=47 output=result_out expected=2114 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=48 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd63789) $fatal(1,"module case=3 step=48 output=result_out expected=63789 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=49 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=50 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd3228) $fatal(1,"module case=3 step=50 output=result_out expected=3228 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=51 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd207) $fatal(1,"module case=3 step=51 output=result_out expected=207 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=52 output=valid_out expected=1 actual=%0d",valid_out);
if (result_out !== 16'd62267) $fatal(1,"module case=3 step=52 output=result_out expected=62267 actual=%0d",result_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=53 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=54 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
N_in=28'd0;
D_in=20'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=55 output=valid_out expected=0 actual=%0d",valid_out);
if (result_out !== 16'd0) $fatal(1,"module case=3 step=55 output=result_out expected=0 actual=%0d",result_out);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule