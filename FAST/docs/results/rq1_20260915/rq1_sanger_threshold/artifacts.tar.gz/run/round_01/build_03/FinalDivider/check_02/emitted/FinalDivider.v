module FixedPointDivPipelined(
  input         clock,
  input         reset,
  input         io_in_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 55:14]
  input  [31:0] io_numerator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 55:14]
  input  [31:0] io_denominator, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 55:14]
  output        io_out_valid, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 55:14]
  output [31:0] io_quotient // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 55:14]
);
`ifdef RANDOMIZE_REG_INIT
  reg [63:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [63:0] _RAND_7;
  reg [31:0] _RAND_8;
  reg [31:0] _RAND_9;
  reg [31:0] _RAND_10;
  reg [31:0] _RAND_11;
  reg [31:0] _RAND_12;
  reg [31:0] _RAND_13;
  reg [63:0] _RAND_14;
  reg [31:0] _RAND_15;
  reg [31:0] _RAND_16;
  reg [31:0] _RAND_17;
  reg [31:0] _RAND_18;
  reg [31:0] _RAND_19;
  reg [31:0] _RAND_20;
  reg [63:0] _RAND_21;
  reg [31:0] _RAND_22;
  reg [31:0] _RAND_23;
  reg [31:0] _RAND_24;
  reg [31:0] _RAND_25;
  reg [31:0] _RAND_26;
  reg [31:0] _RAND_27;
  reg [63:0] _RAND_28;
  reg [31:0] _RAND_29;
  reg [31:0] _RAND_30;
  reg [31:0] _RAND_31;
  reg [31:0] _RAND_32;
  reg [31:0] _RAND_33;
  reg [31:0] _RAND_34;
  reg [63:0] _RAND_35;
  reg [31:0] _RAND_36;
  reg [31:0] _RAND_37;
  reg [31:0] _RAND_38;
  reg [31:0] _RAND_39;
  reg [31:0] _RAND_40;
  reg [31:0] _RAND_41;
  reg [63:0] _RAND_42;
  reg [31:0] _RAND_43;
  reg [31:0] _RAND_44;
  reg [31:0] _RAND_45;
  reg [31:0] _RAND_46;
  reg [31:0] _RAND_47;
  reg [31:0] _RAND_48;
  reg [63:0] _RAND_49;
  reg [31:0] _RAND_50;
  reg [31:0] _RAND_51;
  reg [31:0] _RAND_52;
  reg [31:0] _RAND_53;
  reg [31:0] _RAND_54;
  reg [31:0] _RAND_55;
  reg [63:0] _RAND_56;
  reg [31:0] _RAND_57;
  reg [31:0] _RAND_58;
  reg [31:0] _RAND_59;
  reg [31:0] _RAND_60;
  reg [31:0] _RAND_61;
  reg [31:0] _RAND_62;
  reg [63:0] _RAND_63;
  reg [31:0] _RAND_64;
  reg [31:0] _RAND_65;
  reg [31:0] _RAND_66;
  reg [31:0] _RAND_67;
  reg [31:0] _RAND_68;
  reg [31:0] _RAND_69;
  reg [63:0] _RAND_70;
  reg [31:0] _RAND_71;
  reg [31:0] _RAND_72;
  reg [31:0] _RAND_73;
  reg [31:0] _RAND_74;
  reg [31:0] _RAND_75;
  reg [31:0] _RAND_76;
  reg [63:0] _RAND_77;
  reg [31:0] _RAND_78;
  reg [31:0] _RAND_79;
  reg [31:0] _RAND_80;
  reg [31:0] _RAND_81;
  reg [31:0] _RAND_82;
  reg [31:0] _RAND_83;
  reg [63:0] _RAND_84;
  reg [31:0] _RAND_85;
  reg [31:0] _RAND_86;
  reg [31:0] _RAND_87;
  reg [31:0] _RAND_88;
  reg [31:0] _RAND_89;
  reg [31:0] _RAND_90;
  reg [63:0] _RAND_91;
  reg [31:0] _RAND_92;
  reg [31:0] _RAND_93;
  reg [31:0] _RAND_94;
  reg [31:0] _RAND_95;
  reg [31:0] _RAND_96;
  reg [31:0] _RAND_97;
  reg [63:0] _RAND_98;
  reg [31:0] _RAND_99;
  reg [31:0] _RAND_100;
  reg [31:0] _RAND_101;
  reg [31:0] _RAND_102;
  reg [31:0] _RAND_103;
  reg [31:0] _RAND_104;
  reg [63:0] _RAND_105;
  reg [31:0] _RAND_106;
  reg [31:0] _RAND_107;
  reg [31:0] _RAND_108;
  reg [31:0] _RAND_109;
  reg [31:0] _RAND_110;
  reg [31:0] _RAND_111;
  reg [63:0] _RAND_112;
  reg [31:0] _RAND_113;
  reg [31:0] _RAND_114;
  reg [31:0] _RAND_115;
  reg [31:0] _RAND_116;
  reg [31:0] _RAND_117;
  reg [31:0] _RAND_118;
  reg [63:0] _RAND_119;
  reg [31:0] _RAND_120;
  reg [31:0] _RAND_121;
  reg [31:0] _RAND_122;
  reg [31:0] _RAND_123;
  reg [31:0] _RAND_124;
  reg [31:0] _RAND_125;
  reg [63:0] _RAND_126;
  reg [31:0] _RAND_127;
  reg [31:0] _RAND_128;
  reg [31:0] _RAND_129;
  reg [31:0] _RAND_130;
  reg [31:0] _RAND_131;
  reg [31:0] _RAND_132;
  reg [63:0] _RAND_133;
  reg [31:0] _RAND_134;
  reg [31:0] _RAND_135;
  reg [31:0] _RAND_136;
  reg [31:0] _RAND_137;
  reg [31:0] _RAND_138;
  reg [31:0] _RAND_139;
  reg [63:0] _RAND_140;
  reg [31:0] _RAND_141;
  reg [31:0] _RAND_142;
  reg [31:0] _RAND_143;
  reg [31:0] _RAND_144;
  reg [31:0] _RAND_145;
  reg [31:0] _RAND_146;
  reg [63:0] _RAND_147;
  reg [31:0] _RAND_148;
  reg [31:0] _RAND_149;
  reg [31:0] _RAND_150;
  reg [31:0] _RAND_151;
  reg [31:0] _RAND_152;
  reg [31:0] _RAND_153;
  reg [63:0] _RAND_154;
  reg [31:0] _RAND_155;
  reg [31:0] _RAND_156;
  reg [31:0] _RAND_157;
  reg [31:0] _RAND_158;
  reg [31:0] _RAND_159;
  reg [31:0] _RAND_160;
  reg [63:0] _RAND_161;
  reg [31:0] _RAND_162;
  reg [31:0] _RAND_163;
  reg [31:0] _RAND_164;
  reg [31:0] _RAND_165;
  reg [31:0] _RAND_166;
  reg [31:0] _RAND_167;
  reg [63:0] _RAND_168;
  reg [31:0] _RAND_169;
  reg [31:0] _RAND_170;
  reg [31:0] _RAND_171;
  reg [31:0] _RAND_172;
  reg [31:0] _RAND_173;
  reg [31:0] _RAND_174;
  reg [63:0] _RAND_175;
  reg [31:0] _RAND_176;
  reg [31:0] _RAND_177;
  reg [31:0] _RAND_178;
  reg [31:0] _RAND_179;
  reg [31:0] _RAND_180;
  reg [31:0] _RAND_181;
  reg [63:0] _RAND_182;
  reg [31:0] _RAND_183;
  reg [31:0] _RAND_184;
  reg [31:0] _RAND_185;
  reg [31:0] _RAND_186;
  reg [31:0] _RAND_187;
  reg [31:0] _RAND_188;
  reg [63:0] _RAND_189;
  reg [31:0] _RAND_190;
  reg [31:0] _RAND_191;
  reg [31:0] _RAND_192;
  reg [31:0] _RAND_193;
  reg [31:0] _RAND_194;
  reg [31:0] _RAND_195;
  reg [63:0] _RAND_196;
  reg [31:0] _RAND_197;
  reg [31:0] _RAND_198;
  reg [31:0] _RAND_199;
  reg [31:0] _RAND_200;
  reg [31:0] _RAND_201;
  reg [31:0] _RAND_202;
  reg [63:0] _RAND_203;
  reg [31:0] _RAND_204;
  reg [31:0] _RAND_205;
  reg [31:0] _RAND_206;
  reg [31:0] _RAND_207;
  reg [31:0] _RAND_208;
  reg [31:0] _RAND_209;
  reg [63:0] _RAND_210;
  reg [31:0] _RAND_211;
  reg [31:0] _RAND_212;
  reg [31:0] _RAND_213;
  reg [31:0] _RAND_214;
  reg [31:0] _RAND_215;
  reg [31:0] _RAND_216;
  reg [31:0] _RAND_217;
  reg [31:0] _RAND_218;
  reg [31:0] _RAND_219;
  reg [31:0] _RAND_220;
`endif // RANDOMIZE_REG_INIT
  wire  _initial_dividend_T = $signed(io_numerator) < 32'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 90:35]
  wire [31:0] _initial_dividend_T_3 = 32'sh0 - $signed(io_numerator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 90:35]
  wire [31:0] initial_dividend = $signed(io_numerator) < 32'sh0 ? $signed(_initial_dividend_T_3) : $signed(io_numerator)
    ; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 90:39]
  wire  _initial_divisor_T = $signed(io_denominator) < 32'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 91:35]
  wire [31:0] _initial_divisor_T_3 = 32'sh0 - $signed(io_denominator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 91:35]
  wire [31:0] initial_divisor = $signed(io_denominator) < 32'sh0 ? $signed(_initial_divisor_T_3) : $signed(
    io_denominator); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 91:39]
  wire  initial_negative = _initial_dividend_T ^ _initial_divisor_T; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 92:42]
  wire  initial_divideByZero = $signed(io_denominator) == 32'sh0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 93:40]
  wire [32:0] shifted = {32'h0,initial_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_0 = {{1'd0}, initial_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial = shifted - _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits = shifted >= _GEN_0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_quotient = {31'h0,fits}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_dividend = {initial_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_1 = {REG_remainder[31:0],REG_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_2 = {{1'd0}, REG_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_1 = shifted_1 - _GEN_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_1 = shifted_1 >= _GEN_2; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_1_quotient = {REG_quotient[30:0],fits_1}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_1_dividend = {REG_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_1_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_1_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_2 = {REG_1_remainder[31:0],REG_1_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_4 = {{1'd0}, REG_1_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_2 = shifted_2 - _GEN_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_2 = shifted_2 >= _GEN_4; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_2_quotient = {REG_1_quotient[30:0],fits_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_2_dividend = {REG_1_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_2_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_2_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_3 = {REG_2_remainder[31:0],REG_2_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_6 = {{1'd0}, REG_2_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_3 = shifted_3 - _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_3 = shifted_3 >= _GEN_6; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_3_quotient = {REG_2_quotient[30:0],fits_3}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_3_dividend = {REG_2_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_3_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_3_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_4 = {REG_3_remainder[31:0],REG_3_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_8 = {{1'd0}, REG_3_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_4 = shifted_4 - _GEN_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_4 = shifted_4 >= _GEN_8; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_4_quotient = {REG_3_quotient[30:0],fits_4}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_4_dividend = {REG_3_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_4_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_4_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_4_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_5 = {REG_4_remainder[31:0],REG_4_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_10 = {{1'd0}, REG_4_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_5 = shifted_5 - _GEN_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_5 = shifted_5 >= _GEN_10; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_5_quotient = {REG_4_quotient[30:0],fits_5}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_5_dividend = {REG_4_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_5_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_5_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_5_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_6 = {REG_5_remainder[31:0],REG_5_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_12 = {{1'd0}, REG_5_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_6 = shifted_6 - _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_6 = shifted_6 >= _GEN_12; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_6_quotient = {REG_5_quotient[30:0],fits_6}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_6_dividend = {REG_5_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_6_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_6_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_6_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_7 = {REG_6_remainder[31:0],REG_6_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_14 = {{1'd0}, REG_6_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_7 = shifted_7 - _GEN_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_7 = shifted_7 >= _GEN_14; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_7_quotient = {REG_6_quotient[30:0],fits_7}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_7_dividend = {REG_6_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_7_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_7_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_7_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_8 = {REG_7_remainder[31:0],REG_7_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_16 = {{1'd0}, REG_7_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_8 = shifted_8 - _GEN_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_8 = shifted_8 >= _GEN_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_8_quotient = {REG_7_quotient[30:0],fits_8}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_8_dividend = {REG_7_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_8_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_8_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_8_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_9 = {REG_8_remainder[31:0],REG_8_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_18 = {{1'd0}, REG_8_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_9 = shifted_9 - _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_9 = shifted_9 >= _GEN_18; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_9_quotient = {REG_8_quotient[30:0],fits_9}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_9_dividend = {REG_8_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_9_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_9_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_9_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_10 = {REG_9_remainder[31:0],REG_9_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_20 = {{1'd0}, REG_9_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_10 = shifted_10 - _GEN_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_10 = shifted_10 >= _GEN_20; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_10_quotient = {REG_9_quotient[30:0],fits_10}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_10_dividend = {REG_9_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_10_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_10_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_10_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_11 = {REG_10_remainder[31:0],REG_10_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_22 = {{1'd0}, REG_10_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_11 = shifted_11 - _GEN_22; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_11 = shifted_11 >= _GEN_22; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_11_quotient = {REG_10_quotient[30:0],fits_11}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_11_dividend = {REG_10_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_11_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_11_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_11_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_12 = {REG_11_remainder[31:0],REG_11_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_24 = {{1'd0}, REG_11_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_12 = shifted_12 - _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_12 = shifted_12 >= _GEN_24; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_12_quotient = {REG_11_quotient[30:0],fits_12}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_12_dividend = {REG_11_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_12_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_12_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_12_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_13 = {REG_12_remainder[31:0],REG_12_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_26 = {{1'd0}, REG_12_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_13 = shifted_13 - _GEN_26; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_13 = shifted_13 >= _GEN_26; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_13_quotient = {REG_12_quotient[30:0],fits_13}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_13_dividend = {REG_12_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_13_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_13_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_13_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_14 = {REG_13_remainder[31:0],REG_13_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_28 = {{1'd0}, REG_13_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_14 = shifted_14 - _GEN_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_14 = shifted_14 >= _GEN_28; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_14_quotient = {REG_13_quotient[30:0],fits_14}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_14_dividend = {REG_13_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_14_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_14_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_14_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_14_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_14_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_14_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_14_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_15 = {REG_14_remainder[31:0],REG_14_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_30 = {{1'd0}, REG_14_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_15 = shifted_15 - _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_15 = shifted_15 >= _GEN_30; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_15_quotient = {REG_14_quotient[30:0],fits_15}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_15_dividend = {REG_14_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_15_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_15_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_15_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_15_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_15_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_15_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_15_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_16 = {REG_15_remainder[31:0],REG_15_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_32 = {{1'd0}, REG_15_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_16 = shifted_16 - _GEN_32; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_16 = shifted_16 >= _GEN_32; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_16_quotient = {REG_15_quotient[30:0],fits_16}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_16_dividend = {REG_15_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_16_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_16_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_16_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_16_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_16_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_16_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_16_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_17 = {REG_16_remainder[31:0],REG_16_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_34 = {{1'd0}, REG_16_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_17 = shifted_17 - _GEN_34; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_17 = shifted_17 >= _GEN_34; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_17_quotient = {REG_16_quotient[30:0],fits_17}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_17_dividend = {REG_16_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_17_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_17_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_17_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_17_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_17_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_17_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_17_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_18 = {REG_17_remainder[31:0],REG_17_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_36 = {{1'd0}, REG_17_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_18 = shifted_18 - _GEN_36; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_18 = shifted_18 >= _GEN_36; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_18_quotient = {REG_17_quotient[30:0],fits_18}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_18_dividend = {REG_17_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_18_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_18_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_18_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_18_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_18_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_18_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_18_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_19 = {REG_18_remainder[31:0],REG_18_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_38 = {{1'd0}, REG_18_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_19 = shifted_19 - _GEN_38; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_19 = shifted_19 >= _GEN_38; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_19_quotient = {REG_18_quotient[30:0],fits_19}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_19_dividend = {REG_18_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_19_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_19_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_19_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_19_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_19_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_19_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_19_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_20 = {REG_19_remainder[31:0],REG_19_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_40 = {{1'd0}, REG_19_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_20 = shifted_20 - _GEN_40; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_20 = shifted_20 >= _GEN_40; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_20_quotient = {REG_19_quotient[30:0],fits_20}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_20_dividend = {REG_19_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_20_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_20_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_20_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_20_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_20_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_20_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_20_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_21 = {REG_20_remainder[31:0],REG_20_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_42 = {{1'd0}, REG_20_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_21 = shifted_21 - _GEN_42; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_21 = shifted_21 >= _GEN_42; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_21_quotient = {REG_20_quotient[30:0],fits_21}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_21_dividend = {REG_20_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_21_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_21_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_21_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_21_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_21_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_21_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_21_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_22 = {REG_21_remainder[31:0],REG_21_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_44 = {{1'd0}, REG_21_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_22 = shifted_22 - _GEN_44; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_22 = shifted_22 >= _GEN_44; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_22_quotient = {REG_21_quotient[30:0],fits_22}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_22_dividend = {REG_21_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_22_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_22_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_22_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_22_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_22_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_22_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_22_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_23 = {REG_22_remainder[31:0],REG_22_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_46 = {{1'd0}, REG_22_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_23 = shifted_23 - _GEN_46; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_23 = shifted_23 >= _GEN_46; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_23_quotient = {REG_22_quotient[30:0],fits_23}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_23_dividend = {REG_22_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_23_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_23_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_23_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_23_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_23_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_23_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_23_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_24 = {REG_23_remainder[31:0],REG_23_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_48 = {{1'd0}, REG_23_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_24 = shifted_24 - _GEN_48; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_24 = shifted_24 >= _GEN_48; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_24_quotient = {REG_23_quotient[30:0],fits_24}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_24_dividend = {REG_23_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_24_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_24_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_24_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_24_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_24_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_24_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_24_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_25 = {REG_24_remainder[31:0],REG_24_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_50 = {{1'd0}, REG_24_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_25 = shifted_25 - _GEN_50; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_25 = shifted_25 >= _GEN_50; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_25_quotient = {REG_24_quotient[30:0],fits_25}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_25_dividend = {REG_24_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_25_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_25_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_25_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_25_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_25_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_25_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_25_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_26 = {REG_25_remainder[31:0],REG_25_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_52 = {{1'd0}, REG_25_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_26 = shifted_26 - _GEN_52; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_26 = shifted_26 >= _GEN_52; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_26_quotient = {REG_25_quotient[30:0],fits_26}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_26_dividend = {REG_25_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_26_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_26_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_26_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_26_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_26_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_26_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_26_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_27 = {REG_26_remainder[31:0],REG_26_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_54 = {{1'd0}, REG_26_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_27 = shifted_27 - _GEN_54; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_27 = shifted_27 >= _GEN_54; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_27_quotient = {REG_26_quotient[30:0],fits_27}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_27_dividend = {REG_26_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_27_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_27_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_27_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_27_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_27_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_27_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_27_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_28 = {REG_27_remainder[31:0],REG_27_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_56 = {{1'd0}, REG_27_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_28 = shifted_28 - _GEN_56; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_28 = shifted_28 >= _GEN_56; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_28_quotient = {REG_27_quotient[30:0],fits_28}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_28_dividend = {REG_27_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_28_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_28_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_28_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_28_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_28_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_28_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_28_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_29 = {REG_28_remainder[31:0],REG_28_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_58 = {{1'd0}, REG_28_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_29 = shifted_29 - _GEN_58; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_29 = shifted_29 >= _GEN_58; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_29_quotient = {REG_28_quotient[30:0],fits_29}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_29_dividend = {REG_28_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_29_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_29_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_29_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_29_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_29_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_29_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_29_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_30 = {REG_29_remainder[31:0],REG_29_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_60 = {{1'd0}, REG_29_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire [33:0] trial_30 = shifted_30 - _GEN_60; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_30 = shifted_30 >= _GEN_60; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_30_quotient = {REG_29_quotient[30:0],fits_30}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  wire [31:0] next_30_dividend = {REG_29_dividend[30:0],1'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 108:25]
  reg [32:0] REG_30_remainder; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_30_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_30_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg [31:0] REG_30_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_30_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_30_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_30_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [32:0] shifted_31 = {REG_30_remainder[31:0],REG_30_dividend[31]}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 101:22]
  wire [32:0] _GEN_62 = {{1'd0}, REG_30_divisor}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 102:32]
  wire  fits_31 = shifted_31 >= _GEN_62; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 103:31]
  wire [31:0] next_31_quotient = {REG_30_quotient[30:0],fits_31}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 106:25]
  reg [31:0] REG_31_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_31_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_31_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  reg  REG_31_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
  wire [31:0] _signed_T_3 = 32'sh0 - $signed(REG_31_quotient); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 127:50]
  wire [31:0] signed_ = REG_31_negative ? $signed(_signed_T_3) : $signed(REG_31_quotient); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 127:27]
  assign io_out_valid = REG_31_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 130:16]
  assign io_quotient = REG_31_divideByZero ? $signed(32'sh0) : $signed(signed_); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 131:54]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_remainder <= trial[32:0];
    end else begin
      REG_remainder <= shifted;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_quotient <= next_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_dividend <= next_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_divisor <= initial_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_negative <= initial_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_divideByZero <= initial_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_valid <= io_in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_1) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_1_remainder <= trial_1[32:0];
    end else begin
      REG_1_remainder <= shifted_1;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_1_quotient <= next_1_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_1_dividend <= next_1_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_1_divisor <= REG_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_1_negative <= REG_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_1_divideByZero <= REG_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_1_valid <= REG_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_2) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_2_remainder <= trial_2[32:0];
    end else begin
      REG_2_remainder <= shifted_2;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_2_quotient <= next_2_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_2_dividend <= next_2_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_2_divisor <= REG_1_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_2_negative <= REG_1_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_2_divideByZero <= REG_1_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_2_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_2_valid <= REG_1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_3) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_3_remainder <= trial_3[32:0];
    end else begin
      REG_3_remainder <= shifted_3;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_3_quotient <= next_3_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_3_dividend <= next_3_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_3_divisor <= REG_2_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_3_negative <= REG_2_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_3_divideByZero <= REG_2_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_3_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_3_valid <= REG_2_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_4) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_4_remainder <= trial_4[32:0];
    end else begin
      REG_4_remainder <= shifted_4;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_4_quotient <= next_4_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_4_dividend <= next_4_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_4_divisor <= REG_3_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_4_negative <= REG_3_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_4_divideByZero <= REG_3_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_4_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_4_valid <= REG_3_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_5) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_5_remainder <= trial_5[32:0];
    end else begin
      REG_5_remainder <= shifted_5;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_5_quotient <= next_5_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_5_dividend <= next_5_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_5_divisor <= REG_4_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_5_negative <= REG_4_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_5_divideByZero <= REG_4_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_5_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_5_valid <= REG_4_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_6) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_6_remainder <= trial_6[32:0];
    end else begin
      REG_6_remainder <= shifted_6;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_6_quotient <= next_6_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_6_dividend <= next_6_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_6_divisor <= REG_5_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_6_negative <= REG_5_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_6_divideByZero <= REG_5_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_6_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_6_valid <= REG_5_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_7) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_7_remainder <= trial_7[32:0];
    end else begin
      REG_7_remainder <= shifted_7;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_7_quotient <= next_7_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_7_dividend <= next_7_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_7_divisor <= REG_6_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_7_negative <= REG_6_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_7_divideByZero <= REG_6_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_7_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_7_valid <= REG_6_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_8) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_8_remainder <= trial_8[32:0];
    end else begin
      REG_8_remainder <= shifted_8;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_8_quotient <= next_8_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_8_dividend <= next_8_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_8_divisor <= REG_7_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_8_negative <= REG_7_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_8_divideByZero <= REG_7_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_8_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_8_valid <= REG_7_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_9) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_9_remainder <= trial_9[32:0];
    end else begin
      REG_9_remainder <= shifted_9;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_9_quotient <= next_9_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_9_dividend <= next_9_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_9_divisor <= REG_8_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_9_negative <= REG_8_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_9_divideByZero <= REG_8_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_9_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_9_valid <= REG_8_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_10) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_10_remainder <= trial_10[32:0];
    end else begin
      REG_10_remainder <= shifted_10;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_10_quotient <= next_10_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_10_dividend <= next_10_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_10_divisor <= REG_9_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_10_negative <= REG_9_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_10_divideByZero <= REG_9_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_10_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_10_valid <= REG_9_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_11) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_11_remainder <= trial_11[32:0];
    end else begin
      REG_11_remainder <= shifted_11;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_11_quotient <= next_11_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_11_dividend <= next_11_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_11_divisor <= REG_10_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_11_negative <= REG_10_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_11_divideByZero <= REG_10_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_11_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_11_valid <= REG_10_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_12) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_12_remainder <= trial_12[32:0];
    end else begin
      REG_12_remainder <= shifted_12;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_12_quotient <= next_12_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_12_dividend <= next_12_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_12_divisor <= REG_11_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_12_negative <= REG_11_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_12_divideByZero <= REG_11_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_12_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_12_valid <= REG_11_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_13) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_13_remainder <= trial_13[32:0];
    end else begin
      REG_13_remainder <= shifted_13;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_13_quotient <= next_13_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_13_dividend <= next_13_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_13_divisor <= REG_12_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_13_negative <= REG_12_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_13_divideByZero <= REG_12_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_13_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_13_valid <= REG_12_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_14) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_14_remainder <= trial_14[32:0];
    end else begin
      REG_14_remainder <= shifted_14;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_14_quotient <= next_14_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_14_dividend <= next_14_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_14_divisor <= REG_13_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_14_negative <= REG_13_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_14_divideByZero <= REG_13_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_14_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_14_valid <= REG_13_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_15) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_15_remainder <= trial_15[32:0];
    end else begin
      REG_15_remainder <= shifted_15;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_15_quotient <= next_15_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_15_dividend <= next_15_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_15_divisor <= REG_14_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_15_negative <= REG_14_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_15_divideByZero <= REG_14_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_15_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_15_valid <= REG_14_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_16) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_16_remainder <= trial_16[32:0];
    end else begin
      REG_16_remainder <= shifted_16;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_16_quotient <= next_16_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_16_dividend <= next_16_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_16_divisor <= REG_15_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_16_negative <= REG_15_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_16_divideByZero <= REG_15_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_16_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_16_valid <= REG_15_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_17) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_17_remainder <= trial_17[32:0];
    end else begin
      REG_17_remainder <= shifted_17;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_17_quotient <= next_17_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_17_dividend <= next_17_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_17_divisor <= REG_16_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_17_negative <= REG_16_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_17_divideByZero <= REG_16_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_17_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_17_valid <= REG_16_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_18) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_18_remainder <= trial_18[32:0];
    end else begin
      REG_18_remainder <= shifted_18;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_18_quotient <= next_18_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_18_dividend <= next_18_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_18_divisor <= REG_17_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_18_negative <= REG_17_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_18_divideByZero <= REG_17_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_18_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_18_valid <= REG_17_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_19) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_19_remainder <= trial_19[32:0];
    end else begin
      REG_19_remainder <= shifted_19;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_19_quotient <= next_19_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_19_dividend <= next_19_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_19_divisor <= REG_18_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_19_negative <= REG_18_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_19_divideByZero <= REG_18_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_19_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_19_valid <= REG_18_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_20) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_20_remainder <= trial_20[32:0];
    end else begin
      REG_20_remainder <= shifted_20;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_20_quotient <= next_20_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_20_dividend <= next_20_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_20_divisor <= REG_19_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_20_negative <= REG_19_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_20_divideByZero <= REG_19_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_20_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_20_valid <= REG_19_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_21) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_21_remainder <= trial_21[32:0];
    end else begin
      REG_21_remainder <= shifted_21;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_21_quotient <= next_21_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_21_dividend <= next_21_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_21_divisor <= REG_20_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_21_negative <= REG_20_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_21_divideByZero <= REG_20_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_21_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_21_valid <= REG_20_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_22) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_22_remainder <= trial_22[32:0];
    end else begin
      REG_22_remainder <= shifted_22;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_22_quotient <= next_22_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_22_dividend <= next_22_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_22_divisor <= REG_21_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_22_negative <= REG_21_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_22_divideByZero <= REG_21_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_22_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_22_valid <= REG_21_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_23) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_23_remainder <= trial_23[32:0];
    end else begin
      REG_23_remainder <= shifted_23;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_23_quotient <= next_23_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_23_dividend <= next_23_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_23_divisor <= REG_22_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_23_negative <= REG_22_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_23_divideByZero <= REG_22_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_23_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_23_valid <= REG_22_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_24) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_24_remainder <= trial_24[32:0];
    end else begin
      REG_24_remainder <= shifted_24;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_24_quotient <= next_24_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_24_dividend <= next_24_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_24_divisor <= REG_23_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_24_negative <= REG_23_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_24_divideByZero <= REG_23_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_24_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_24_valid <= REG_23_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_25) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_25_remainder <= trial_25[32:0];
    end else begin
      REG_25_remainder <= shifted_25;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_25_quotient <= next_25_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_25_dividend <= next_25_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_25_divisor <= REG_24_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_25_negative <= REG_24_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_25_divideByZero <= REG_24_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_25_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_25_valid <= REG_24_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_26) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_26_remainder <= trial_26[32:0];
    end else begin
      REG_26_remainder <= shifted_26;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_26_quotient <= next_26_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_26_dividend <= next_26_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_26_divisor <= REG_25_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_26_negative <= REG_25_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_26_divideByZero <= REG_25_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_26_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_26_valid <= REG_25_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_27) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_27_remainder <= trial_27[32:0];
    end else begin
      REG_27_remainder <= shifted_27;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_27_quotient <= next_27_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_27_dividend <= next_27_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_27_divisor <= REG_26_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_27_negative <= REG_26_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_27_divideByZero <= REG_26_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_27_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_27_valid <= REG_26_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_28) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_28_remainder <= trial_28[32:0];
    end else begin
      REG_28_remainder <= shifted_28;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_28_quotient <= next_28_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_28_dividend <= next_28_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_28_divisor <= REG_27_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_28_negative <= REG_27_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_28_divideByZero <= REG_27_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_28_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_28_valid <= REG_27_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_29) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_29_remainder <= trial_29[32:0];
    end else begin
      REG_29_remainder <= shifted_29;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_29_quotient <= next_29_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_29_dividend <= next_29_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_29_divisor <= REG_28_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_29_negative <= REG_28_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_29_divideByZero <= REG_28_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_29_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_29_valid <= REG_28_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_remainder <= 33'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else if (fits_30) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 105:26]
      REG_30_remainder <= trial_30[32:0];
    end else begin
      REG_30_remainder <= shifted_30;
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_30_quotient <= next_30_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_dividend <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_30_dividend <= next_30_dividend; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_divisor <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_30_divisor <= REG_29_divisor; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_30_negative <= REG_29_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_30_divideByZero <= REG_29_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_30_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_30_valid <= REG_29_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_31_quotient <= 32'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_31_quotient <= next_31_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_31_negative <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_31_negative <= REG_30_negative; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_31_divideByZero <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_31_divideByZero <= REG_30_divideByZero; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
      REG_31_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end else begin
      REG_31_valid <= REG_30_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/references/006.scala 121:22]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {2{`RANDOM}};
  REG_remainder = _RAND_0[32:0];
  _RAND_1 = {1{`RANDOM}};
  REG_quotient = _RAND_1[31:0];
  _RAND_2 = {1{`RANDOM}};
  REG_dividend = _RAND_2[31:0];
  _RAND_3 = {1{`RANDOM}};
  REG_divisor = _RAND_3[31:0];
  _RAND_4 = {1{`RANDOM}};
  REG_negative = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  REG_divideByZero = _RAND_5[0:0];
  _RAND_6 = {1{`RANDOM}};
  REG_valid = _RAND_6[0:0];
  _RAND_7 = {2{`RANDOM}};
  REG_1_remainder = _RAND_7[32:0];
  _RAND_8 = {1{`RANDOM}};
  REG_1_quotient = _RAND_8[31:0];
  _RAND_9 = {1{`RANDOM}};
  REG_1_dividend = _RAND_9[31:0];
  _RAND_10 = {1{`RANDOM}};
  REG_1_divisor = _RAND_10[31:0];
  _RAND_11 = {1{`RANDOM}};
  REG_1_negative = _RAND_11[0:0];
  _RAND_12 = {1{`RANDOM}};
  REG_1_divideByZero = _RAND_12[0:0];
  _RAND_13 = {1{`RANDOM}};
  REG_1_valid = _RAND_13[0:0];
  _RAND_14 = {2{`RANDOM}};
  REG_2_remainder = _RAND_14[32:0];
  _RAND_15 = {1{`RANDOM}};
  REG_2_quotient = _RAND_15[31:0];
  _RAND_16 = {1{`RANDOM}};
  REG_2_dividend = _RAND_16[31:0];
  _RAND_17 = {1{`RANDOM}};
  REG_2_divisor = _RAND_17[31:0];
  _RAND_18 = {1{`RANDOM}};
  REG_2_negative = _RAND_18[0:0];
  _RAND_19 = {1{`RANDOM}};
  REG_2_divideByZero = _RAND_19[0:0];
  _RAND_20 = {1{`RANDOM}};
  REG_2_valid = _RAND_20[0:0];
  _RAND_21 = {2{`RANDOM}};
  REG_3_remainder = _RAND_21[32:0];
  _RAND_22 = {1{`RANDOM}};
  REG_3_quotient = _RAND_22[31:0];
  _RAND_23 = {1{`RANDOM}};
  REG_3_dividend = _RAND_23[31:0];
  _RAND_24 = {1{`RANDOM}};
  REG_3_divisor = _RAND_24[31:0];
  _RAND_25 = {1{`RANDOM}};
  REG_3_negative = _RAND_25[0:0];
  _RAND_26 = {1{`RANDOM}};
  REG_3_divideByZero = _RAND_26[0:0];
  _RAND_27 = {1{`RANDOM}};
  REG_3_valid = _RAND_27[0:0];
  _RAND_28 = {2{`RANDOM}};
  REG_4_remainder = _RAND_28[32:0];
  _RAND_29 = {1{`RANDOM}};
  REG_4_quotient = _RAND_29[31:0];
  _RAND_30 = {1{`RANDOM}};
  REG_4_dividend = _RAND_30[31:0];
  _RAND_31 = {1{`RANDOM}};
  REG_4_divisor = _RAND_31[31:0];
  _RAND_32 = {1{`RANDOM}};
  REG_4_negative = _RAND_32[0:0];
  _RAND_33 = {1{`RANDOM}};
  REG_4_divideByZero = _RAND_33[0:0];
  _RAND_34 = {1{`RANDOM}};
  REG_4_valid = _RAND_34[0:0];
  _RAND_35 = {2{`RANDOM}};
  REG_5_remainder = _RAND_35[32:0];
  _RAND_36 = {1{`RANDOM}};
  REG_5_quotient = _RAND_36[31:0];
  _RAND_37 = {1{`RANDOM}};
  REG_5_dividend = _RAND_37[31:0];
  _RAND_38 = {1{`RANDOM}};
  REG_5_divisor = _RAND_38[31:0];
  _RAND_39 = {1{`RANDOM}};
  REG_5_negative = _RAND_39[0:0];
  _RAND_40 = {1{`RANDOM}};
  REG_5_divideByZero = _RAND_40[0:0];
  _RAND_41 = {1{`RANDOM}};
  REG_5_valid = _RAND_41[0:0];
  _RAND_42 = {2{`RANDOM}};
  REG_6_remainder = _RAND_42[32:0];
  _RAND_43 = {1{`RANDOM}};
  REG_6_quotient = _RAND_43[31:0];
  _RAND_44 = {1{`RANDOM}};
  REG_6_dividend = _RAND_44[31:0];
  _RAND_45 = {1{`RANDOM}};
  REG_6_divisor = _RAND_45[31:0];
  _RAND_46 = {1{`RANDOM}};
  REG_6_negative = _RAND_46[0:0];
  _RAND_47 = {1{`RANDOM}};
  REG_6_divideByZero = _RAND_47[0:0];
  _RAND_48 = {1{`RANDOM}};
  REG_6_valid = _RAND_48[0:0];
  _RAND_49 = {2{`RANDOM}};
  REG_7_remainder = _RAND_49[32:0];
  _RAND_50 = {1{`RANDOM}};
  REG_7_quotient = _RAND_50[31:0];
  _RAND_51 = {1{`RANDOM}};
  REG_7_dividend = _RAND_51[31:0];
  _RAND_52 = {1{`RANDOM}};
  REG_7_divisor = _RAND_52[31:0];
  _RAND_53 = {1{`RANDOM}};
  REG_7_negative = _RAND_53[0:0];
  _RAND_54 = {1{`RANDOM}};
  REG_7_divideByZero = _RAND_54[0:0];
  _RAND_55 = {1{`RANDOM}};
  REG_7_valid = _RAND_55[0:0];
  _RAND_56 = {2{`RANDOM}};
  REG_8_remainder = _RAND_56[32:0];
  _RAND_57 = {1{`RANDOM}};
  REG_8_quotient = _RAND_57[31:0];
  _RAND_58 = {1{`RANDOM}};
  REG_8_dividend = _RAND_58[31:0];
  _RAND_59 = {1{`RANDOM}};
  REG_8_divisor = _RAND_59[31:0];
  _RAND_60 = {1{`RANDOM}};
  REG_8_negative = _RAND_60[0:0];
  _RAND_61 = {1{`RANDOM}};
  REG_8_divideByZero = _RAND_61[0:0];
  _RAND_62 = {1{`RANDOM}};
  REG_8_valid = _RAND_62[0:0];
  _RAND_63 = {2{`RANDOM}};
  REG_9_remainder = _RAND_63[32:0];
  _RAND_64 = {1{`RANDOM}};
  REG_9_quotient = _RAND_64[31:0];
  _RAND_65 = {1{`RANDOM}};
  REG_9_dividend = _RAND_65[31:0];
  _RAND_66 = {1{`RANDOM}};
  REG_9_divisor = _RAND_66[31:0];
  _RAND_67 = {1{`RANDOM}};
  REG_9_negative = _RAND_67[0:0];
  _RAND_68 = {1{`RANDOM}};
  REG_9_divideByZero = _RAND_68[0:0];
  _RAND_69 = {1{`RANDOM}};
  REG_9_valid = _RAND_69[0:0];
  _RAND_70 = {2{`RANDOM}};
  REG_10_remainder = _RAND_70[32:0];
  _RAND_71 = {1{`RANDOM}};
  REG_10_quotient = _RAND_71[31:0];
  _RAND_72 = {1{`RANDOM}};
  REG_10_dividend = _RAND_72[31:0];
  _RAND_73 = {1{`RANDOM}};
  REG_10_divisor = _RAND_73[31:0];
  _RAND_74 = {1{`RANDOM}};
  REG_10_negative = _RAND_74[0:0];
  _RAND_75 = {1{`RANDOM}};
  REG_10_divideByZero = _RAND_75[0:0];
  _RAND_76 = {1{`RANDOM}};
  REG_10_valid = _RAND_76[0:0];
  _RAND_77 = {2{`RANDOM}};
  REG_11_remainder = _RAND_77[32:0];
  _RAND_78 = {1{`RANDOM}};
  REG_11_quotient = _RAND_78[31:0];
  _RAND_79 = {1{`RANDOM}};
  REG_11_dividend = _RAND_79[31:0];
  _RAND_80 = {1{`RANDOM}};
  REG_11_divisor = _RAND_80[31:0];
  _RAND_81 = {1{`RANDOM}};
  REG_11_negative = _RAND_81[0:0];
  _RAND_82 = {1{`RANDOM}};
  REG_11_divideByZero = _RAND_82[0:0];
  _RAND_83 = {1{`RANDOM}};
  REG_11_valid = _RAND_83[0:0];
  _RAND_84 = {2{`RANDOM}};
  REG_12_remainder = _RAND_84[32:0];
  _RAND_85 = {1{`RANDOM}};
  REG_12_quotient = _RAND_85[31:0];
  _RAND_86 = {1{`RANDOM}};
  REG_12_dividend = _RAND_86[31:0];
  _RAND_87 = {1{`RANDOM}};
  REG_12_divisor = _RAND_87[31:0];
  _RAND_88 = {1{`RANDOM}};
  REG_12_negative = _RAND_88[0:0];
  _RAND_89 = {1{`RANDOM}};
  REG_12_divideByZero = _RAND_89[0:0];
  _RAND_90 = {1{`RANDOM}};
  REG_12_valid = _RAND_90[0:0];
  _RAND_91 = {2{`RANDOM}};
  REG_13_remainder = _RAND_91[32:0];
  _RAND_92 = {1{`RANDOM}};
  REG_13_quotient = _RAND_92[31:0];
  _RAND_93 = {1{`RANDOM}};
  REG_13_dividend = _RAND_93[31:0];
  _RAND_94 = {1{`RANDOM}};
  REG_13_divisor = _RAND_94[31:0];
  _RAND_95 = {1{`RANDOM}};
  REG_13_negative = _RAND_95[0:0];
  _RAND_96 = {1{`RANDOM}};
  REG_13_divideByZero = _RAND_96[0:0];
  _RAND_97 = {1{`RANDOM}};
  REG_13_valid = _RAND_97[0:0];
  _RAND_98 = {2{`RANDOM}};
  REG_14_remainder = _RAND_98[32:0];
  _RAND_99 = {1{`RANDOM}};
  REG_14_quotient = _RAND_99[31:0];
  _RAND_100 = {1{`RANDOM}};
  REG_14_dividend = _RAND_100[31:0];
  _RAND_101 = {1{`RANDOM}};
  REG_14_divisor = _RAND_101[31:0];
  _RAND_102 = {1{`RANDOM}};
  REG_14_negative = _RAND_102[0:0];
  _RAND_103 = {1{`RANDOM}};
  REG_14_divideByZero = _RAND_103[0:0];
  _RAND_104 = {1{`RANDOM}};
  REG_14_valid = _RAND_104[0:0];
  _RAND_105 = {2{`RANDOM}};
  REG_15_remainder = _RAND_105[32:0];
  _RAND_106 = {1{`RANDOM}};
  REG_15_quotient = _RAND_106[31:0];
  _RAND_107 = {1{`RANDOM}};
  REG_15_dividend = _RAND_107[31:0];
  _RAND_108 = {1{`RANDOM}};
  REG_15_divisor = _RAND_108[31:0];
  _RAND_109 = {1{`RANDOM}};
  REG_15_negative = _RAND_109[0:0];
  _RAND_110 = {1{`RANDOM}};
  REG_15_divideByZero = _RAND_110[0:0];
  _RAND_111 = {1{`RANDOM}};
  REG_15_valid = _RAND_111[0:0];
  _RAND_112 = {2{`RANDOM}};
  REG_16_remainder = _RAND_112[32:0];
  _RAND_113 = {1{`RANDOM}};
  REG_16_quotient = _RAND_113[31:0];
  _RAND_114 = {1{`RANDOM}};
  REG_16_dividend = _RAND_114[31:0];
  _RAND_115 = {1{`RANDOM}};
  REG_16_divisor = _RAND_115[31:0];
  _RAND_116 = {1{`RANDOM}};
  REG_16_negative = _RAND_116[0:0];
  _RAND_117 = {1{`RANDOM}};
  REG_16_divideByZero = _RAND_117[0:0];
  _RAND_118 = {1{`RANDOM}};
  REG_16_valid = _RAND_118[0:0];
  _RAND_119 = {2{`RANDOM}};
  REG_17_remainder = _RAND_119[32:0];
  _RAND_120 = {1{`RANDOM}};
  REG_17_quotient = _RAND_120[31:0];
  _RAND_121 = {1{`RANDOM}};
  REG_17_dividend = _RAND_121[31:0];
  _RAND_122 = {1{`RANDOM}};
  REG_17_divisor = _RAND_122[31:0];
  _RAND_123 = {1{`RANDOM}};
  REG_17_negative = _RAND_123[0:0];
  _RAND_124 = {1{`RANDOM}};
  REG_17_divideByZero = _RAND_124[0:0];
  _RAND_125 = {1{`RANDOM}};
  REG_17_valid = _RAND_125[0:0];
  _RAND_126 = {2{`RANDOM}};
  REG_18_remainder = _RAND_126[32:0];
  _RAND_127 = {1{`RANDOM}};
  REG_18_quotient = _RAND_127[31:0];
  _RAND_128 = {1{`RANDOM}};
  REG_18_dividend = _RAND_128[31:0];
  _RAND_129 = {1{`RANDOM}};
  REG_18_divisor = _RAND_129[31:0];
  _RAND_130 = {1{`RANDOM}};
  REG_18_negative = _RAND_130[0:0];
  _RAND_131 = {1{`RANDOM}};
  REG_18_divideByZero = _RAND_131[0:0];
  _RAND_132 = {1{`RANDOM}};
  REG_18_valid = _RAND_132[0:0];
  _RAND_133 = {2{`RANDOM}};
  REG_19_remainder = _RAND_133[32:0];
  _RAND_134 = {1{`RANDOM}};
  REG_19_quotient = _RAND_134[31:0];
  _RAND_135 = {1{`RANDOM}};
  REG_19_dividend = _RAND_135[31:0];
  _RAND_136 = {1{`RANDOM}};
  REG_19_divisor = _RAND_136[31:0];
  _RAND_137 = {1{`RANDOM}};
  REG_19_negative = _RAND_137[0:0];
  _RAND_138 = {1{`RANDOM}};
  REG_19_divideByZero = _RAND_138[0:0];
  _RAND_139 = {1{`RANDOM}};
  REG_19_valid = _RAND_139[0:0];
  _RAND_140 = {2{`RANDOM}};
  REG_20_remainder = _RAND_140[32:0];
  _RAND_141 = {1{`RANDOM}};
  REG_20_quotient = _RAND_141[31:0];
  _RAND_142 = {1{`RANDOM}};
  REG_20_dividend = _RAND_142[31:0];
  _RAND_143 = {1{`RANDOM}};
  REG_20_divisor = _RAND_143[31:0];
  _RAND_144 = {1{`RANDOM}};
  REG_20_negative = _RAND_144[0:0];
  _RAND_145 = {1{`RANDOM}};
  REG_20_divideByZero = _RAND_145[0:0];
  _RAND_146 = {1{`RANDOM}};
  REG_20_valid = _RAND_146[0:0];
  _RAND_147 = {2{`RANDOM}};
  REG_21_remainder = _RAND_147[32:0];
  _RAND_148 = {1{`RANDOM}};
  REG_21_quotient = _RAND_148[31:0];
  _RAND_149 = {1{`RANDOM}};
  REG_21_dividend = _RAND_149[31:0];
  _RAND_150 = {1{`RANDOM}};
  REG_21_divisor = _RAND_150[31:0];
  _RAND_151 = {1{`RANDOM}};
  REG_21_negative = _RAND_151[0:0];
  _RAND_152 = {1{`RANDOM}};
  REG_21_divideByZero = _RAND_152[0:0];
  _RAND_153 = {1{`RANDOM}};
  REG_21_valid = _RAND_153[0:0];
  _RAND_154 = {2{`RANDOM}};
  REG_22_remainder = _RAND_154[32:0];
  _RAND_155 = {1{`RANDOM}};
  REG_22_quotient = _RAND_155[31:0];
  _RAND_156 = {1{`RANDOM}};
  REG_22_dividend = _RAND_156[31:0];
  _RAND_157 = {1{`RANDOM}};
  REG_22_divisor = _RAND_157[31:0];
  _RAND_158 = {1{`RANDOM}};
  REG_22_negative = _RAND_158[0:0];
  _RAND_159 = {1{`RANDOM}};
  REG_22_divideByZero = _RAND_159[0:0];
  _RAND_160 = {1{`RANDOM}};
  REG_22_valid = _RAND_160[0:0];
  _RAND_161 = {2{`RANDOM}};
  REG_23_remainder = _RAND_161[32:0];
  _RAND_162 = {1{`RANDOM}};
  REG_23_quotient = _RAND_162[31:0];
  _RAND_163 = {1{`RANDOM}};
  REG_23_dividend = _RAND_163[31:0];
  _RAND_164 = {1{`RANDOM}};
  REG_23_divisor = _RAND_164[31:0];
  _RAND_165 = {1{`RANDOM}};
  REG_23_negative = _RAND_165[0:0];
  _RAND_166 = {1{`RANDOM}};
  REG_23_divideByZero = _RAND_166[0:0];
  _RAND_167 = {1{`RANDOM}};
  REG_23_valid = _RAND_167[0:0];
  _RAND_168 = {2{`RANDOM}};
  REG_24_remainder = _RAND_168[32:0];
  _RAND_169 = {1{`RANDOM}};
  REG_24_quotient = _RAND_169[31:0];
  _RAND_170 = {1{`RANDOM}};
  REG_24_dividend = _RAND_170[31:0];
  _RAND_171 = {1{`RANDOM}};
  REG_24_divisor = _RAND_171[31:0];
  _RAND_172 = {1{`RANDOM}};
  REG_24_negative = _RAND_172[0:0];
  _RAND_173 = {1{`RANDOM}};
  REG_24_divideByZero = _RAND_173[0:0];
  _RAND_174 = {1{`RANDOM}};
  REG_24_valid = _RAND_174[0:0];
  _RAND_175 = {2{`RANDOM}};
  REG_25_remainder = _RAND_175[32:0];
  _RAND_176 = {1{`RANDOM}};
  REG_25_quotient = _RAND_176[31:0];
  _RAND_177 = {1{`RANDOM}};
  REG_25_dividend = _RAND_177[31:0];
  _RAND_178 = {1{`RANDOM}};
  REG_25_divisor = _RAND_178[31:0];
  _RAND_179 = {1{`RANDOM}};
  REG_25_negative = _RAND_179[0:0];
  _RAND_180 = {1{`RANDOM}};
  REG_25_divideByZero = _RAND_180[0:0];
  _RAND_181 = {1{`RANDOM}};
  REG_25_valid = _RAND_181[0:0];
  _RAND_182 = {2{`RANDOM}};
  REG_26_remainder = _RAND_182[32:0];
  _RAND_183 = {1{`RANDOM}};
  REG_26_quotient = _RAND_183[31:0];
  _RAND_184 = {1{`RANDOM}};
  REG_26_dividend = _RAND_184[31:0];
  _RAND_185 = {1{`RANDOM}};
  REG_26_divisor = _RAND_185[31:0];
  _RAND_186 = {1{`RANDOM}};
  REG_26_negative = _RAND_186[0:0];
  _RAND_187 = {1{`RANDOM}};
  REG_26_divideByZero = _RAND_187[0:0];
  _RAND_188 = {1{`RANDOM}};
  REG_26_valid = _RAND_188[0:0];
  _RAND_189 = {2{`RANDOM}};
  REG_27_remainder = _RAND_189[32:0];
  _RAND_190 = {1{`RANDOM}};
  REG_27_quotient = _RAND_190[31:0];
  _RAND_191 = {1{`RANDOM}};
  REG_27_dividend = _RAND_191[31:0];
  _RAND_192 = {1{`RANDOM}};
  REG_27_divisor = _RAND_192[31:0];
  _RAND_193 = {1{`RANDOM}};
  REG_27_negative = _RAND_193[0:0];
  _RAND_194 = {1{`RANDOM}};
  REG_27_divideByZero = _RAND_194[0:0];
  _RAND_195 = {1{`RANDOM}};
  REG_27_valid = _RAND_195[0:0];
  _RAND_196 = {2{`RANDOM}};
  REG_28_remainder = _RAND_196[32:0];
  _RAND_197 = {1{`RANDOM}};
  REG_28_quotient = _RAND_197[31:0];
  _RAND_198 = {1{`RANDOM}};
  REG_28_dividend = _RAND_198[31:0];
  _RAND_199 = {1{`RANDOM}};
  REG_28_divisor = _RAND_199[31:0];
  _RAND_200 = {1{`RANDOM}};
  REG_28_negative = _RAND_200[0:0];
  _RAND_201 = {1{`RANDOM}};
  REG_28_divideByZero = _RAND_201[0:0];
  _RAND_202 = {1{`RANDOM}};
  REG_28_valid = _RAND_202[0:0];
  _RAND_203 = {2{`RANDOM}};
  REG_29_remainder = _RAND_203[32:0];
  _RAND_204 = {1{`RANDOM}};
  REG_29_quotient = _RAND_204[31:0];
  _RAND_205 = {1{`RANDOM}};
  REG_29_dividend = _RAND_205[31:0];
  _RAND_206 = {1{`RANDOM}};
  REG_29_divisor = _RAND_206[31:0];
  _RAND_207 = {1{`RANDOM}};
  REG_29_negative = _RAND_207[0:0];
  _RAND_208 = {1{`RANDOM}};
  REG_29_divideByZero = _RAND_208[0:0];
  _RAND_209 = {1{`RANDOM}};
  REG_29_valid = _RAND_209[0:0];
  _RAND_210 = {2{`RANDOM}};
  REG_30_remainder = _RAND_210[32:0];
  _RAND_211 = {1{`RANDOM}};
  REG_30_quotient = _RAND_211[31:0];
  _RAND_212 = {1{`RANDOM}};
  REG_30_dividend = _RAND_212[31:0];
  _RAND_213 = {1{`RANDOM}};
  REG_30_divisor = _RAND_213[31:0];
  _RAND_214 = {1{`RANDOM}};
  REG_30_negative = _RAND_214[0:0];
  _RAND_215 = {1{`RANDOM}};
  REG_30_divideByZero = _RAND_215[0:0];
  _RAND_216 = {1{`RANDOM}};
  REG_30_valid = _RAND_216[0:0];
  _RAND_217 = {1{`RANDOM}};
  REG_31_quotient = _RAND_217[31:0];
  _RAND_218 = {1{`RANDOM}};
  REG_31_negative = _RAND_218[0:0];
  _RAND_219 = {1{`RANDOM}};
  REG_31_divideByZero = _RAND_219[0:0];
  _RAND_220 = {1{`RANDOM}};
  REG_31_valid = _RAND_220[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
module FinalDivider(
  input         clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 7:17]
  input         reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 8:17]
  input         valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 9:20]
  input  [27:0] N_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 10:16]
  input  [19:0] D_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 11:16]
  output        valid_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 12:21]
  output [15:0] result_out // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 13:22]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
`endif // RANDOMIZE_REG_INIT
  wire  divider_clock; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  wire  divider_reset; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  wire  divider_io_in_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  wire [31:0] divider_io_numerator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  wire [31:0] divider_io_denominator; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  wire  divider_io_out_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  wire [31:0] divider_io_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
  reg  s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 20:59]
  reg [27:0] s1_N_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 21:58]
  reg [19:0] s1_D_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 22:58]
  reg  s34_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 51:60]
  reg [31:0] s34_result; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 52:61]
  FixedPointDivPipelined divider ( // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 30:11]
    .clock(divider_clock),
    .reset(divider_reset),
    .io_in_valid(divider_io_in_valid),
    .io_numerator(divider_io_numerator),
    .io_denominator(divider_io_denominator),
    .io_out_valid(divider_io_out_valid),
    .io_quotient(divider_io_quotient)
  );
  assign valid_out = s34_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 55:13]
  assign result_out = s34_result[15:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 57:34]
  assign divider_clock = clock;
  assign divider_reset = reset;
  assign divider_io_in_valid = s1_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 33:23]
  assign divider_io_numerator = {$signed(s1_N_in), 4'h0}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 38:33]
  assign divider_io_denominator = {12'h0,s1_D_in}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 44:37]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 20:59]
      s1_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 20:59]
    end else begin
      s1_valid <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 20:59]
    end
    s1_N_in <= N_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 21:58]
    s1_D_in <= D_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 22:58]
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 51:60]
      s34_valid <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 51:60]
    end else begin
      s34_valid <= divider_io_out_valid; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 51:60]
    end
    s34_result <= divider_io_quotient; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_sanger_threshold/round_01/build_03/FinalDivider/FinalDivider.scala 52:61]
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  s1_valid = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  s1_N_in = _RAND_1[27:0];
  _RAND_2 = {1{`RANDOM}};
  s1_D_in = _RAND_2[19:0];
  _RAND_3 = {1{`RANDOM}};
  s34_valid = _RAND_3[0:0];
  _RAND_4 = {1{`RANDOM}};
  s34_result = _RAND_4[31:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
