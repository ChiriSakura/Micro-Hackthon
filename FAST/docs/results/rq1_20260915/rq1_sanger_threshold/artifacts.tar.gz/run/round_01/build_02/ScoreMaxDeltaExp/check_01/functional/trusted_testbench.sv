module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] valid_in;
reg [7:0] q_in;
reg [127:0] k_in;
wire [0:0] valid_out;
wire [255:0] e_values_out;
ScoreMaxDeltaExp dut(.clock(clock),.reset(reset),.valid_in(valid_in),.q_in(q_in),.k_in(k_in),.valid_out(valid_out),.e_values_out(e_values_out));
initial begin
clock=0;
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=0 step=0 output=e_values_out expected=0 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=0 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=0 step=3 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=5 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=0 step=5 output=e_values_out expected=0 actual=%0d",e_values_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=1 step=0 output=e_values_out expected=0 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd119;
k_in=128'd158798437896437949616241483468158498679;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=1 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=1 step=3 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=5 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=1 step=5 output=e_values_out expected=0 actual=%0d",e_values_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=2 step=0 output=e_values_out expected=0 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd136;
k_in=128'd181483929024500513847133123963609712776;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=2 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=2 step=3 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=5 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=2 step=5 output=e_values_out expected=0 actual=%0d",e_values_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=3 step=0 output=e_values_out expected=0 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=1 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd119;
k_in=128'd158798437896437949616241483468158498679;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd136;
k_in=128'd181483929024500513847133123963609712776;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=3 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=4 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=4 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd6;
k_in=128'd133675627699162836426760952961471760063;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=5 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=5 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd22;
k_in=128'd182123255894873296035206982041170165673;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=6 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd71;
k_in=128'd116217738347039293553405485551948585911;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=7 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd54696470797618383576525668884128441781115551963294104444430486719910870192779) $fatal(1,"module case=3 step=7 output=e_values_out expected=54696470797618383576525668884128441781115551963294104444430486719910870192779 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=8 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd571302190946101222281593831791687311647780379363105373844521499151469379950) $fatal(1,"module case=3 step=8 output=e_values_out expected=571302190946101222281593831791687311647780379363105373844521499151469379950 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd105;
k_in=128'd73816103745100878911360478521740674613;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=9 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd90178141794038281662674444092196734077413864809326184893529722200207325925470) $fatal(1,"module case=3 step=9 output=e_values_out expected=90178141794038281662674444092196734077413864809326184893529722200207325925470 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd30;
k_in=128'd61213478488820252256134758906607468922;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=10 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd68;
k_in=128'd275245561246775690154763954382237896226;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=11 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd1551562672847176564490230794870629992757670799084408085318837860779931404347) $fatal(1,"module case=3 step=11 output=e_values_out expected=1551562672847176564490230794870629992757670799084408085318837860779931404347 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=12 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd51382463538355258836152455969332271772365713185687513261531464159415688167423) $fatal(1,"module case=3 step=12 output=e_values_out expected=51382463538355258836152455969332271772365713185687513261531464159415688167423 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd106;
k_in=128'd125044176695481444964473076998262856225;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=13 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd5765871957450072327883692822859142279692500540342679693729580511583890012397) $fatal(1,"module case=3 step=13 output=e_values_out expected=5765871957450072327883692822859142279692500540342679693729580511583890012397 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd169;
k_in=128'd164048159149099133126186481258945646722;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=14 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd134;
k_in=128'd194606926588516888636688375889181065500;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=15 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd79582385936045500511052410469588171985284255148294298217386278143164762165899) $fatal(1,"module case=3 step=15 output=e_values_out expected=79582385936045500511052410469588171985284255148294298217386278143164762165899 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=16 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd2258108167657590896312521325681204424742537236097757790454829865369680756922) $fatal(1,"module case=3 step=16 output=e_values_out expected=2258108167657590896312521325681204424742537236097757790454829865369680756922 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd246;
k_in=128'd338072591323448704560983625857896639721;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=17 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd17756815670133176315977576925381421632921518180686189594454785452220491300883) $fatal(1,"module case=3 step=17 output=e_values_out expected=17756815670133176315977576925381421632921518180686189594454785452220491300883 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd156;
k_in=128'd100410661617164621728880605661371221925;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=18 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd88;
k_in=128'd66999301087809751303745853771742695397;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=19 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd3962105718393824596105768806776463997099560608547923314806974457705258549614) $fatal(1,"module case=3 step=19 output=e_values_out expected=3962105718393824596105768806776463997099560608547923314806974457705258549614 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=20 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd475281833471611658603566462407549327924104705442620184667852449737778792146) $fatal(1,"module case=3 step=20 output=e_values_out expected=475281833471611658603566462407549327924104705442620184667852449737778792146 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd136;
k_in=128'd158798437896437949616241483468158498679;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=21 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd2402919695331897944009605939263604074174722043093772596339026395260548546624) $fatal(1,"module case=3 step=21 output=e_values_out expected=2402919695331897944009605939263604074174722043093772596339026395260548546624 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd119;
k_in=128'd181483929024500513847133123963609712776;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=22 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=23 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=23 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=24 output=valid_out expected=1 actual=%0d",valid_out);
if (e_values_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=24 output=e_values_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",e_values_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=25 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=26 output=valid_out expected=0 actual=%0d",valid_out);
if (e_values_out !== 256'd0) $fatal(1,"module case=3 step=26 output=e_values_out expected=0 actual=%0d",e_values_out);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule