import chisel3._
import chisel3.util._

class Rq1SangerThreshold extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val start = IO(Input(Bool()))
  val q = IO(Input(UInt(8.W)))
  val k = IO(Input(UInt(128.W)))
  val v = IO(Input(UInt(128.W)))
  val done = IO(Output(Bool()))
  val result = IO(Output(UInt(16.W)))
  val keep_mask = IO(Output(UInt(16.W)))

  withClockAndReset(clock, reset) {
    // Instantiate child modules
    val scoreMaxDeltaExp = Module(new ScoreMaxDeltaExp)
    scoreMaxDeltaExp.clock := clock
    scoreMaxDeltaExp.reset := reset

    val selectionReduce = Module(new SelectionReduce)
    selectionReduce.clock := clock
    selectionReduce.reset := reset

    val finalDivider = Module(new FinalDivider)
    finalDivider.clock := clock
    finalDivider.reset := reset

    // FSM for pipeline control
    val sIdle :: sBusy :: Nil = Enum(2)
    val state = RegInit(sIdle)

    // Latched input registers
    val q_reg = RegInit(0.U(8.W))
    val k_reg = RegInit(0.U(128.W))
    val v_reg = RegInit(0.U(128.W))

    // One-cycle valid pulse to start the pipeline
    val smde_valid_in = WireDefault(false.B)

    // The total pipeline data path latency is 41 cycles (3+4+34).
    // The counter tracks the number of cycles since the start of a transaction.
    val counter = RegInit(0.U(7.W)) // 7 bits for 0-127, sufficient for 42.

    // Per the compiler diagnosis, the 'done' signal must be asserted when the counter reaches 42.
    // This ensures the final result from the pipeline is stable for one full cycle before being sampled.
    // Data path latency is 41 cycles. A transaction starting at t=0 has its result ready at t=41.
    // The counter is 0 at t=0, 1 at t=1, ..., 41 at t=41.
    // We assert done at t=42, when the counter is 42, to resolve the race condition.
    val is_done = (state === sBusy) && (counter === 42.U)

    // FSM state transitions and control logic
    switch(state) {
      is(sIdle) {
        when(start) {
          state := sBusy
          // Latch inputs and generate a one-cycle pulse to start the pipeline
          q_reg := q
          k_reg := k
          v_reg := v
          smde_valid_in := true.B
          counter := 0.U
        }
      }
      is(sBusy) {
        counter := counter + 1.U
        when(is_done) {
          state := sIdle
        }
      }
    }

    // --- Pipeline Data Path ---

    // Stage 1: ScoreMaxDeltaExp (Latency: 3 cycles)
    scoreMaxDeltaExp.valid_in := smde_valid_in
    scoreMaxDeltaExp.q_in := q_reg
    scoreMaxDeltaExp.k_in := k_reg

    // The 'v' input must be aligned with the output of ScoreMaxDeltaExp.
    // Delay 'v' by 3 cycles.
    val v_delayed_3 = ShiftRegister(v_reg, 3)

    // Stage 2: SelectionReduce (Latency: 4 cycles)
    selectionReduce.valid_in := scoreMaxDeltaExp.valid_out
    selectionReduce.e_values_in := scoreMaxDeltaExp.e_values_out
    selectionReduce.v_in := v_delayed_3
    selectionReduce.threshold_in := 3.U(8.W) // Hardwired as per plan

    // Stage 3: FinalDivider (Latency: 34 cycles)
    finalDivider.valid_in := selectionReduce.valid_out
    finalDivider.N_in := selectionReduce.N_out.asUInt
    finalDivider.D_in := selectionReduce.D_out

    // --- Output Alignment and Assignment ---

    // The 'keep_mask' is available after Stage 2 (total latency 3+4=7 cycles).
    // It must be delayed by the latency of Stage 3 (34 cycles) to align
    // with the final 'result'.
    val keep_mask_final = ShiftRegister(selectionReduce.keep_mask_out, 34)

    // Final outputs are valid when 'is_done' is true.
    done := is_done
    result := finalDivider.result_out
    keep_mask := keep_mask_final
  }
}
