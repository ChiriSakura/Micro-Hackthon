import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val q_in = IO(Input(UInt(8.W)))
  val k_in = IO(Input(UInt(128.W)))
  val valid_out = IO(Output(Bool()))
  val scores_out = IO(Output(UInt(144.W)))

  // Unpack inputs using explicit slicing and casting to SInt.
  // Per contract: q[d] at 4*d. So q[0] is low bits, q[1] is high bits.
  val q0 = q_in(3, 0).asSInt
  val q1 = q_in(7, 4).asSInt

  val scores_vec = Wire(Vec(16, SInt(9.W)))

  // Per contract: k[i][d] at 4*(2*i+d). This means k[i] is at bit 8*i.
  // k[i][0] is at 8*i + 0, k[i][1] is at 8*i + 4.
  for (i <- 0 until 16) {
    val k_base = i * 8
    val k_i0 = k_in(k_base + 3, k_base + 0).asSInt
    val k_i1 = k_in(k_base + 7, k_base + 4).asSInt

    // S4 * S4 results in S8
    val p0 = q0 * k_i0
    val p1 = q1 * k_i1

    // S8 + S8 results in S9. Chisel's SInt addition widens to prevent overflow.
    // The result correctly fits in the SInt(9.W) wire.
    scores_vec(i) := p0 + p1
  }

  // Register the outputs for a single-cycle pipeline.
  val valid_out_reg = withClockAndReset(clock, reset) {
    RegNext(valid_in, init = false.B)
  }
  valid_out := valid_out_reg

  val scores_out_reg = withClockAndReset(clock, reset) {
    // Use RegEnable to only update when valid_in is high.
    RegEnable(scores_vec.asUInt, 0.U(144.W), valid_in)
  }
  scores_out := scores_out_reg
}
