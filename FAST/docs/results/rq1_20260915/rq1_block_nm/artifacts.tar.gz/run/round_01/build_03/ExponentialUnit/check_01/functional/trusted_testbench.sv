module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] valid_in;
reg [143:0] scores_in;
wire [0:0] valid_out;
wire [255:0] exponentials_out;
ExponentialUnit dut(.clock(clock),.reset(reset),.valid_in(valid_in),.scores_in(scores_in),.valid_out(valid_out),.exponentials_out(exponentials_out));
initial begin
clock=0;
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=0 step=0 output=exponentials_out expected=0 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=0 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=0 step=1 output=exponentials_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=3 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=0 step=3 output=exponentials_out expected=0 actual=%0d",exponentials_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=1 step=0 output=exponentials_out expected=0 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd17457583195970038645878672413857557468727424;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=1 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd411451466659038524200357682597145161003751554663642664774991871) $fatal(1,"module case=1 step=1 output=exponentials_out expected=411451466659038524200357682597145161003751554663642664774991871 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=3 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=1 step=3 output=exponentials_out expected=0 actual=%0d",exponentials_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=2 step=0 output=exponentials_out expected=0 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd5583701669726411365622141046083347258489232;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=2 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115790629410329750877755812468108450614246727448422552968527559307795453968384) $fatal(1,"module case=2 step=1 output=exponentials_out expected=115790629410329750877755812468108450614246727448422552968527559307795453968384 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=3 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=2 step=3 output=exponentials_out expected=0 actual=%0d",exponentials_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=3 step=0 output=exponentials_out expected=0 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=1 output=exponentials_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd17457583195970038645878672413857557468727424;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=2 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd411451466659038524200357682597145161003751554663642664774991871) $fatal(1,"module case=3 step=2 output=exponentials_out expected=411451466659038524200357682597145161003751554663642664774991871 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd5583701669726411365622141046083347258489232;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115790629410329750877755812468108450614246727448422552968527559307795453968384) $fatal(1,"module case=3 step=3 output=exponentials_out expected=115790629410329750877755812468108450614246727448422552968527559307795453968384 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd17521058758251584537634527123102487309232835;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=5 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd28550583931888666872853882013580567605249916856548663527513506307878898) $fatal(1,"module case=3 step=5 output=exponentials_out expected=28550583931888666872853882013580567605249916856548663527513506307878898 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd1477077504343411201485910864333034351249168;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=6 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd12164183355622992813219399493502532739610177774179844096) $fatal(1,"module case=3 step=6 output=exponentials_out expected=12164183355622992813219399493502532739610177774179844096 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd9140124765822809920024955964302583381416199;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=7 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd6954310046967720721239858962924127284422059222758555712439127360990072995840) $fatal(1,"module case=3 step=7 output=exponentials_out expected=6954310046967720721239858962924127284422059222758555712439127360990072995840 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=8 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd908253841060733004986680371086154116653376;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=9 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd12734971145349575962972965208832073045117741976928102301517431701504) $fatal(1,"module case=3 step=9 output=exponentials_out expected=12734971145349575962972965208832073045117741976928102301517431701504 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd15232877270571035932033011586780988647077729;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=10 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd131841836531857870382276091311495094777870178466667096440832) $fatal(1,"module case=3 step=10 output=exponentials_out expected=131841836531857870382276091311495094777870178466667096440832 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd16274818132881304602162461412003540546665907;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=11 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd32153236728009812924544476081334778659294857854976) $fatal(1,"module case=3 step=11 output=exponentials_out expected=32153236728009812924544476081334778659294857854976 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=12 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd8023463036246355967434746352853615804129700;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=13 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115790336782253056280347696825091024882587112829544609939627674655778651766784) $fatal(1,"module case=3 step=13 output=exponentials_out expected=115790336782253056280347696825091024882587112829544609939627674655778651766784 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd3840437127350089155031619703608493644361931;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=14 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd7067496099311638554138288661697672647531101804231478162369462893235148382) $fatal(1,"module case=3 step=14 output=exponentials_out expected=7067496099311638554138288661697672647531101804231478162369462893235148382 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd19285433929860888356232261420226668701834729;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=15 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd9333008281631930353563474612619353300527910082772640120040325120) $fatal(1,"module case=3 step=15 output=exponentials_out expected=9333008281631930353563474612619353300527910082772640120040325120 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=16 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd11747582245474711754910764927525648995342310;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=17 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd822752278756383992381618638198339684051430961690679540579303424) $fatal(1,"module case=3 step=17 output=exponentials_out expected=822752278756383992381618638198339684051430961690679540579303424 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd17669696791663239170687826553877885329129756;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=18 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd464034187126405926884704878183700073135367802776543451406427684864) $fatal(1,"module case=3 step=18 output=exponentials_out expected=464034187126405926884704878183700073135367802776543451406427684864 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd14111113726479455147178516195369239350661384;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=19 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd319227877843539506468525854678101183414572821023123920029903028224) $fatal(1,"module case=3 step=19 output=exponentials_out expected=319227877843539506468525854678101183414572821023123920029903028224 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=20 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd11172193289283443295955271776512682085187840;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=21 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=21 output=exponentials_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd1;
scores_in=144'd11128551909247179845580446496135679420792575;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=22 output=valid_out expected=1 actual=%0d",valid_out);
if (exponentials_out !== 256'd115792089237316195423570985008687907853269984665640564039457584007913129639935) $fatal(1,"module case=3 step=22 output=exponentials_out expected=115792089237316195423570985008687907853269984665640564039457584007913129639935 actual=%0d",exponentials_out);
reset=1'd0;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=23 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
scores_in=144'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=24 output=valid_out expected=0 actual=%0d",valid_out);
if (exponentials_out !== 256'd0) $fatal(1,"module case=3 step=24 output=exponentials_out expected=0 actual=%0d",exponentials_out);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule