import chisel3._
import chisel3.util._

class ScoreCalculator extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val q_in = IO(Input(UInt(8.W)))
  val k_in = IO(Input(UInt(128.W)))
  val valid_out = IO(Output(Bool()))
  val scores_out = IO(Output(UInt(144.W)))

  // Combinational logic to calculate scores
  val q0 = q_in(3, 0).asSInt
  val q1 = q_in(7, 4).asSInt

  val scores_wire = Wire(Vec(16, SInt(9.W)))

  for (i <- 0 until 16) {
    val k_i0 = k_in(i * 8 + 3, i * 8 + 0).asSInt
    val k_i1 = k_in(i * 8 + 7, i * 8 + 4).asSInt

    // Products are S4*S4 -> S8
    val p0 = q0 * k_i0
    val p1 = q1 * k_i1

    // Widening addition S8 +& S8 -> S9 to prevent overflow (e.g., 64+64=128)
    scores_wire(i) := p0 +& p1
  }

  // Pipeline registers with explicit clock and reset domain
  withClockAndReset(clock, reset) {
    // valid_out is a delayed version of valid_in.
    valid_out := RegNext(valid_in, false.B)

    // scores_out is the registered version of the calculated scores.
    // Latch new scores only when valid_in is asserted.
    scores_out := RegEnable(scores_wire.asUInt, 0.U(144.W), valid_in)
  }
}
