import chisel3._
import chisel3.util._

class ExponentialUnit extends RawModule {
  val clock = IO(Input(Clock()))
  val reset = IO(Input(Bool()))
  val valid_in = IO(Input(Bool()))
  val scores_in = IO(Input(UInt(144.W)))
  val valid_out = IO(Output(Bool()))
  val exponentials_out = IO(Output(UInt(256.W)))

  // The exp_table from the algorithm contract, used to initialize a ROM.
  val exp_table_data = Seq(
    65535, 61564, 57834, 54330, 51039, 47946, 45042, 42313, 39749, 37341, 35078, 32953, 30957, 29081, 27319, 25664,
    24109, 22648, 21276, 19987, 18776, 17639, 16570, 15566, 14623, 13737, 12905, 12123, 11388, 10698, 10050, 9441,
    8869, 8332, 7827, 7353, 6907, 6489, 6096, 5726, 5379, 5054, 4747, 4460, 4190, 3936, 3697, 3473, 3263, 3065,
    2879, 2705, 2541, 2387, 2242, 2107, 1979, 1859, 1746, 1641, 1541, 1448, 1360, 1278, 1200, 1128, 1059, 995,
    935, 878, 825, 775, 728, 684, 642, 604, 567, 533, 500, 470, 442, 415, 390, 366, 344, 323, 303, 285,
    268, 252, 236, 222, 209, 196, 184, 173, 162, 153, 143, 135, 127, 119, 112, 105, 99, 93, 87, 82,
    77, 72, 68, 64, 60, 56, 53, 50, 47, 44, 41, 39, 36, 34, 32, 30, 28, 27, 25, 23, 22, 21,
    19, 18, 17, 16, 15, 14, 13, 13, 12, 11, 10, 10, 9, 9, 8, 8, 7, 7, 6, 6, 6, 5,
    5, 5, 4, 4, 4, 4, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
  ).map(_.U(16.W))
  val exp_table_rom = VecInit(exp_table_data)

  // Combinational logic path
  val scores = scores_in.asTypeOf(Vec(16, SInt(9.W)))

  // Find the maximum score 'h' using a comparator tree.
  val max_score = scores.reduce((a, b) => Mux(a > b, a, b))

  val exponentials = Wire(Vec(16, UInt(16.W)))
  for (i <- 0 until 16) {
    // Calculate delta d_i = h - s_i. The result is always non-negative.
    // Chisel widens the result of the subtraction to 10 bits to prevent overflow.
    val delta = (max_score - scores(i)).asUInt

    // The behavior spec requires clamping the delta to 255: `min(h-s_i, 255)`.
    // The previous attempt truncated with `delta(7,0)`, causing incorrect lookups for deltas > 255.
    // This Mux implements the required clamping behavior.
    val addr = Mux(delta > 255.U, 255.U(8.W), delta(7, 0))

    exponentials(i) := exp_table_rom(addr)
  }

  // Register outputs for a 1-cycle pipeline latency.
  withClockAndReset(clock, reset) {
    valid_out := RegNext(valid_in, false.B)
    // asUInt packs the vector with element 0 at the LSBs, matching the behavior spec.
    exponentials_out := RegNext(exponentials.asUInt, 0.U(256.W))
  }
}
