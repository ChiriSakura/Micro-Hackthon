module FASTTestbench;
reg [0:0] clock;
reg [0:0] reset;
reg [0:0] valid_in;
reg [7:0] q_in;
reg [127:0] k_in;
wire [0:0] valid_out;
wire [143:0] scores_out;
ScoreCalculator dut(.clock(clock),.reset(reset),.valid_in(valid_in),.q_in(q_in),.k_in(k_in),.valid_out(valid_out),.scores_out(scores_out));
initial begin
clock=0;
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=0 step=0 output=scores_out expected=0 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=0 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=0 step=1 output=scores_out expected=0 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=0 step=3 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=0 step=3 output=scores_out expected=0 actual=%0d",scores_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=1 step=0 output=scores_out expected=0 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd17;
k_in=128'd22685491128062564230891640495451214097;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=1 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd87282760072526900749650560754005328790530) $fatal(1,"module case=1 step=1 output=scores_out expected=87282760072526900749650560754005328790530 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=1 step=3 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=1 step=3 output=scores_out expected=0 actual=%0d",scores_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=2 step=0 output=scores_out expected=0 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd135;
k_in=128'd180149488369908598304139498052112582535;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=2 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd4931475944097769892355256682601301076664945) $fatal(1,"module case=2 step=1 output=scores_out expected=4931475944097769892355256682601301076664945 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=2 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=2 step=3 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=2 step=3 output=scores_out expected=0 actual=%0d",scores_out);
$display("FAST_CASE cycles=1");
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=0 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=3 step=0 output=scores_out expected=0 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=1 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=3 step=1 output=scores_out expected=0 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd17;
k_in=128'd22685491128062564230891640495451214097;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=2 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd87282760072526900749650560754005328790530) $fatal(1,"module case=3 step=2 output=scores_out expected=87282760072526900749650560754005328790530 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd135;
k_in=128'd180149488369908598304139498052112582535;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=3 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd4931475944097769892355256682601301076664945) $fatal(1,"module case=3 step=3 output=scores_out expected=4931475944097769892355256682601301076664945 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=4 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd6;
k_in=128'd133675627699162836426760952961471760063;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=5 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd1045429665492126554832916446078818470349306) $fatal(1,"module case=3 step=5 output=scores_out expected=1045429665492126554832916446078818470349306 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd22;
k_in=128'd182123255894873296035206982041170165673;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=6 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd20124546565700569997240300009967601653119952) $fatal(1,"module case=3 step=6 output=scores_out expected=20124546565700569997240300009967601653119952 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd71;
k_in=128'd116217738347039293553405485551948585911;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=7 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd3006297020025512151521461522881581393093149) $fatal(1,"module case=3 step=7 output=scores_out expected=3006297020025512151521461522881581393093149 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=8 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd105;
k_in=128'd73816103745100878911360478521740674613;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=9 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd20951185479964340477171097462415397078924783) $fatal(1,"module case=3 step=9 output=scores_out expected=20951185479964340477171097462415397078924783 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd30;
k_in=128'd61213478488820252256134758906607468922;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=10 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd261850435981635109077683579550817617439763) $fatal(1,"module case=3 step=10 output=scores_out expected=261850435981635109077683579550817617439763 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd68;
k_in=128'd275245561246775690154763954382237896226;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=11 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd21430644670013226026783013746564837056688144) $fatal(1,"module case=3 step=11 output=scores_out expected=21430644670013226026783013746564837056688144 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=12 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd106;
k_in=128'd125044176695481444964473076998262856225;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=13 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd1872481966708202616386735412143246878176262) $fatal(1,"module case=3 step=13 output=scores_out expected=1872481966708202616386735412143246878176262 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd169;
k_in=128'd164048159149099133126186481258945646722;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=14 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd21996363782795860910776272824270285708456994) $fatal(1,"module case=3 step=14 output=scores_out expected=21996363782795860910776272824270285708456994 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd134;
k_in=128'd194606926588516888636688375889181065500;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=15 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd3004864269584998703586166840855916131143136) $fatal(1,"module case=3 step=15 output=scores_out expected=3004864269584998703586166840855916131143136 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=16 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd246;
k_in=128'd338072591323448704560983625857896639721;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=17 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd21824341923427629926727075009728593228449240) $fatal(1,"module case=3 step=17 output=scores_out expected=21824341923427629926727075009728593228449240 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd156;
k_in=128'd100410661617164621728880605661371221925;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=18 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd21959177965661533340438779167579552223068182) $fatal(1,"module case=3 step=18 output=scores_out expected=21959177965661533340438779167579552223068182 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd88;
k_in=128'd66999301087809751303745853771742695397;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=19 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd22298538326316433415879742691727023356242382) $fatal(1,"module case=3 step=19 output=scores_out expected=22298538326316433415879742691727023356242382 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=20 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd136;
k_in=128'd181483929024500513847133123963609712776;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=21 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd5586096644641721647977635888256341042593920) $fatal(1,"module case=3 step=21 output=scores_out expected=5586096644641721647977635888256341042593920 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd119;
k_in=128'd158798437896437949616241483468158498679;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=22 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd4276855243553818136732877476946261110735970) $fatal(1,"module case=3 step=22 output=scores_out expected=4276855243553818136732877476946261110735970 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd136;
k_in=128'd158798437896437949616241483468158498679;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=23 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd17456552014505380149930112150801065758106000) $fatal(1,"module case=3 step=23 output=scores_out expected=17456552014505380149930112150801065758106000 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=24 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd0;
valid_in=1'd1;
q_in=8'd119;
k_in=128'd181483929024500513847133123963609712776;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd1) $fatal(1,"module case=3 step=25 output=valid_out expected=1 actual=%0d",valid_out);
if (scores_out !== 144'd17456552014505380149930112150801065758106000) $fatal(1,"module case=3 step=25 output=scores_out expected=17456552014505380149930112150801065758106000 actual=%0d",scores_out);
reset=1'd0;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=26 output=valid_out expected=0 actual=%0d",valid_out);
reset=1'd1;
valid_in=1'd0;
q_in=8'd0;
k_in=128'd0;
#5;
repeat (1) begin clock=1; #5; clock=0; #5; end
if (valid_out !== 1'd0) $fatal(1,"module case=3 step=27 output=valid_out expected=0 actual=%0d",valid_out);
if (scores_out !== 144'd0) $fatal(1,"module case=3 step=27 output=scores_out expected=0 actual=%0d",scores_out);
$display("FAST_CASE cycles=1");
$display("FAST_PASS cases=4");
$finish;
end
endmodule