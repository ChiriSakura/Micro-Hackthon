module ScoreCalculator(
  input          clock, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 5:17]
  input          reset, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 6:17]
  input          valid_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 7:20]
  input  [7:0]   q_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 8:16]
  input  [127:0] k_in, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 9:16]
  output         valid_out, // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 10:21]
  output [143:0] scores_out // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 11:22]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [159:0] _RAND_1;
`endif // RANDOMIZE_REG_INIT
  wire [3:0] q_vec_0 = q_in[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 15:28]
  wire [3:0] q_vec_1 = q_in[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 15:28]
  wire [3:0] k_mat_0_0 = k_in[3:0]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_0_1 = k_in[7:4]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_1_0 = k_in[11:8]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_1_1 = k_in[15:12]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_2_0 = k_in[19:16]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_2_1 = k_in[23:20]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_3_0 = k_in[27:24]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_3_1 = k_in[31:28]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_4_0 = k_in[35:32]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_4_1 = k_in[39:36]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_5_0 = k_in[43:40]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_5_1 = k_in[47:44]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_6_0 = k_in[51:48]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_6_1 = k_in[55:52]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_7_0 = k_in[59:56]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_7_1 = k_in[63:60]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_8_0 = k_in[67:64]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_8_1 = k_in[71:68]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_9_0 = k_in[75:72]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_9_1 = k_in[79:76]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_10_0 = k_in[83:80]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_10_1 = k_in[87:84]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_11_0 = k_in[91:88]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_11_1 = k_in[95:92]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_12_0 = k_in[99:96]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_12_1 = k_in[103:100]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_13_0 = k_in[107:104]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_13_1 = k_in[111:108]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_14_0 = k_in[115:112]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_14_1 = k_in[119:116]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_15_0 = k_in[123:120]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [3:0] k_mat_15_1 = k_in[127:124]; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 20:28]
  wire [7:0] p0 = $signed(q_vec_0) * $signed(k_mat_0_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1 = $signed(q_vec_1) * $signed(k_mat_0_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_0_T_2 = $signed(p0) + $signed(p1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_1 = $signed(q_vec_0) * $signed(k_mat_1_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_1 = $signed(q_vec_1) * $signed(k_mat_1_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_1_T_2 = $signed(p0_1) + $signed(p1_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_2 = $signed(q_vec_0) * $signed(k_mat_2_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_2 = $signed(q_vec_1) * $signed(k_mat_2_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_2_T_2 = $signed(p0_2) + $signed(p1_2); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_3 = $signed(q_vec_0) * $signed(k_mat_3_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_3 = $signed(q_vec_1) * $signed(k_mat_3_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_3_T_2 = $signed(p0_3) + $signed(p1_3); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_4 = $signed(q_vec_0) * $signed(k_mat_4_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_4 = $signed(q_vec_1) * $signed(k_mat_4_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_4_T_2 = $signed(p0_4) + $signed(p1_4); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_5 = $signed(q_vec_0) * $signed(k_mat_5_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_5 = $signed(q_vec_1) * $signed(k_mat_5_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_5_T_2 = $signed(p0_5) + $signed(p1_5); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_6 = $signed(q_vec_0) * $signed(k_mat_6_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_6 = $signed(q_vec_1) * $signed(k_mat_6_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_6_T_2 = $signed(p0_6) + $signed(p1_6); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_7 = $signed(q_vec_0) * $signed(k_mat_7_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_7 = $signed(q_vec_1) * $signed(k_mat_7_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_7_T_2 = $signed(p0_7) + $signed(p1_7); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_8 = $signed(q_vec_0) * $signed(k_mat_8_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_8 = $signed(q_vec_1) * $signed(k_mat_8_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_8_T_2 = $signed(p0_8) + $signed(p1_8); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_9 = $signed(q_vec_0) * $signed(k_mat_9_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_9 = $signed(q_vec_1) * $signed(k_mat_9_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_9_T_2 = $signed(p0_9) + $signed(p1_9); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_10 = $signed(q_vec_0) * $signed(k_mat_10_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_10 = $signed(q_vec_1) * $signed(k_mat_10_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_10_T_2 = $signed(p0_10) + $signed(p1_10); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_11 = $signed(q_vec_0) * $signed(k_mat_11_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_11 = $signed(q_vec_1) * $signed(k_mat_11_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_11_T_2 = $signed(p0_11) + $signed(p1_11); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_12 = $signed(q_vec_0) * $signed(k_mat_12_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_12 = $signed(q_vec_1) * $signed(k_mat_12_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_12_T_2 = $signed(p0_12) + $signed(p1_12); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_13 = $signed(q_vec_0) * $signed(k_mat_13_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_13 = $signed(q_vec_1) * $signed(k_mat_13_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_13_T_2 = $signed(p0_13) + $signed(p1_13); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_14 = $signed(q_vec_0) * $signed(k_mat_14_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_14 = $signed(q_vec_1) * $signed(k_mat_14_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_14_T_2 = $signed(p0_14) + $signed(p1_14); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  wire [7:0] p0_15 = $signed(q_vec_0) * $signed(k_mat_15_0); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 29:17]
  wire [7:0] p1_15 = $signed(q_vec_1) * $signed(k_mat_15_1); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 30:17]
  wire [7:0] _scores_vec_15_T_2 = $signed(p0_15) + $signed(p1_15); // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 34:25]
  reg  valid_out_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 39:25]
  wire [8:0] _scores_out_T = {{1{_scores_vec_0_T_2[7]}},_scores_vec_0_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_1 = {{1{_scores_vec_1_T_2[7]}},_scores_vec_1_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_2 = {{1{_scores_vec_2_T_2[7]}},_scores_vec_2_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_3 = {{1{_scores_vec_3_T_2[7]}},_scores_vec_3_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_4 = {{1{_scores_vec_4_T_2[7]}},_scores_vec_4_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_5 = {{1{_scores_vec_5_T_2[7]}},_scores_vec_5_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_6 = {{1{_scores_vec_6_T_2[7]}},_scores_vec_6_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_7 = {{1{_scores_vec_7_T_2[7]}},_scores_vec_7_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_8 = {{1{_scores_vec_8_T_2[7]}},_scores_vec_8_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_9 = {{1{_scores_vec_9_T_2[7]}},_scores_vec_9_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_10 = {{1{_scores_vec_10_T_2[7]}},_scores_vec_10_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_11 = {{1{_scores_vec_11_T_2[7]}},_scores_vec_11_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_12 = {{1{_scores_vec_12_T_2[7]}},_scores_vec_12_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_13 = {{1{_scores_vec_13_T_2[7]}},_scores_vec_13_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_14 = {{1{_scores_vec_14_T_2[7]}},_scores_vec_14_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [8:0] _scores_out_T_15 = {{1{_scores_vec_15_T_2[7]}},_scores_vec_15_T_2}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [71:0] scores_out_lo = {_scores_out_T_7,_scores_out_T_6,_scores_out_T_5,_scores_out_T_4,_scores_out_T_3,
    _scores_out_T_2,_scores_out_T_1,_scores_out_T}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  wire [143:0] _scores_out_T_16 = {_scores_out_T_15,_scores_out_T_14,_scores_out_T_13,_scores_out_T_12,_scores_out_T_11,
    _scores_out_T_10,_scores_out_T_9,_scores_out_T_8,scores_out_lo}; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:40]
  reg [143:0] scores_out_r; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:28]
  assign valid_out = valid_out_REG; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 39:15]
  assign scores_out = scores_out_r; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:16]
  always @(posedge clock) begin
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 39:25]
      valid_out_REG <= 1'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 39:25]
    end else begin
      valid_out_REG <= valid_in; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 39:25]
    end
    if (reset) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:28]
      scores_out_r <= 144'h0; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:28]
    end else if (valid_in) begin // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:28]
      scores_out_r <= _scores_out_T_16; // @[scratch/gz2522/gz2522/tmp/micro-hackthon/runs/rq1_v1_20260915/rq1_block_nm/round_01/build_02/ScoreCalculator/ScoreCalculator.scala 40:28]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  valid_out_REG = _RAND_0[0:0];
  _RAND_1 = {5{`RANDOM}};
  scores_out_r = _RAND_1[143:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
